# AI-Based Cross-Vector Digital Forensics and Cybercrime Evidence Assistance System with Explainable AI (Version C)

An advanced, air-gapped cybersecurity digital forensics and incident response (DFIR) platform designed to ingest, preserve, analyze, and correlate multi-vector cyber incident evidence while adhering strictly to academic defense and anti-fabrication standards.

---

## 1. System Architecture & Forensic Lifecycle

The system transforms raw multi-source telemetry into an evidence-backed DFIR investigation dossier through an 8-stage lifecycle:

```text
Collect  ──►  Preserve  ──►  Hash  ──►  Extract  ──►  Analyze  ──►  Correlate  ──►  Reconstruct Timeline  ──►  Explain  ──►  Report
```

```text
AI_Browser_Email_Forensics/
├── app/
│   ├── ai/                      # 11-Feature Machine Learning & Live SHAP TreeExplainer
│   │   ├── __init__.py
│   │   └── phishing_model.py
│   ├── browser/                 # Chromium & Firefox SQLite history extraction
│   │   ├── __init__.py
│   │   └── browser_forensics.py
│   ├── email/                   # RFC822 parser, SPF/DKIM/DMARC, attachment triage
│   │   ├── __init__.py
│   │   └── email_forensics.py
│   ├── network/                 # NetFlow, PCAP CSV, and DNS telemetry
│   │   ├── __init__.py
│   │   └── network_forensics.py
│   ├── nlp/                     # Social engineering lure & urgency detection
│   │   ├── __init__.py
│   │   └── phishing_nlp.py
│   ├── reports/                 # Dual Reporting (Technical DFIR & Community Assistance)
│   │   ├── __init__.py
│   │   └── report_generator.py
│   ├── website/                 # URL lexical structure & login form detection
│   │   ├── __init__.py
│   │   └── website_analysis.py
│   ├── community_assistance.py  # Plain English triage & awareness registry
│   ├── correlation_engine.py    # Cross-artifact correlation rules (URL, Domain, DNS-Net, Temporal)
│   ├── dashboard.py             # Flask Web Workstation & DFIR REST endpoints
│   ├── db.py                    # SQLite Case and Evidence Management store
│   ├── event_normalizer.py      # Common normalized forensic event schema
│   ├── evidence_graph.py        # Topological artifact relationship graph
│   ├── evidence_integrity.py    # Immutable vault storage & SHA-256 verification
│   ├── research_evaluation.py   # Benchmark evaluation & empirical ablation study
│   ├── timeline_generator.py    # Chronological timeline with anchored/unanchored segregation
│   └── utils.py                 # Domain extraction & heuristic scoring
├── data/
│   ├── benchmark_forensic_dataset.csv  # 200-sample balanced research dataset
│   └── dfir_cases.db            # Local SQLite case and evidence ledger
├── scripts/
│   ├── demo_case_generator.py   # One-click generator for reproducible CASE-2026-0001
│   └── generate_benchmark_dataset.py # Reproducible benchmark dataset generator
├── tests/                       # Comprehensive automated pytest suite
├── DATASET.md                   # Dataset provenance & feature dictionary
├── LIMITATIONS.md               # Technical boundaries & legal disclaimers
├── METHODOLOGY.md               # Scientific DFIR methodology documentation
├── RESEARCH_EXPERIMENT.md       # Empirical ablation experiment results
├── requirements.txt             # Python package dependencies
└── run.py                       # CLI & dashboard launcher
```

---

## 2. Key Capabilities in Version C

### 2.1. Case & Evidence Management
- Structured case registry: Case ID (e.g. `CASE-2026-0001`), incident category, description, and status.
- **Evidence Vault**: Original files are preserved in `uploads/evidence_vault/<case_id>/`.
- **SHA-256 Bitstream Integrity**: Immediate hash calculation upon acquisition. Analysis executes strictly on non-destructive working copies. Includes live **"Verify Integrity"** audit.

### 2.2. Normalized Forensic Event Model
- Standardizes events across all vectors:
  `EMAIL_RECEIVED`, `URL_EXTRACTED`, `URL_VISITED`, `DNS_QUERY`, `NETWORK_CONNECTION`, `DOMAIN_DETECTED`, `IP_DETECTED`, `CREDENTIAL_REQUEST`, `SUSPICIOUS_LANGUAGE`.
- Missing timestamps are assigned `"Timestamp unavailable"`. Timestamps are never fabricated.

### 2.3. Cross-Artifact Correlation Engine
- **URL Correlation**: Direct link between email lures and visited browser history.
- **Domain Correlation**: Suspicious domains tracked across email, browser, DNS, and NetFlow.
- **DNS-Network Correlation**: DNS query host resolution matching subsequent TCP flows.
- **Temporal Correlation**: Rapid attack progression matching within a 15-minute window.

### 2.4. Chronological Incident Timeline & Evidence Graph
- **Timeline**: Chronological sorting of verified events; segregation of unanchored indicators.
- **Topological Graph**: Interactive SVG/Canvas network linking Case $\rightarrow$ Evidence $\rightarrow$ Entities $\rightarrow$ Correlations with clickable node inspection.

### 2.5. Explainable AI with Live SHAP
- Trains a `RandomForestClassifier` (100 trees) on an 11-feature multi-vector matrix.
- Generates live Shapley values using `shap.TreeExplainer`, displaying exact numerical contributions ($\Delta$) per feature relative to baseline expectation.
- Combined with rule-based forensic reasoning.

### 2.6. Core Research Experiment: Vector Ablation Study
- Evaluates the cross-vector hypothesis on a 200-record benchmark dataset (`data/benchmark_forensic_dataset.csv`).
- Removes one vector at a time to measure the empirical impact on F1-score, Precision, Recall, ROC-AUC, FPR, and FNR.

### 2.7. Dual Reporting System
- **Technical Forensic Report**: Comprehensive DFIR dossier with evidence inventories, SHA-256 checksums, SHAP attributions, timeline, and IOC table.
- **Community Cybercrime Report**: Plain-English incident assistance, evidence preservation certificate, and safety next steps for non-experts.

---

## 3. Absolute Anti-Fabrication Rule & Viva Defense

This system is built for strict academic defense:
- **No hard-coded metrics:** All scores, probabilities, and SHAP values derive from real inference.
- **No fake datasets:** Benchmark research data and synthetic demonstration data are explicitly distinguished.
- **Viva Safety Audit:** Viewable at `/viva-audit`, documenting permitted vs prohibited claims for examiners.

---

## 4. Quick Start & Demonstration

### Setup Environment:
```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
```

### 1. Launch Safe Synthetic Demonstration Case:
```powershell
python scripts/demo_case_generator.py
```
*Initializes `CASE-2026-0001`, ingests 3 synthetic evidence items, executes cross-vector correlation, computes real SHAP values, and builds both HTML reports.*

### 2. Launch DFIR Web Console:
```powershell
python run.py --dashboard
```
Open **`http://127.0.0.1:5000`** in any browser.

### 3. Run Automated Tests:
```powershell
python -m pytest tests -v
```
