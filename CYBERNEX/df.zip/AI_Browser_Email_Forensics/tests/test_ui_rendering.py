import pytest
from app.dashboard import app


@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        # Pre-authenticate client for protected routes
        with client.session_transaction() as sess:
            sess['logged_in'] = True
            sess['username'] = 'admin'
        yield client


@pytest.fixture
def unauth_client():
    app.config['TESTING'] = False
    with app.test_client() as client:
        yield client


def test_login_page_renders(unauth_client):
    res = unauth_client.get('/login')
    assert res.status_code == 200
    assert b'Sign In' in res.data
    assert b'admin' in res.data
    assert b'forensics2026' in res.data


def test_login_authentication_success(unauth_client):
    res = unauth_client.post('/login', data={'username': 'admin', 'password': 'forensics2026'}, follow_redirects=True)
    assert res.status_code == 200
    assert b'Dashboard' in res.data


def test_dashboard_structure(client):
    res = client.get('/dashboard')
    assert res.status_code == 200
    assert b'Cyber Forensics' in res.data
    assert b'theme-toggle-btn' in res.data
    assert b'Email Forensics' in res.data
    assert b'Browser Forensics' in res.data
    assert b'URL Scanner' in res.data


def test_email_tool_structure(client):
    res = client.get('/tools/email')
    assert res.status_code == 200
    assert b'Email Forensics' in res.data
    assert b'Browser Session Extraction' in res.data
    assert b'Upload File' in res.data


def test_browser_tool_structure(client):
    res = client.get('/tools/browser')
    assert res.status_code == 200
    assert b'Browser Forensics' in res.data
    assert b'Live Extraction' in res.data
    assert b'Upload History File' in res.data


def test_url_tool_structure(client):
    res = client.get('/tools/url-scanner')
    assert res.status_code == 200
    assert b'URL Scanner' in res.data
    assert b'Scan URL' in res.data


def test_email_raw_paste_analysis(client):
    raw_header = (
        "From: alert@fake-bank.com\n"
        "To: victim@company.com\n"
        "Subject: Urgent Security Warning\n"
        "Authentication-Results: spf=fail; dkim=fail; dmarc=fail\n\n"
        "Please visit: http://phishing-site.test/login"
    )
    res = client.post('/analyze-email', data={'consent': 'yes', 'email_source': 'paste', 'email_raw': raw_header})
    assert res.status_code == 200
    assert b'VERDICT' in res.data
    assert b'theme-toggle-btn' in res.data


def test_browser_paste_analysis(client):
    urls = "http://45.33.11.9/login.php\nhttps://example-test.com"
    res = client.post('/analyze-browser', data={'consent': 'yes', 'browser_source': 'paste', 'browser_raw': urls})
    assert res.status_code == 200
    assert b'Browser Forensic Report' in res.data
    assert b'theme-toggle-btn' in res.data


def test_url_scan_analysis(client, monkeypatch):
    class MockResponse:
        status_code = 200
        text = "<html><head><title>Test Page</title></head><body>Login: <input name='pass' type='password'></body></html>"
    
    import requests
    monkeypatch.setattr(requests, "get", lambda *args, **kwargs: MockResponse())

    res = client.post('/scan-url', data={'scan_url': 'http://45.33.11.9/login.php'})
    assert res.status_code == 200
    assert b'VERDICT' in res.data
    assert b'theme-toggle-btn' in res.data
