from pathlib import Path

from app.ai.phishing_model import predict_class
from app.browser.browser_forensics import (
    analyze_browser_history,
    detect_installed_browsers,
    extract_live_browser_history,
    parse_pasted_urls,
)
from app.email.email_forensics import (
    analyze_email_file,
    analyze_email_inbox,
    extract_gmail_browser_telemetry,
    get_simulated_gmail_inbox,
    fetch_emails_from_imap,
)
from app.network.network_forensics import analyze_network_traffic

ROOT = Path(__file__).resolve().parents[1]


def test_email_analysis_runs():
    data = analyze_email_file(ROOT / "data" / "sample_email.eml")
    assert data["subject"]
    assert "risk_score" in data


def test_gmail_inbox_analysis():
    inbox = get_simulated_gmail_inbox("student@gmail.com")
    assert len(inbox) >= 2
    result = analyze_email_inbox(inbox, source_label="Test Gmail Feed")
    assert "overall_status" in result
    assert "inbox_risk_score" in result
    assert result["total_emails"] == len(inbox)
    assert result["phishing_count"] >= 1


def test_auto_gmail_browser_extraction():
    records = extract_gmail_browser_telemetry(limit=10)
    assert isinstance(records, list)
    if records:
        analysis = analyze_email_inbox(records, source_label="Auto Gmail Test")
        assert "overall_status" in analysis
        assert analysis["total_emails"] == len(records)


def test_imap_error_handling():
    emails, err = fetch_emails_from_imap(username="invalid@gmail.com", password="badpassword")
    assert err is not None
    assert len(emails) == 0


def test_browser_analysis_runs():
    data = analyze_browser_history(ROOT / "data" / "browser_history.csv")
    assert data["records_analyzed"] > 0
    assert "records" in data


def test_detect_installed_browsers():
    browsers = detect_installed_browsers()
    assert isinstance(browsers, list)
    assert len(browsers) >= 3


def test_extract_and_analyze_live_browser():
    records, label = extract_live_browser_history(browser_name="auto", limit=10)
    assert isinstance(records, list)
    assert len(records) > 0
    analysis = analyze_browser_history(records=records, source_label=label)
    assert "browser_risk_score" in analysis
    assert "status" in analysis
    assert len(analysis["records"]) == len(records)


def test_pasted_urls_analysis():
    sample_text = "http://45.33.11.9/login.php\nhttps://google.com"
    records = parse_pasted_urls(sample_text)
    assert len(records) == 2
    analysis = analyze_browser_history(records=records)
    assert analysis["records_analyzed"] == 2


def test_network_analysis_runs():
    data = analyze_network_traffic(ROOT / "data" / "network_sample.csv")
    assert data["flows_analyzed"] > 0


def test_model_prediction_runs():
    result = predict_class({
        "https": 0,
        "spf_result": 0,
        "dkim_result": 0,
        "dmarc_result": 0,
        "url_risk": 90,
        "domain_risk": 80,
        "number_of_suspicious_words": 6,
        "reply_to_mismatch": 1,
        "sender_domain_mismatch": 1,
        "suspicious_network_indicator": 1,
        "browser_risk_score": 82,
    })
    assert result["prediction"] in {"Safe", "Suspicious", "Phishing"}
