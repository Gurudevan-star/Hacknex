from pathlib import Path

import run


PROJECT_ROOT = Path(__file__).resolve().parents[1]
REQUIRED_DIRECTORIES = [
    "app",
    "app/browser",
    "app/email",
    "app/nlp",
    "app/network",
    "app/website",
    "app/ai",
    "app/reports",
    "data",
    "models",
    "docs/assets",
    "tests",
]


def test_required_directories_exist():
    for directory in REQUIRED_DIRECTORIES:
        assert (PROJECT_ROOT / directory).exists()


def test_main_function_runs():
    assert callable(run.main)

