from __future__ import annotations

import argparse
from pathlib import Path

from app.ai.phishing_model import predict_class
from app.browser.browser_forensics import analyze_browser_history
from app.email.email_forensics import analyze_email_file
from app.nlp.phishing_nlp import detect_phishing_language
from app.network.network_forensics import analyze_network_traffic
from app.reports.report_generator import generate_html_report
from app.website.website_analysis import analyze_url_for_suspicion

PROJECT_ROOT = Path(__file__).resolve().parent
EMAIL_FILE = PROJECT_ROOT / "data" / "sample_email.eml"
BROWSER_FILE = PROJECT_ROOT / "data" / "browser_history.csv"
NETWORK_FILE = PROJECT_ROOT / "data" / "network_sample.csv"


def ensure_demo_data():
    EMAIL_FILE.parent.mkdir(parents=True, exist_ok=True)
    if not EMAIL_FILE.exists():
        EMAIL_FILE.write_text(
            "From: security-alert@bank-update.net\n"
            "To: student@example.com\n"
            "Subject: Urgent: Verify your account immediately\n"
            "Reply-To: support@secure-account-login.net\n"
            "Return-Path: <bounce@bank-update.net>\n"
            "Received: from mail.bank-update.net (mail.bank-update.net [45.33.11.9])\n"
            "Authentication-Results: spf=fail smtp.mailfrom=bank-update.net; dkim=fail; dmarc=fail\n"
            "\n"
            "Urgent action required. Your bank account has been suspended.\n"
            "Verify your account immediately to avoid service interruption.\n"
            "Click the secure link below to confirm your password and payment details.\n"
            "https://login-verify-secure-bank.net/account/login\n",
            encoding="utf-8",
        )

    if not BROWSER_FILE.exists():
        BROWSER_FILE.write_text(
            "url,title,timestamp,visit_count\n"
            "https://www.google.com/search?q=secure-login,Google Search,2026-08-01 10:00:00,5\n"
            "http://45.33.11.9/login.php,Account Verification,2026-08-01 10:15:00,3\n"
            "https://bank-security-update.example.com/verify,Bank Update,2026-08-01 11:00:00,7\n",
            encoding="utf-8",
        )

    if not NETWORK_FILE.exists():
        NETWORK_FILE.write_text(
            "timestamp,src_ip,dst_ip,protocol,host,dns_query\n"
            "2026-08-01 10:00:00,192.168.1.10,45.33.11.9,HTTP,login-bank.example.com,login-bank.example.com\n",
            encoding="utf-8",
        )


def run_analysis(url: str = "http://45.33.11.9/login.php"):
    ensure_demo_data()

    email_data = analyze_email_file(EMAIL_FILE)
    browser_data = analyze_browser_history(BROWSER_FILE)
    network_data = analyze_network_traffic(NETWORK_FILE)
    nlp_data = detect_phishing_language(email_data["body"])
    website_data = analyze_url_for_suspicion(url)

    numeric_features = {
        "https": int(website_data.get("https", False) is True),
        "spf_result": 1 if email_data.get("spf") == "pass" else 0,
        "dkim_result": 1 if email_data.get("dkim") == "pass" else 0,
        "dmarc_result": 1 if email_data.get("dmarc") == "pass" else 0,
        "url_risk": int(website_data.get("risk_score", 0)),
        "domain_risk": int(browser_data.get("browser_risk_score", 0)),
        "number_of_suspicious_words": len(nlp_data.get("suspicious_words", [])),
        "reply_to_mismatch": int("Reply-To mismatch" in email_data.get("reasons", [])),
        "sender_domain_mismatch": int("Sender/domain mismatch" in email_data.get("reasons", [])),
        "suspicious_network_indicator": int("Suspicious host pattern" in network_data.get("reasons", [])),
        "browser_risk_score": float(browser_data.get("browser_risk_score", 0)),
    }

    result = predict_class(numeric_features)

    reasons = []
    reasons.extend(browser_data.get("suspicious_indicators", []))
    reasons.extend(email_data.get("reasons", []))
    reasons.extend(network_data.get("reasons", []))
    reasons.extend(website_data.get("reasons", []))
    reasons.extend(nlp_data.get("suspicious_words", []))

    report = {
        "prediction": result["prediction"],
        "risk_score": result["risk_score"],
        "reasons": sorted(set(reasons)),
        "browser_risk_score": browser_data.get("browser_risk_score", 0),
        "email_risk_score": email_data.get("risk_score", 0),
        "network_risk_score": network_data.get("risk_score", 0),
        "website_risk_score": website_data.get("risk_score", 0),
    }

    report_path = generate_html_report(report)

    print("========================================")
    print("AI-Based Browser and Email Forensics Engine")
    print("========================================")
    print(f"Prediction: {report['prediction']}")
    print(f"Risk Score: {report['risk_score']}/100")
    print("Reasons:")
    for reason in report["reasons"]:
        print(f"- {reason}")
    print(f"Model used: {result['model']}")
    print(f"HTML report saved to: {report_path}")
    return report


def main():
    parser = argparse.ArgumentParser(description="AI phishing forensics engine")
    parser.add_argument("--dashboard", action="store_true", help="Launch the Flask demo dashboard")
    parser.add_argument("--url", default="http://45.33.11.9/login.php", help="URL to analyze in safe mode")
    args = parser.parse_args()

    if args.dashboard:
        from app.dashboard import app

        app.run(host="127.0.0.1", port=5000, debug=True)
        return

    run_analysis(args.url)


if __name__ == "__main__":
    main()
