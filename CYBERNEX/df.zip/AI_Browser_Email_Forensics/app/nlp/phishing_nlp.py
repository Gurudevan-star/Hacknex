from __future__ import annotations

import re

from app.utils import clamp, keyword_hits


def detect_phishing_language(text: str):
    if not text:
        return {"risk_score": 0, "suspicious_words": [], "status": "safe"}

    hits = keyword_hits(text)
    score = min(len(hits) * 15, 85)
    if "verify" in text.lower() or "suspended" in text.lower():
        score += 10
    if "immediately" in text.lower() or "urgent" in text.lower():
        score += 10

    if "password" in text.lower() and ("reset" in text.lower() or "update" in text.lower()):
        score += 10

    score = clamp(score, 0, 100)
    return {
        "risk_score": round(score, 2),
        "suspicious_words": hits,
        "status": "phishing" if score >= 60 else "suspicious" if score >= 30 else "safe",
    }


if __name__ == "__main__":
    sample = "Urgent action required! Verify your account immediately. Password reset required to avoid suspension."
    print(detect_phishing_language(sample))
