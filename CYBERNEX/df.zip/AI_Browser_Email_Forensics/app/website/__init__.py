"""Website metadata and Selenium-based analysis module."""
