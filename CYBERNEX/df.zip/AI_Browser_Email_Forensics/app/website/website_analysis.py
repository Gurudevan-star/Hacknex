from __future__ import annotations

import re
from pathlib import Path

import requests
from bs4 import BeautifulSoup

from app.utils import clamp

SAFE_TIMEOUT = 10


def get_website_metadata(url: str):
    try:
        response = requests.get(url, timeout=SAFE_TIMEOUT, allow_redirects=True)
        title = ""
        soup = BeautifulSoup(response.text, "html.parser")
        if soup.title and soup.title.string:
            title = soup.title.string.strip()

        login_forms = len(soup.find_all("form")) > 0
        is_https = url.lower().startswith("https://")
        redirect_chain = list(response.history)
        return {
            "url": url,
            "title": title or "No title found",
            "https": is_https,
            "status_code": response.status_code,
            "login_forms_detected": login_forms,
            "redirects": len(redirect_chain),
            "screenshot": "No screenshot captured in safe mode",
            "error": None,
        }
    except Exception as exc:  # pragma: no cover - safe fallback
        return {
            "url": url,
            "title": "Unavailable",
            "https": False,
            "status_code": 0,
            "login_forms_detected": False,
            "redirects": 0,
            "screenshot": "No screenshot captured in safe mode",
            "error": str(exc),
        }


def analyze_url_for_suspicion(url: str):
    metadata = get_website_metadata(url)
    score = 10
    reasons = []

    if not metadata["https"]:
        reasons.append("Website uses HTTP instead of HTTPS")
        score += 25
    if metadata["login_forms_detected"]:
        reasons.append("Login form detected")
        score += 20
    if metadata["redirects"] > 1:
        reasons.append("Multiple redirects detected")
        score += 15
    if "login" in url.lower() or "verify" in url.lower() or "secure" in url.lower():
        reasons.append("URL matches phishing lure patterns")
        score += 20
    if metadata["error"]:
        reasons.append(f"Request error: {metadata['error']}")
        score += 10

    metadata["risk_score"] = round(clamp(score, 0, 100), 2)
    metadata["reasons"] = reasons or ["No clear phishing indicators detected in safe website metadata."]
    metadata["status"] = "phishing" if score >= 60 else "suspicious" if score >= 30 else "safe"
    return metadata


if __name__ == "__main__":
    print(analyze_url_for_suspicion("https://example.com"))
