"""Email forensic analysis module."""
