from __future__ import annotations

from pathlib import Path

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, f1_score, precision_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier

PROJECT_ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = PROJECT_ROOT / "models" / "phishing_model.joblib"
FEATURES = [
    "https",
    "spf_result",
    "dkim_result",
    "dmarc_result",
    "url_risk",
    "domain_risk",
    "number_of_suspicious_words",
    "reply_to_mismatch",
    "sender_domain_mismatch",
    "suspicious_network_indicator",
    "browser_risk_score",
]


def _build_dataset():
    rows = [
        [1, 1, 1, 1, 10, 5, 1, 0, 0, 0, 12, 0],
        [1, 1, 1, 1, 15, 10, 2, 0, 0, 0, 8, 0],
        [1, 0, 0, 0, 70, 65, 8, 1, 1, 1, 82, 1],
        [0, 0, 0, 0, 92, 78, 12, 1, 1, 1, 95, 1],
        [1, 1, 0, 0, 50, 45, 5, 0, 0, 1, 43, 1],
        [1, 1, 1, 1, 12, 15, 1, 0, 0, 0, 10, 0],
        [0, 0, 1, 0, 68, 60, 9, 1, 1, 1, 88, 1],
        [1, 1, 1, 1, 22, 18, 2, 0, 0, 0, 20, 0],
        [0, 1, 0, 1, 58, 52, 6, 1, 0, 1, 65, 1],
        [1, 1, 1, 1, 14, 12, 2, 0, 0, 0, 15, 0],
        [0, 0, 0, 0, 80, 70, 10, 1, 1, 1, 90, 1],
        [1, 1, 1, 1, 18, 14, 2, 0, 0, 0, 18, 0],
        [0, 1, 0, 0, 77, 74, 11, 1, 1, 1, 91, 1],
        [1, 1, 1, 1, 16, 11, 2, 0, 0, 0, 16, 0],
        [0, 1, 0, 0, 60, 57, 8, 1, 1, 1, 70, 1],
    ]

    columns = [
        "https",
        "spf_result",
        "dkim_result",
        "dmarc_result",
        "url_risk",
        "domain_risk",
        "number_of_suspicious_words",
        "reply_to_mismatch",
        "sender_domain_mismatch",
        "suspicious_network_indicator",
        "browser_risk_score",
        "label",
    ]
    df = pd.DataFrame(rows, columns=columns)
    return df


def train_models():
    df = _build_dataset()
    X = df[FEATURES]
    y = df["label"]

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42, stratify=y)

    models = {
        "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42),
        "LogisticRegression": LogisticRegression(max_iter=1000, random_state=42),
        "DecisionTree": DecisionTreeClassifier(random_state=42),
    }

    results = {}
    for name, model in models.items():
        model.fit(X_train, y_train)
        predictions = model.predict(X_test)
        results[name] = {
            "accuracy": accuracy_score(y_test, predictions),
            "precision": precision_score(y_test, predictions, zero_division=0),
            "recall": recall_score(y_test, predictions, zero_division=0),
            "f1": f1_score(y_test, predictions, zero_division=0),
            "model": model,
        }

    best_name = max(results, key=lambda key: results[key]["f1"])
    best_model = results[best_name]["model"]
    payload = {
        "model": best_model,
        "features": FEATURES,
        "evaluation": results,
        "best_model": best_name,
    }
    joblib.dump(payload, MODEL_PATH)
    return payload


def get_model():
    if not MODEL_PATH.exists():
        return train_models()
    payload = joblib.load(MODEL_PATH)
    return payload


def predict_class(features_dict):
    payload = get_model()
    model = payload["model"]
    row = {}
    for feature in payload["features"]:
        value = features_dict.get(feature, 0)
        if isinstance(value, bool):
            value = int(value)
        row[feature] = float(value)

    frame = pd.DataFrame([row], columns=payload["features"])
    pred = int(model.predict(frame)[0])
    probability = float(model.predict_proba(frame)[0][pred]) if hasattr(model, "predict_proba") else 0.0

    if pred == 1:
        if probability < 0.55:
            label = "Suspicious"
        else:
            label = "Phishing"
    else:
        label = "Safe"

    risk_score = int(round(probability * 100 if pred == 1 else max(0, 100 - probability * 100)))
    if label == "Suspicious":
        risk_score = max(45, min(70, risk_score))

    return {
        "prediction": label,
        "risk_score": risk_score,
        "probability": round(probability, 3),
        "model": payload["best_model"],
        "evaluation": payload["evaluation"],
    }


if __name__ == "__main__":
    model = train_models()
    print(model["best_model"])
    print(model["evaluation"])
