from __future__ import annotations

import re
from urllib.parse import urlparse


PHISHING_KEYWORDS = [
    "urgent",
    "verify",
    "verify account",
    "password",
    "suspended",
    "bank",
    "payment",
    "invoice",
    "reward",
    "click here",
    "confirm",
    "security alert",
    "lock your account",
    "act now",
    "final notice",
    "limited time",
    "threaten",
    "suspicious activity",
]


def normalize_url(url: str) -> str:
    if not url:
        return ""
    return url.strip().lower()


def extract_domain(url: str) -> str:
    cleaned = normalize_url(url)
    if not cleaned:
        return ""
    parsed = urlparse(cleaned if cleaned.startswith(("http://", "https://")) else "https://" + cleaned)
    return parsed.netloc or parsed.path or ""


def suspicious_url_structure(url: str) -> bool:
    cleaned = normalize_url(url)
    if not cleaned:
        return False
    if "http://" in cleaned and not cleaned.startswith("https://"):
        return True
    if re.search(r"(?:[0-9]{1,3}\.){3}[0-9]{1,3}", cleaned):
        return True
    if cleaned.count(".") > 4:
        return True
    if re.search(r"(?:login|verify|secure|update|confirm|bank|account|pay|invoice)", cleaned):
        return True
    return False


def suspicious_domain_score(domain: str) -> int:
    score = 0
    if not domain:
        return score
    lowered = domain.lower()
    if re.search(r"(?:login|verify|secure|update|account|bank|wallet|invoice|payment)", lowered):
        score += 35
    if lowered.count(".") > 2:
        score += 20
    if re.search(r"(?:cdn|drive|cloud|confirm|free|bonus|alert)", lowered):
        score += 15
    return min(score, 100)


def keyword_hits(text: str) -> list[str]:
    if not text:
        return []
    lowered = text.lower()
    hits = [word for word in PHISHING_KEYWORDS if word in lowered]
    return sorted(set(hits), key=lambda item: lowered.index(item))


def clamp(value: float, minimum: float = 0.0, maximum: float = 100.0) -> float:
    return max(minimum, min(value, maximum))


def clean_bool(value):
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "pass", "passive"}
    return bool(value)
