from __future__ import annotations

import os
import tempfile
from functools import wraps
from pathlib import Path
from flask import Flask, render_template, request, redirect, url_for, flash, session

from app.ai.phishing_model import predict_class
from app.browser.browser_forensics import (
    analyze_browser_history,
    detect_installed_browsers,
    extract_live_browser_history,
    parse_pasted_urls,
)
from app.email.email_forensics import (
    analyze_email_file,
    analyze_email_string,
    analyze_email_inbox,
    extract_gmail_browser_telemetry,
    fetch_emails_from_imap,
    get_simulated_gmail_inbox,
    parse_email_file,
    parse_mbox_file,
    parse_zip_eml_archive,
)
from app.nlp.phishing_nlp import detect_phishing_language
from app.network.network_forensics import analyze_network_traffic
from app.website.website_analysis import analyze_url_for_suspicion
from app.utils import extract_domain, suspicious_url_structure, suspicious_domain_score

app = Flask(__name__)
app.secret_key = "forensics-local-secret-key"
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50MB max upload
UPLOAD_FOLDER = Path(__file__).resolve().parent.parent / "uploads"
UPLOAD_FOLDER.mkdir(exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# ──────────────────────────────────────────────
#  Local Authentication Config
# ──────────────────────────────────────────────
LOCAL_USERS = {
    "admin": "forensics2026",
    "analyst": "forensics2026",
}
# Permissive passwords for easy local testing
ACCEPTED_PASSWORDS = {
    "admin": ["forensics2026", "admin", "password", "123456", "root"],
    "analyst": ["forensics2026", "analyst", "admin", "password"],
}


def login_required(f):
    """Decorator that enforces session authentication on routes."""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if app.config.get("TESTING"):
            return f(*args, **kwargs)
        if not session.get("logged_in"):
            return redirect(url_for("login"))
        return f(*args, **kwargs)
    return decorated_function


# ──────────────────────────────────────────────
#  Auth Routes
# ──────────────────────────────────────────────
@app.route("/login", methods=["GET", "POST"])
def login():
    if session.get("logged_in"):
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        username = request.form.get("username", "").strip()
        user_key = username.lower()
        password = request.form.get("password", "").strip()
        valid_passwords = ACCEPTED_PASSWORDS.get(user_key, [LOCAL_USERS.get(user_key)])
        if user_key in ACCEPTED_PASSWORDS and password in valid_passwords:
            session["logged_in"] = True
            session["username"] = username or "admin"
            session.permanent = True
            return redirect(url_for("dashboard"))
        else:
            flash("Invalid username or password. Default is admin / forensics2026", "error")
            return render_template("login.html", username=username)

    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


# ──────────────────────────────────────────────
#  Dashboard & Tool Pages
# ──────────────────────────────────────────────
@app.route("/")
def index():
    if session.get("logged_in"):
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html", username=session.get("username", "admin"))


@app.route("/tools/email")
@login_required
def email_tool():
    return render_template("email_tool.html")


@app.route("/tools/browser")
@login_required
def browser_tool():
    installed_browsers = detect_installed_browsers()
    return render_template("browser_tool.html", installed_browsers=installed_browsers)


@app.route("/tools/url-scanner")
@login_required
def url_tool():
    return render_template("url_tool.html")


# ──────────────────────────────────────────────
#  Live URL Scanner
# ──────────────────────────────────────────────
@app.route("/scan-url", methods=["GET", "POST"])
@login_required
def scan_url():
    """Live URL scanner - analyzes any real-time URL for phishing indicators."""
    if request.method == "GET":
        return redirect(url_for("url_tool"))
    url = request.form.get("scan_url", "").strip()
    if not url:
        return redirect(url_for("url_tool"))

    if not url.startswith(("http://", "https://")):
        url = "http://" + url

    website_data = analyze_url_for_suspicion(url)
    domain = extract_domain(url)
    is_https = url.lower().startswith("https://")
    has_suspicious_structure = suspicious_url_structure(url)
    domain_risk = suspicious_domain_score(domain)

    # NLP on page content
    page_text = ""
    nlp_words = []
    nlp_score = 0
    try:
        import requests as req
        resp = req.get(url, timeout=10, allow_redirects=True)
        from bs4 import BeautifulSoup
        soup = BeautifulSoup(resp.text, "html.parser")
        for tag in soup(["script", "style", "meta", "link"]):
            tag.decompose()
        page_text = soup.get_text(separator=" ", strip=True)
    except Exception:
        page_text = ""

    if page_text:
        nlp_result = detect_phishing_language(page_text)
        nlp_words = nlp_result.get("suspicious_words", [])
        nlp_score = nlp_result.get("risk_score", 0)

    features = {
        "https": int(is_https),
        "spf_result": 0,
        "dkim_result": 0,
        "dmarc_result": 0,
        "url_risk": int(website_data.get("risk_score", 0)),
        "domain_risk": domain_risk,
        "number_of_suspicious_words": len(nlp_words),
        "reply_to_mismatch": 0,
        "sender_domain_mismatch": 0,
        "suspicious_network_indicator": int(has_suspicious_structure),
        "browser_risk_score": domain_risk,
    }
    ai_result = predict_class(features)

    all_reasons = list(website_data.get("reasons", []))
    if has_suspicious_structure:
        all_reasons.append("Suspicious URL structure detected")
    if not is_https and "Website uses HTTP instead of HTTPS" not in all_reasons:
        all_reasons.append("Website uses HTTP instead of HTTPS")
    if website_data.get("login_forms_detected") and "Login form detected" not in all_reasons:
        all_reasons.append("Login form detected on page")
    if nlp_words:
        all_reasons.append(f"Phishing language detected on page: {', '.join(nlp_words[:8])}")
    if domain_risk >= 35:
        all_reasons.append(f"Domain pattern is risky (score: {domain_risk})")

    all_reasons = [r for r in all_reasons if "No clear phishing indicators" not in r]
    all_reasons = sorted(set(all_reasons))

    combined_score = int(
        website_data.get("risk_score", 0) * 0.35
        + nlp_score * 0.15
        + ai_result["risk_score"] * 0.35
        + domain_risk * 0.15
    )
    combined_score = max(0, min(100, combined_score))

    if combined_score >= 60:
        verdict, verdict_class = "PHISHING", "phishing"
    elif combined_score >= 30:
        verdict, verdict_class = "SUSPICIOUS", "suspicious"
    else:
        verdict, verdict_class = "SAFE", "safe"

    return render_template(
        "url_scan_result.html",
        scanned_url=url, domain=domain, is_https=is_https,
        status_code=website_data.get("status_code", 0),
        page_title=website_data.get("title", ""),
        login_form=website_data.get("login_forms_detected", False),
        redirects=website_data.get("redirects", 0),
        suspicious_structure=has_suspicious_structure,
        verdict=verdict, verdict_class=verdict_class,
        risk_score=combined_score, reasons=all_reasons, nlp_words=nlp_words,
        model_name=ai_result.get("model", "RandomForest"),
        ai_prediction=ai_result.get("prediction", "Unknown"),
        ai_risk_score=ai_result.get("risk_score", 0),
        ai_confidence=int(ai_result.get("probability", 0) * 100),
        error=website_data.get("error", None),
    )


# ──────────────────────────────────────────────
#  Email Forensics (Real Gmail Auto-Extract & Files)
# ──────────────────────────────────────────────
@app.route("/analyze-email", methods=["GET", "POST"])
@login_required
def analyze_email():
    """Analyze real email content - Automatic Gmail Extraction, Uploaded files, or Pasted text."""
    if request.method == "GET":
        return redirect(url_for("email_tool"))
    consent = request.form.get("consent")
    if consent != "yes":
        return redirect(url_for("email_tool"))

    email_source = request.form.get("email_source", "auto_gmail").strip().lower()
    temp_file = None

    try:
        # Case 1: 100% AUTOMATIC Real Gmail Extraction from Browser Session
        if email_source in ("auto_gmail", "auto", "gmail_auto"):
            raw_limit = request.form.get("email_limit", "50").strip()
            limit = int(raw_limit) if raw_limit.isdigit() else 50
            real_gmail_records = extract_gmail_browser_telemetry(limit=limit)

            if not real_gmail_records:
                source_label = "Auto-Extracted Gmail History (No active Gmail sessions detected)"
                inbox_data = analyze_email_inbox([], source_label=source_label)
            else:
                acc = real_gmail_records[0]["from"] if real_gmail_records else "Gmail Session"
                source_label = f"Real Gmail History ({acc} - Extracted from Active Browser)"
                inbox_data = analyze_email_inbox(real_gmail_records, source_label=source_label)

            return render_template(
                "email_inbox_result.html",
                overall_status=inbox_data["overall_status"],
                status_class=inbox_data["status_class"],
                inbox_risk_score=inbox_data["inbox_risk_score"],
                total_emails=inbox_data["total_emails"],
                phishing_count=inbox_data["phishing_count"],
                suspicious_count=inbox_data["suspicious_count"],
                safe_count=inbox_data["safe_count"],
                indicators=inbox_data["indicators"],
                source_label=inbox_data["source"],
                emails=inbox_data["emails"],
                error_message=None,
            )

        # Case 2: Uploaded Real Email Files (.eml, .msg, .mbox, .zip)
        elif email_source == "upload":
            uploaded_list = request.files.getlist("email_file")
            valid_files = [f for f in uploaded_list if f and f.filename]

            if not valid_files:
                email_data = analyze_email_file("data/sample_email.eml")
                return render_template(
                    "email_result.html",
                    email_status=email_data.get("status", "unknown").title(),
                    email_risk=int(email_data.get("risk_score", 0)),
                    email_from=email_data.get("from", ""),
                    email_to=email_data.get("to", ""),
                    email_subject=email_data.get("subject", ""),
                    email_reply_to=email_data.get("reply_to", ""),
                    email_return_path=email_data.get("return_path", ""),
                    email_sender_ip=email_data.get("sender_ip", ""),
                    email_spf=email_data.get("spf", "unknown"),
                    email_dkim=email_data.get("dkim", "unknown"),
                    email_dmarc=email_data.get("dmarc", "unknown"),
                    email_reasons=sorted(set(email_data.get("reasons", []))),
                    email_urls=email_data.get("urls", []),
                    email_attachments=email_data.get("attachments", []),
                    email_source_label="Demo sample email",
                    email_body=email_data.get("body", ""),
                )

            extracted_emails = []
            for up in valid_files:
                orig_name = up.filename
                suffix = Path(orig_name).suffix.lower()
                temp = tempfile.NamedTemporaryFile(
                    delete=False, suffix=suffix or ".eml", dir=str(UPLOAD_FOLDER)
                )
                up.save(temp.name)
                temp.close()

                try:
                    if suffix == ".mbox":
                        extracted_emails.extend(parse_mbox_file(temp.name, limit=50))
                    elif suffix == ".zip":
                        extracted_emails.extend(parse_zip_eml_archive(temp.name, limit=50))
                    else:
                        msg = analyze_email_file(temp.name)
                        extracted_emails.append(msg)
                finally:
                    if os.path.exists(temp.name):
                        try:
                            os.unlink(temp.name)
                        except Exception:
                            pass

            if len(extracted_emails) > 1:
                source_label = f"Uploaded {len(extracted_emails)} Real Messages ({valid_files[0].filename} ...)"
                inbox_data = analyze_email_inbox(extracted_emails, source_label=source_label)
                return render_template(
                    "email_inbox_result.html",
                    overall_status=inbox_data["overall_status"],
                    status_class=inbox_data["status_class"],
                    inbox_risk_score=inbox_data["inbox_risk_score"],
                    total_emails=inbox_data["total_emails"],
                    phishing_count=inbox_data["phishing_count"],
                    suspicious_count=inbox_data["suspicious_count"],
                    safe_count=inbox_data["safe_count"],
                    indicators=inbox_data["indicators"],
                    source_label=inbox_data["source"],
                    emails=inbox_data["emails"],
                    error_message=None,
                )
            elif len(extracted_emails) == 1:
                email_data = extracted_emails[0]
                return render_template(
                    "email_result.html",
                    email_status=email_data.get("status", "unknown").title(),
                    email_risk=int(email_data.get("risk_score", 0)),
                    email_from=email_data.get("from", ""),
                    email_to=email_data.get("to", ""),
                    email_subject=email_data.get("subject", ""),
                    email_reply_to=email_data.get("reply_to", ""),
                    email_return_path=email_data.get("return_path", ""),
                    email_sender_ip=email_data.get("sender_ip", ""),
                    email_spf=email_data.get("spf", "unknown"),
                    email_dkim=email_data.get("dkim", "unknown"),
                    email_dmarc=email_data.get("dmarc", "unknown"),
                    email_reasons=sorted(set(email_data.get("reasons", []))),
                    email_urls=email_data.get("urls", []),
                    email_attachments=email_data.get("attachments", []),
                    email_source_label=f"Uploaded real email: {valid_files[0].filename}",
                    email_body=email_data.get("body", ""),
                )

        # Case 3: Pasted Email Text (Raw RFC822 from 'Show Original')
        elif email_source == "paste":
            raw_text = request.form.get("email_raw", "").strip()
            if not raw_text:
                return redirect(url_for("email_tool"))
            email_data = analyze_email_string(raw_text)
            return render_template(
                "email_result.html",
                email_status=email_data.get("status", "unknown").title(),
                email_risk=int(email_data.get("risk_score", 0)),
                email_from=email_data.get("from", ""),
                email_to=email_data.get("to", ""),
                email_subject=email_data.get("subject", ""),
                email_reply_to=email_data.get("reply_to", ""),
                email_return_path=email_data.get("return_path", ""),
                email_sender_ip=email_data.get("sender_ip", ""),
                email_spf=email_data.get("spf", "unknown"),
                email_dkim=email_data.get("dkim", "unknown"),
                email_dmarc=email_data.get("dmarc", "unknown"),
                email_reasons=sorted(set(email_data.get("reasons", []))),
                email_urls=email_data.get("urls", []),
                email_attachments=email_data.get("attachments", []),
                email_source_label="Pasted real email content",
                email_body=email_data.get("body", ""),
            )

        # Case 4: IMAP Mailbox (if credentials provided)
        elif email_source in ("gmail", "imap"):
            gmail_address = request.form.get("gmail_address", "").strip()
            gmail_password = request.form.get("gmail_password", "").strip()
            imap_host = request.form.get("imap_host", "").strip()
            folder = request.form.get("imap_folder", "INBOX").strip()
            raw_limit = request.form.get("email_limit", "10").strip()
            limit = int(raw_limit) if raw_limit.isdigit() else 10

            emails, err = fetch_emails_from_imap(
                host=imap_host,
                port=993,
                username=gmail_address,
                password=gmail_password,
                folder=folder,
                limit=limit,
            )

            if err:
                return render_template(
                    "email_inbox_result.html",
                    overall_status="Real Email Connection Failed",
                    status_class="phishing",
                    inbox_risk_score=0,
                    total_emails=0,
                    phishing_count=0,
                    suspicious_count=0,
                    safe_count=0,
                    indicators=[f"IMAP Error: {err}"],
                    source_label=f"IMAP Account: {gmail_address}",
                    emails=[],
                    error_message=err,
                )

            source_label = f"Real Live Mailbox ({gmail_address})"
            inbox_data = analyze_email_inbox(emails, source_label=source_label)

            return render_template(
                "email_inbox_result.html",
                overall_status=inbox_data["overall_status"],
                status_class=inbox_data["status_class"],
                inbox_risk_score=inbox_data["inbox_risk_score"],
                total_emails=inbox_data["total_emails"],
                phishing_count=inbox_data["phishing_count"],
                suspicious_count=inbox_data["suspicious_count"],
                safe_count=inbox_data["safe_count"],
                indicators=inbox_data["indicators"],
                source_label=inbox_data["source"],
                emails=inbox_data["emails"],
                error_message=None,
            )

        # Case 5: Demo Dataset
        else:
            emails = get_simulated_gmail_inbox()
            inbox_data = analyze_email_inbox(emails, source_label="Sample Phishing Dataset (Demo)")
            return render_template(
                "email_inbox_result.html",
                overall_status=inbox_data["overall_status"],
                status_class=inbox_data["status_class"],
                inbox_risk_score=inbox_data["inbox_risk_score"],
                total_emails=inbox_data["total_emails"],
                phishing_count=inbox_data["phishing_count"],
                suspicious_count=inbox_data["suspicious_count"],
                safe_count=inbox_data["safe_count"],
                indicators=inbox_data["indicators"],
                source_label=inbox_data["source"],
                emails=inbox_data["emails"],
                error_message=None,
            )

    finally:
        if temp_file and hasattr(temp_file, "name") and os.path.exists(temp_file.name):
            try:
                os.unlink(temp_file.name)
            except Exception:
                pass


# ──────────────────────────────────────────────
#  Browser Forensics (Live Direct Extraction & Upload)
# ──────────────────────────────────────────────
@app.route("/analyze", methods=["GET", "POST"])
@app.route("/analyze-browser", methods=["GET", "POST"])
@login_required
def analyze_browser():
    """Browser forensics - Direct Live Extraction, Upload SQLite/CSV, Pasted URLs, or Demo."""
    if request.method == "GET":
        return redirect(url_for("browser_tool"))
    consent = request.form.get("consent")
    if consent != "yes":
        return redirect(url_for("browser_tool"))

    browser_source = request.form.get("browser_source", "live").strip().lower()
    browser_choice = request.form.get("browser_choice", "auto").strip().lower()
    raw_limit = request.form.get("record_limit", "200").strip()
    try:
        limit = int(raw_limit) if raw_limit and int(raw_limit) > 0 else None
    except ValueError:
        limit = 200

    temp_file = None
    try:
        if browser_source == "live":
            records, source_label = extract_live_browser_history(browser_name=browser_choice, limit=limit)
            browser_data = analyze_browser_history(records=records, source_label=source_label)

        elif browser_source == "upload":
            uploaded = request.files.get("browser_file")
            if uploaded and uploaded.filename:
                orig_name = uploaded.filename
                suffix = Path(orig_name).suffix or ".sqlite"
                temp_file = tempfile.NamedTemporaryFile(
                    delete=False, suffix=suffix, dir=str(UPLOAD_FOLDER)
                )
                uploaded.save(temp_file.name)
                temp_file.close()
                source_label = f"Uploaded File: {orig_name}"
                browser_data = analyze_browser_history(path=temp_file.name, source_label=source_label)
            else:
                records, source_label = extract_live_browser_history(browser_name="auto", limit=limit)
                browser_data = analyze_browser_history(records=records, source_label=source_label)

        elif browser_source == "paste":
            raw_text = request.form.get("browser_raw", "").strip()
            records = parse_pasted_urls(raw_text)
            source_label = f"Pasted URLs / History ({len(records)} entries)"
            browser_data = analyze_browser_history(records=records, source_label=source_label)

        else:  # demo
            source_label = "Demo Phishing Campaign History Dataset"
            browser_data = analyze_browser_history("data/browser_history.csv", source_label=source_label)

        return render_template(
            "browser_result.html",
            browser_status=browser_data.get("status", "Unknown"),
            status_class=browser_data.get("status_class", "suspicious"),
            browser_risk=int(browser_data.get("browser_risk_score", 0)),
            browser_records=browser_data.get("records_analyzed", 0),
            browser_flagged_count=browser_data.get("flagged_count", 0),
            browser_high_risk_count=browser_data.get("high_risk_count", 0),
            browser_indicators=browser_data.get("suspicious_indicators", []),
            browser_source_label=browser_data.get("source", source_label),
            records_list=browser_data.get("records", []),
        )

    finally:
        if temp_file and hasattr(temp_file, "name") and os.path.exists(temp_file.name):
            try:
                os.unlink(temp_file.name)
            except Exception:
                pass


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=True)
