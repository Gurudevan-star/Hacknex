from __future__ import annotations

import csv
import datetime
import json
import os
import re
import shutil
import sqlite3
import tempfile
from pathlib import Path
from urllib.parse import urlparse

from app.utils import clamp, extract_domain, keyword_hits, suspicious_domain_score, suspicious_url_structure

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_HISTORY_FILE = PROJECT_ROOT / "data" / "browser_history.csv"


# ─────────────────────────────────────────────────────────────
#  Browser Path Discovery (Windows, macOS, Linux)
# ─────────────────────────────────────────────────────────────
def get_browser_search_paths() -> dict[str, dict]:
    """Returns candidate profile search paths for installed browsers."""
    local_appdata = os.environ.get("LOCALAPPDATA", "")
    appdata = os.environ.get("APPDATA", "")
    home = Path.home()

    candidates = {
        "chrome": {
            "name": "Google Chrome",
            "type": "chromium",
            "paths": [
                Path(local_appdata) / "Google" / "Chrome" / "User Data" / "Default" / "History",
                Path(local_appdata) / "Google" / "Chrome" / "User Data" / "Profile 1" / "History",
                Path(local_appdata) / "Google" / "Chrome" / "User Data" / "Profile 2" / "History",
                home / "Library" / "Application Support" / "Google" / "Chrome" / "Default" / "History",
                home / ".config" / "google-chrome" / "Default" / "History",
                home / ".config" / "chromium" / "Default" / "History",
            ],
        },
        "edge": {
            "name": "Microsoft Edge",
            "type": "chromium",
            "paths": [
                Path(local_appdata) / "Microsoft" / "Edge" / "User Data" / "Default" / "History",
                Path(local_appdata) / "Microsoft" / "Edge" / "User Data" / "Profile 1" / "History",
                Path(local_appdata) / "Microsoft" / "Edge" / "User Data" / "Profile 2" / "History",
                home / "Library" / "Application Support" / "Microsoft Edge" / "Default" / "History",
                home / ".config" / "microsoft-edge" / "Default" / "History",
            ],
        },
        "brave": {
            "name": "Brave Browser",
            "type": "chromium",
            "paths": [
                Path(local_appdata) / "BraveSoftware" / "Brave-Browser" / "User Data" / "Default" / "History",
                home / "Library" / "Application Support" / "BraveSoftware" / "Brave-Browser" / "Default" / "History",
                home / ".config" / "BraveSoftware" / "Brave-Browser" / "Default" / "History",
            ],
        },
        "firefox": {
            "name": "Mozilla Firefox",
            "type": "firefox",
            "patterns": [
                (Path(appdata) / "Mozilla" / "Firefox" / "Profiles", "*places.sqlite"),
                (home / "Library" / "Application Support" / "Firefox" / "Profiles", "*places.sqlite"),
                (home / ".mozilla" / "firefox", "*places.sqlite"),
            ],
        },
        "opera": {
            "name": "Opera / Opera GX",
            "type": "chromium",
            "paths": [
                Path(appdata) / "Opera Software" / "Opera Stable" / "History",
                Path(appdata) / "Opera Software" / "Opera GX Stable" / "History",
                home / "Library" / "Application Support" / "com.operasoftware.Opera" / "History",
                home / ".config" / "opera" / "History",
            ],
        },
    }
    return candidates


def detect_installed_browsers() -> list[dict]:
    """Detects available browser history databases on the local system."""
    browser_defs = get_browser_search_paths()
    detected = []

    for browser_id, info in browser_defs.items():
        found_path = None
        if "paths" in info:
            for candidate in info["paths"]:
                if candidate and candidate.exists() and candidate.is_file():
                    found_path = candidate
                    break
        elif "patterns" in info:
            for base_dir, pattern in info["patterns"]:
                if base_dir and base_dir.exists():
                    matches = list(base_dir.glob(f"**/{pattern}"))
                    if matches:
                        found_path = matches[0]
                        break

        detected.append({
            "id": browser_id,
            "name": info["name"],
            "available": bool(found_path),
            "path": str(found_path) if found_path else None,
            "type": info["type"],
        })

    return detected


# ─────────────────────────────────────────────────────────────
#  Timestamp Conversion Helpers
# ─────────────────────────────────────────────────────────────
def _convert_chromium_timestamp(microseconds: int | float | None) -> str:
    """Converts Chromium timestamp (microseconds since 1601-01-01 UTC) to readable string."""
    if not microseconds:
        return "N/A"
    try:
        dt = datetime.datetime(1601, 1, 1, tzinfo=datetime.timezone.utc) + datetime.timedelta(microseconds=int(microseconds))
        return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "N/A"


def _convert_firefox_timestamp(microseconds: int | float | None) -> str:
    """Converts Firefox timestamp (microseconds since 1970-01-01 UTC) to readable string."""
    if not microseconds:
        return "N/A"
    try:
        dt = datetime.datetime.fromtimestamp(microseconds / 1_000_000, tz=datetime.timezone.utc)
        return dt.astimezone().strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        return "N/A"


# ─────────────────────────────────────────────────────────────
#  Direct Browser SQLite Extractors
# ─────────────────────────────────────────────────────────────
def _extract_from_chromium_sqlite(sqlite_path: Path | str, limit: int | None = 200) -> list[dict]:
    """Safely extracts URL history from Chromium-based SQLite database file."""
    p = Path(sqlite_path)
    if not p.exists():
        return []

    temp_dir = tempfile.mkdtemp()
    temp_db = Path(temp_dir) / "history_copy.sqlite"

    try:
        shutil.copy2(p, temp_db)
        # Also copy WAL / SHM files if they exist to get latest history
        wal = p.with_name(p.name + "-wal")
        if wal.exists():
            shutil.copy2(wal, Path(temp_dir) / (temp_db.name + "-wal"))

        conn = sqlite3.connect(temp_db)
        cur = conn.cursor()

        query = (
            "SELECT url, title, visit_count, last_visit_time FROM urls "
            "WHERE url NOT LIKE 'chrome%' AND url NOT LIKE 'edge%' AND url NOT LIKE 'about:%' "
            "ORDER BY last_visit_time DESC"
        )
        if limit and limit > 0:
            query += f" LIMIT {int(limit)}"

        cur.execute(query)
        rows = cur.fetchall()
        conn.close()

        records = []
        for url, title, visits, ts in rows:
            if not url:
                continue
            records.append({
                "url": url,
                "title": (title or "").strip() or extract_domain(url),
                "timestamp": _convert_chromium_timestamp(ts),
                "visit_count": int(visits or 1),
            })
        return records
    except Exception:
        return []
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def _extract_from_firefox_sqlite(sqlite_path: Path | str, limit: int | None = 200) -> list[dict]:
    """Safely extracts URL history from Firefox places.sqlite database file."""
    p = Path(sqlite_path)
    if not p.exists():
        return []

    temp_dir = tempfile.mkdtemp()
    temp_db = Path(temp_dir) / "places_copy.sqlite"

    try:
        shutil.copy2(p, temp_db)
        wal = p.with_name(p.name + "-wal")
        if wal.exists():
            shutil.copy2(wal, Path(temp_dir) / (temp_db.name + "-wal"))

        conn = sqlite3.connect(temp_db)
        cur = conn.cursor()

        query = (
            "SELECT url, title, visit_count, last_visit_date FROM moz_places "
            "WHERE url NOT LIKE 'about:%' AND url NOT LIKE 'place:%' "
            "ORDER BY last_visit_date DESC"
        )
        if limit and limit > 0:
            query += f" LIMIT {int(limit)}"

        cur.execute(query)
        rows = cur.fetchall()
        conn.close()

        records = []
        for url, title, visits, ts in rows:
            if not url:
                continue
            records.append({
                "url": url,
                "title": (title or "").strip() or extract_domain(url),
                "timestamp": _convert_firefox_timestamp(ts),
                "visit_count": int(visits or 1),
            })
        return records
    except Exception:
        return []
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


def extract_live_browser_history(browser_name: str = "auto", limit: int | None = 200) -> tuple[list[dict], str]:
    """Extracts live browser history directly from installed browsers on the machine."""
    detected = detect_installed_browsers()
    target_browser = None

    if browser_name and browser_name.lower() != "auto":
        for b in detected:
            if b["id"] == browser_name.lower() and b["available"]:
                target_browser = b
                break

    if not target_browser:
        # Pick first available browser
        for b in detected:
            if b["available"]:
                target_browser = b
                break

    if not target_browser or not target_browser["path"]:
        return _default_history_records(), "Demo / Fallback Sample (No live browser detected)"

    source_label = f"Live {target_browser['name']} History"
    path = target_browser["path"]

    if target_browser["type"] == "firefox":
        records = _extract_from_firefox_sqlite(path, limit=limit)
    else:
        records = _extract_from_chromium_sqlite(path, limit=limit)

    if not records:
        return _default_history_records(), f"{source_label} (Empty history, fallback to demo sample)"

    return records, source_label


# ─────────────────────────────────────────────────────────────
#  File Parsers (SQLite, CSV, JSON, TXT, Pasted Text)
# ─────────────────────────────────────────────────────────────
def _default_history_records() -> list[dict]:
    return [
        {
            "url": "http://45.33.11.9/login.php",
            "title": "Account Verification & Banking Portal",
            "timestamp": "2026-08-01 10:15:00",
            "visit_count": 3,
        },
        {
            "url": "https://bank-security-update.example.com/verify",
            "title": "Urgent Bank Security Update Notice",
            "timestamp": "2026-08-01 11:00:00",
            "visit_count": 7,
        },
        {
            "url": "http://paypal-verification-secure-account.top/signin",
            "title": "PayPal Security Center - Confirm Password",
            "timestamp": "2026-08-01 11:20:00",
            "visit_count": 2,
        },
        {
            "url": "https://www.google.com/search?q=secure-login",
            "title": "Google Search",
            "timestamp": "2026-08-01 10:00:00",
            "visit_count": 5,
        },
        {
            "url": "https://www.microsoft.com",
            "title": "Microsoft Official Home",
            "timestamp": "2026-08-01 12:00:00",
            "visit_count": 2,
        },
    ]


def parse_pasted_urls(text: str) -> list[dict]:
    """Parses raw pasted URLs or history text into structured records."""
    if not text:
        return []
    records = []
    lines = text.strip().splitlines()
    for line in lines:
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        # Check if line has comma-separated fields: url,title,visits
        parts = [p.strip() for p in line.split(",") if p.strip()]
        if len(parts) >= 2 and parts[0].startswith(("http://", "https://", "www.")):
            url = parts[0]
            title = parts[1]
            visits = int(parts[2]) if len(parts) > 2 and parts[2].isdigit() else 1
            records.append({
                "url": url,
                "title": title,
                "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                "visit_count": visits,
            })
        else:
            # Extract URLs with regex
            found_urls = re.findall(r"https?://[^\s,;\"'<>]+", line)
            if found_urls:
                for u in found_urls:
                    records.append({
                        "url": u,
                        "title": extract_domain(u),
                        "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                        "visit_count": 1,
                    })
            elif line.startswith(("www.", "http://", "https://")) or "." in line:
                u = line if line.startswith(("http://", "https://")) else "http://" + line
                records.append({
                    "url": u,
                    "title": extract_domain(u),
                    "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
                    "visit_count": 1,
                })
    return records


def load_browser_history(path: str | Path | None = None, limit: int | None = 200) -> list[dict]:
    """Loads browser history from file path, SQLite DB, CSV, or default demo data."""
    if not path:
        return _default_history_records()

    target = Path(path)
    if not target.exists():
        return _default_history_records()

    # Try SQLite detection
    try:
        with open(target, "rb") as f:
            header = f.read(16)
        if header.startswith(b"SQLite format 3"):
            # Check if chromium or firefox
            res = _extract_from_chromium_sqlite(target, limit=limit)
            if not res:
                res = _extract_from_firefox_sqlite(target, limit=limit)
            return res or _default_history_records()
    except Exception:
        pass

    # Try CSV
    rows = []
    try:
        with open(target, "r", encoding="utf-8", errors="ignore", newline="") as csv_file:
            sample = csv_file.read(2048)
            csv_file.seek(0)
            if "," in sample or "\t" in sample:
                reader = csv.DictReader(csv_file)
                for row in reader:
                    url = row.get("url") or row.get("URL") or row.get("link") or ""
                    if not url:
                        continue
                    rows.append({
                        "url": url,
                        "title": row.get("title") or row.get("Title") or extract_domain(url),
                        "timestamp": row.get("timestamp") or row.get("date") or "N/A",
                        "visit_count": int(row.get("visit_count", 1) or 1),
                    })
    except Exception:
        pass

    # Try JSON
    if not rows:
        try:
            with open(target, "r", encoding="utf-8", errors="ignore") as f:
                data = json.load(f)
            if isinstance(data, list):
                for item in data:
                    if isinstance(item, dict) and "url" in item:
                        rows.append({
                            "url": item.get("url", ""),
                            "title": item.get("title", "") or extract_domain(item.get("url", "")),
                            "timestamp": item.get("timestamp", "N/A"),
                            "visit_count": int(item.get("visit_count", 1) or 1),
                        })
        except Exception:
            pass

    return rows or _default_history_records()


# ─────────────────────────────────────────────────────────────
#  Forensic Record & History Analysis
# ─────────────────────────────────────────────────────────────
def analyze_single_record(record: dict) -> dict:
    """Performs granular forensic checks on an individual browsing record."""
    url = record.get("url", "").strip()
    title = record.get("title", "").strip()
    parsed = urlparse(url if url.startswith(("http://", "https://")) else "http://" + url)
    domain = (parsed.netloc or "").lower()

    flags = []
    record_risk = 0

    if not url:
        return {"url": url, "title": title, "risk_level": "clean", "flags": [], "risk_score": 0}

    # 1. Unencrypted HTTP
    if parsed.scheme.lower() == "http":
        flags.append("Unencrypted HTTP protocol")
        record_risk += 25

    # 2. Direct IP Address in URL
    if re.search(r"^(?:[0-9]{1,3}\.){3}[0-9]{1,3}(?::[0-9]+)?$", domain) or re.search(r"https?://(?:[0-9]{1,3}\.){3}[0-9]{1,3}", url):
        flags.append("Direct IP address used instead of domain name")
        record_risk += 45

    # 3. Suspicious TLD (.top, .xyz, .tk, .ml, .ga, .cf, .gq, .buzz, .rest, .icu, .click)
    if re.search(r"\.(top|xyz|tk|ml|ga|cf|gq|buzz|rest|icu|click|work|fit|link|surf)$", domain):
        flags.append(f"Suspicious high-risk TLD detected: .{domain.split('.')[-1]}")
        record_risk += 35

    # 4. Suspicious URL Structure (multiple subdomains, hex, @ symbol)
    if "@" in url:
        flags.append("URL contains '@' symbol (Credential obfuscation attempt)")
        record_risk += 50
    if suspicious_url_structure(url):
        flags.append("Suspicious URL structure / pattern")
        record_risk += 20

    # 5. Phishing Keywords in URL / Title
    combined_text = f"{url} {title}"
    keywords = keyword_hits(combined_text)
    if keywords:
        flags.append(f"Phishing keywords found: {', '.join(keywords[:4])}")
        record_risk += min(len(keywords) * 15, 40)

    # 6. Domain Risk
    d_score = suspicious_domain_score(domain)
    if d_score >= 35:
        flags.append(f"Risky domain keyword combination ({domain})")
        record_risk += d_score // 2

    # 7. Non-standard ports
    if parsed.port and parsed.port not in (80, 443, 8080, 5000):
        flags.append(f"Non-standard network port ({parsed.port})")
        record_risk += 20

    # Classify Risk Level
    record_risk = min(record_risk, 100)
    if record_risk >= 60:
        risk_level = "high"
    elif record_risk >= 25:
        risk_level = "medium"
    elif record_risk > 0:
        risk_level = "low"
    else:
        risk_level = "clean"

    return {
        "url": url,
        "title": title or domain or url,
        "domain": domain,
        "timestamp": record.get("timestamp", "N/A"),
        "visit_count": record.get("visit_count", 1),
        "risk_level": risk_level,
        "risk_score": record_risk,
        "flags": flags,
    }


def analyze_browser_history(
    path: str | Path | None = None,
    records: list[dict] | None = None,
    source_label: str = "Browser Forensics Analysis",
) -> dict:
    """Comprehensive Browser Forensics analyzer - supports direct list or file paths."""
    if records is None:
        records = load_browser_history(path)

    if not records:
        records = _default_history_records()

    analyzed_records = []
    all_indicators = []
    total_record_risk = 0
    flagged_records_count = 0
    high_risk_count = 0

    for rec in records:
        analyzed = analyze_single_record(rec)
        analyzed_records.append(analyzed)
        if analyzed["flags"]:
            all_indicators.extend(analyzed["flags"])
            flagged_records_count += 1
            if analyzed["risk_level"] == "high":
                high_risk_count += 1
        total_record_risk += analyzed["risk_score"]

    num_records = max(len(analyzed_records), 1)
    
    # Calculate overall risk score: weighted combination of max risk, average risk, and flagged ratio
    max_risk = max((r["risk_score"] for r in analyzed_records), default=0)
    avg_risk = total_record_risk / num_records
    flagged_ratio = flagged_records_count / num_records

    composite_score = (
        max_risk * 0.45 +
        avg_risk * 0.35 +
        min(flagged_ratio * 100, 100) * 0.20
    )

    if not all_indicators:
        composite_score = 10
        all_indicators.append("No obvious malicious browser artifacts detected in history")

    final_score = int(clamp(composite_score, 0, 100))

    if final_score >= 60 or high_risk_count >= 1:
        status = "Phishing Campaign Detected"
        status_class = "phishing"
    elif final_score >= 25 or flagged_records_count >= 1:
        status = "Suspicious Activity"
        status_class = "suspicious"
    else:
        status = "Safe / Clean"
        status_class = "safe"

    return {
        "browser_risk_score": final_score,
        "risk_score": final_score,
        "records_analyzed": len(analyzed_records),
        "flagged_count": flagged_records_count,
        "high_risk_count": high_risk_count,
        "suspicious_indicators": sorted(set(all_indicators)),
        "reasons": sorted(set(all_indicators)),
        "status": status,
        "status_class": status_class,
        "source": source_label,
        "records": analyzed_records,
    }


if __name__ == "__main__":
    detected = detect_installed_browsers()
    print("Detected Browsers:", detected)
    records, label = extract_live_browser_history("auto", limit=5)
    print(f"\nExtracted from {label} ({len(records)} records)")
    result = analyze_browser_history(records=records, source_label=label)
    print(f"Risk Score: {result['browser_risk_score']}/100 - Status: {result['status']}")
    for ind in result["suspicious_indicators"]:
        print(f" - {ind}")
