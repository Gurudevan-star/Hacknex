from __future__ import annotations

from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[2]
REPORT_PATH = PROJECT_ROOT / "app" / "reports" / "forensic_report.html"


def generate_html_report(report_data):
    html = f"""
    <html>
      <head>
        <title>Forensic Investigation Report</title>
        <style>
          body {{ font-family: Arial; margin: 30px; background: #f5f7fb; color: #222; }}
          .card {{ background: white; border-radius: 10px; padding: 20px; margin-bottom: 20px; box-shadow: 0 2px 8px rgba(0,0,0,0.08); }}
          h1, h2 {{ color: #1d3557; }}
          .badge {{ background: #e63946; color: white; padding: 8px 16px; border-radius: 20px; display: inline-block; }}
        </style>
      </head>
      <body>
        <div class="card">
          <h1>AI-Based Browser and Email Forensics Report</h1>
          <div class="badge">Prediction: {report_data['prediction']}</div>
          <p><strong>Risk Score:</strong> {report_data['risk_score']}/100</p>
        </div>

        <div class="card">
          <h2>Reasons</h2>
          <ul>
            {''.join(f'<li>{reason}</li>' for reason in report_data.get('reasons', []))}
          </ul>
        </div>

        <div class="card">
          <h2>Evidence Summary</h2>
          <p><strong>Browser risk:</strong> {report_data.get('browser_risk_score', 0)}</p>
          <p><strong>Email risk:</strong> {report_data.get('email_risk_score', 0)}</p>
          <p><strong>Network risk:</strong> {report_data.get('network_risk_score', 0)}</p>
          <p><strong>Website risk:</strong> {report_data.get('website_risk_score', 0)}</p>
        </div>
      </body>
    </html>
    """
    REPORT_PATH.write_text(html, encoding="utf-8")
    return str(REPORT_PATH)


if __name__ == "__main__":
    generate_html_report({
        "prediction": "Phishing",
        "risk_score": 92,
        "reasons": ["SPF failed", "Suspicious URL", "Urgent phishing language"],
        "browser_risk_score": 88,
        "email_risk_score": 90,
        "network_risk_score": 50,
        "website_risk_score": 76,
    })
    print(REPORT_PATH)
