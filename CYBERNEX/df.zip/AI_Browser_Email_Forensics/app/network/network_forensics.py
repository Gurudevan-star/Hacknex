from __future__ import annotations

import csv
from pathlib import Path

from app.utils import clamp

PROJECT_ROOT = Path(__file__).resolve().parents[2]
DEFAULT_NETWORK_FILE = PROJECT_ROOT / "dataset" / "network_sample.csv"


def load_network_csv(path: str | Path | None = None):
    target = Path(path) if path else DEFAULT_NETWORK_FILE
    if not target.exists():
        return [
            {"timestamp": "2026-08-01 10:00:00", "src_ip": "192.168.1.10", "dst_ip": "45.33.11.9", "protocol": "HTTP", "host": "login-bank.example.com", "dns_query": "login-bank.example.com"},
            {"timestamp": "2026-08-01 10:05:00", "src_ip": "192.168.1.10", "dst_ip": "8.8.8.8", "protocol": "DNS", "host": "example.com", "dns_query": "example.com"},
            {"timestamp": "2026-08-01 10:23:00", "src_ip": "192.168.1.10", "dst_ip": "172.217.167.78", "protocol": "HTTPS", "host": "google.com", "dns_query": "google.com"},
        ]

    rows = []
    with open(target, "r", encoding="utf-8", newline="") as csv_file:
        reader = csv.DictReader(csv_file)
        for row in reader:
            rows.append({
                "timestamp": row.get("timestamp", ""),
                "src_ip": row.get("src_ip", ""),
                "dst_ip": row.get("dst_ip", ""),
                "protocol": row.get("protocol", ""),
                "host": row.get("host", ""),
                "dns_query": row.get("dns_query", ""),
            })
    return rows


def analyze_network_traffic(path: str | Path | None = None):
    flows = load_network_csv(path)
    reasons = []
    score = 0

    for flow in flows:
        protocol = (flow.get("protocol") or "").upper()
        host = (flow.get("host") or "").lower()
        dst_ip = flow.get("dst_ip", "")
        if protocol == "HTTP":
            reasons.append("Unencrypted HTTP traffic")
            score += 25
        if "login" in host or "verify" in host or "secure" in host:
            reasons.append("Suspicious host pattern")
            score += 20
        if dst_ip.startswith("45.") or dst_ip.startswith("46."):
            reasons.append("Destination IP matches suspicious range")
            score += 20
        if flow.get("dns_query", "").lower().endswith(".example.com"):
            reasons.append("Suspicious DNS lookup")
            score += 15

    if not reasons:
        reasons.append("No suspicious network activity detected")
        score = 10

    return {
        "risk_score": round(clamp(score / max(len(flows), 1) + 15, 0, 100), 2),
        "flows_analyzed": len(flows),
        "reasons": sorted(set(reasons)),
        "status": "suspicious" if score >= 60 else "safe",
    }


if __name__ == "__main__":
    print(analyze_network_traffic())
