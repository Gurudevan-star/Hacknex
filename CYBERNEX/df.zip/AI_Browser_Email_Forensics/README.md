# AI-Based Browser and Email Forensics Engine

This project is being developed as a cybersecurity academic project for phishing campaign detection using browser artifacts, email evidence, network telemetry, and AI/ML classification.

## Phase 1: Project setup and folder structure

This phase focuses on creating the base project structure and environment so the later forensic modules can be implemented cleanly and maintainably.

## Project structure

```text
AI_Browser_Email_Forensics/
├── app/
│   ├── __init__.py
│   ├── browser/
│   │   └── __init__.py
│   ├── email/
│   │   └── __init__.py
│   ├── nlp/
│   │   └── __init__.py
│   ├── network/
│   │   └── __init__.py
│   ├── website/
│   │   └── __init__.py
│   ├── ai/
│   │   └── __init__.py
│   └── reports/
│       └── __init__.py
├── dataset/
├── models/
├── screenshots/
├── tests/
├── .gitignore
├── requirements.txt
├── main.py
└── README.md
```

## Why this step matters

A modular structure keeps the project organized and makes it easier to:

- separate browser, email, network, and AI responsibilities,
- test each forensic module independently,
- keep reports and trained models in dedicated locations,
- collaborate as a team with clear ownership.

## How to run

From the project root:

```bash
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
python main.py
```

## Expected output

When the project is initialized successfully, the console should print a startup message confirming that the project structure is ready.

## Next step

After this setup is confirmed, the project will move to Phase 2: Browser Forensics.
