"""Generate a professional email forensics report to show to instructor."""

from pathlib import Path
import json
import sys
PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.append(str(PROJECT_ROOT))
REPORT_PATH = PROJECT_ROOT / "email_forensic_report.html"

from app.email.email_forensics import analyze_email_file


def generate_email_report_html(email_path):
    """Generate a professional HTML report for email forensics."""
    result = analyze_email_file(email_path)

    html = f"""
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Forensics Report</title>
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        body {{
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            padding: 20px;
            min-height: 100vh;
        }}
        .container {{
            max-width: 900px;
            margin: 0 auto;
            background: white;
            border-radius: 10px;
            box-shadow: 0 10px 40px rgba(0, 0, 0, 0.3);
            overflow: hidden;
        }}
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            text-align: center;
        }}
        .header h1 {{
            font-size: 28px;
            margin-bottom: 10px;
        }}
        .header p {{
            font-size: 14px;
            opacity: 0.9;
        }}
        .content {{
            padding: 30px;
        }}
        .section {{
            margin-bottom: 30px;
        }}
        .section h2 {{
            font-size: 20px;
            color: #333;
            border-bottom: 3px solid #667eea;
            padding-bottom: 10px;
            margin-bottom: 15px;
        }}
        .verdict {{
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: #f5f5f5;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }}
        .verdict-status {{
            font-size: 32px;
            font-weight: bold;
        }}
        .status-phishing {{
            color: #e74c3c;
        }}
        .status-suspicious {{
            color: #f39c12;
        }}
        .status-safe {{
            color: #27ae60;
        }}
        .risk-score {{
            text-align: center;
        }}
        .risk-score-value {{
            font-size: 48px;
            font-weight: bold;
            color: #667eea;
        }}
        .risk-score-label {{
            font-size: 14px;
            color: #666;
            margin-top: 5px;
        }}
        .email-headers {{
            background: #f9f9f9;
            padding: 15px;
            border-left: 4px solid #667eea;
            border-radius: 4px;
            font-family: 'Courier New', monospace;
            font-size: 13px;
            margin-bottom: 15px;
        }}
        .header-row {{
            margin-bottom: 10px;
            line-height: 1.6;
        }}
        .header-label {{
            font-weight: bold;
            color: #667eea;
            display: inline-block;
            width: 120px;
        }}
        .reasons-list {{
            list-style: none;
            padding: 0;
        }}
        .reasons-list li {{
            padding: 10px 15px;
            margin-bottom: 8px;
            background: #fee;
            border-left: 4px solid #e74c3c;
            border-radius: 4px;
            color: #333;
        }}
        .reasons-list li:before {{
            content: "[!] ";
            font-weight: bold;
            color: #e74c3c;
        }}
        .auth-note {{
            background: #fff3cd;
            border: 1px solid #ffc107;
            padding: 15px;
            border-radius: 8px;
            color: #856404;
            font-size: 13px;
            line-height: 1.6;
            margin-top: 20px;
        }}
        .urls-section {{
            background: #f5f5f5;
            padding: 15px;
            border-radius: 8px;
            font-family: 'Courier New', monospace;
            font-size: 12px;
            word-break: break-all;
        }}
        .footer {{
            background: #f9f9f9;
            padding: 20px;
            text-align: center;
            border-top: 1px solid #eee;
            font-size: 13px;
            color: #666;
        }}
        .badge {{
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            margin: 0 5px;
        }}
        .badge-fail {{
            background: #e74c3c;
            color: white;
        }}
        .badge-pass {{
            background: #27ae60;
            color: white;
        }}
        .badge-unknown {{
            background: #95a5a6;
            color: white;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Email Forensic Analysis Report</h1>
            <p>AI-Based Phishing Detection System</p>
        </div>

        <div class="content">
            <!-- Verdict Section -->
            <div class="section">
                <div class="verdict">
                    <div class="verdict-status status-{result['status'].lower()}">
                        {result['status'].upper()}
                    </div>
                    <div class="risk-score">
                        <div class="risk-score-value">{result['risk_score']}</div>
                        <div class="risk-score-label">RISK SCORE / 100</div>
                    </div>
                </div>
            </div>

            <!-- Email Headers Section -->
            <div class="section">
                <h2>Email Headers</h2>
                <div class="email-headers">
                    <div class="header-row">
                        <span class="header-label">From:</span>
                        <span>{result['from']}</span>
                    </div>
                    <div class="header-row">
                        <span class="header-label">To:</span>
                        <span>{result['to']}</span>
                    </div>
                    <div class="header-row">
                        <span class="header-label">Subject:</span>
                        <span>{result['subject']}</span>
                    </div>
                    <div class="header-row">
                        <span class="header-label">Reply-To:</span>
                        <span>{result['reply_to']}</span>
                    </div>
                    <div class="header-row">
                        <span class="header-label">Return-Path:</span>
                        <span>{result['return_path']}</span>
                    </div>
                    <div class="header-row">
                        <span class="header-label">Sender IP:</span>
                        <span>{result['sender_ip'] or 'Not found'}</span>
                    </div>
                </div>
            </div>

            <!-- Authentication Section -->
            <div class="section">
                <h2>Email Authentication</h2>
                <div style="padding: 15px; background: #f9f9f9; border-radius: 8px;">
                    <div style="margin-bottom: 10px;">
                        <strong>SPF:</strong> 
                        <span class="badge badge-{result['spf'].lower()}">{result['spf'].upper()}</span>
                    </div>
                    <div style="margin-bottom: 10px;">
                        <strong>DKIM:</strong> 
                        <span class="badge badge-{result['dkim'].lower()}">{result['dkim'].upper()}</span>
                    </div>
                    <div>
                        <strong>DMARC:</strong> 
                        <span class="badge badge-{result['dmarc'].lower()}">{result['dmarc'].upper()}</span>
                    </div>
                </div>
                <div class="auth-note">
                    <strong>Important Note:</strong> {result['auth_note']}
                </div>
            </div>

            <!-- URLs Found -->
            {'<div class="section">' + '<h2>URLs Detected</h2>' + '<div class="urls-section">' + ('<br>'.join(result['urls']) if result['urls'] else 'No URLs found') + '</div></div>' if result.get('urls') else ''}

            <!-- Red Flags Section -->
            <div class="section">
                <h2>Detected Phishing Indicators</h2>
                <ul class="reasons-list">
                    {''.join(f'<li>{reason}</li>' for reason in result['reasons'])}
                </ul>
            </div>

            <!-- Attachments Section -->
            {'<div class="section"><h2>Attachments</h2><div style="background: #f5f5f5; padding: 15px; border-radius: 8px;">' + ('<br>'.join(result['attachments']) if result.get('attachments') else 'No attachments found') + '</div></div>' if result.get('attachments') else '<div class="section"><h2>Attachments</h2><div style="background: #f5f5f5; padding: 15px; border-radius: 8px; color: #666;">No attachments found</div></div>'}

        </div>

        <div class="footer">
            <p>Generated by AI-Based Browser and Email Forensics Engine</p>
            <p>Educational Project - Cybersecurity</p>
        </div>
    </div>
</body>
</html>
"""
    
    REPORT_PATH.write_text(html, encoding="utf-8")
    return str(REPORT_PATH)


if __name__ == "__main__":
    import sys
    email_path = sys.argv[1] if len(sys.argv) > 1 else "data/sample_email.eml"
    report_file = generate_email_report_html(email_path)
    print(f"[+] Report generated: {report_file}")
    print(f"[+] Open in browser: file:///{Path(report_file).resolve()}")
