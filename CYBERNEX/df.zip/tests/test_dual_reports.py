from pathlib import Path
from app.db import create_case, delete_case, init_db
from app.reports.report_generator import (
    generate_community_report,
    generate_html_report,
    generate_technical_forensic_report,
)

def test_legacy_html_report():
    path_str = generate_html_report({
        "prediction": "Phishing",
        "risk_score": 85,
        "reasons": ["Urgency keywords", "SPF fail"],
    })
    p = Path(path_str)
    assert p.exists()
    content = p.read_text(encoding="utf-8")
    assert "AI-Based Browser and Email Forensics Report" in content

def test_technical_forensic_report_generation():
    init_db()
    case_id = "CASE-TEST-TECHREP"
    delete_case(case_id)
    create_case(case_id=case_id, incident_type="Phishing", incident_description="Technical report generation test")

    ai_assessment = {
        "prediction": "Phishing",
        "risk_score": 90,
        "model_probability": 0.95,
        "model_name": "RandomForest",
        "shap_available": True,
        "shap_baseline": 0.5,
        "shap_contributions": [
            {"feature": "url_risk", "value": 85, "shap_value": 0.18, "impact": "Increases Risk", "direction": "+"},
            {"feature": "https", "value": 0, "shap_value": 0.12, "impact": "Increases Risk", "direction": "+"},
        ],
        "rule_based_explanations": ["SPF authentication failed", "Urgency language detected"],
    }

    rep_path = generate_technical_forensic_report(case_id, ai_assessment)
    p = Path(rep_path)
    assert p.exists()
    html = p.read_text(encoding="utf-8")
    assert case_id in html
    assert "Live SHAP Feature Attribution (TreeExplainer)" in html
    assert "url_risk" in html
    assert "Cryptographic Hash Integrity" in html
    assert "Legal Admissibility Disclaimer" in html or "Admissibility" in html

def test_community_report_generation():
    init_db()
    case_id = "CASE-TEST-COMMREP"
    delete_case(case_id)
    create_case(case_id=case_id, incident_type="Suspicious email", incident_description="Community report test")

    ai_assessment = {
        "prediction": "Phishing",
        "risk_score": 88,
        "rule_based_explanations": ["SPF authentication failed (Sender IP not authorized)"],
    }

    rep_path = generate_community_report(case_id, ai_assessment)
    p = Path(rep_path)
    assert p.exists()
    html = p.read_text(encoding="utf-8")
    assert case_id in html
    assert "Community Cybercrime Evidence Assistance" in html or "Incident Assistance" in html
    assert "Recommended Protective Actions" in html
    assert "Evidence Preservation Certificate" in html
