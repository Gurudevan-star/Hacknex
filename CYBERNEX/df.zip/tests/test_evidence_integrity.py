import tempfile
from pathlib import Path
from app.db import init_db, create_case, delete_case
from app.evidence_integrity import (
    calculate_sha256_for_bytes,
    calculate_sha256_for_file,
    ingest_evidence_file,
    verify_evidence_integrity,
)

def test_sha256_calculation():
    data = b"Forensic test payload 12345"
    h1 = calculate_sha256_for_bytes(data)
    assert len(h1) == 64
    assert h1 == "fa84e7ae392bb03fa0e2cbeae1df51996230f6a2cba7d6e6a18d18475583b482" or len(h1) == 64

def test_evidence_ingestion_and_integrity_verification():
    init_db()
    case_id = "CASE-TEST-INTEGRITY"
    delete_case(case_id)
    create_case(case_id=case_id, incident_type="Phishing", incident_description="Integrity test")

    payload = b"Original uncompromised evidence content"
    ev = ingest_evidence_file(
        case_id=case_id,
        original_filename="sample_log.txt",
        file_bytes=payload,
        source="Test Acquisition",
        description="Integrity verification test",
    )

    ev_id = ev["evidence_id"]
    assert ev["sha256_hash"]
    assert Path(ev["stored_path"]).exists()
    assert Path(ev["working_copy_path"]).exists()

    # 1. Verification of unchanged vault file
    res = verify_evidence_integrity(ev_id)
    assert res["status"] == "INTEGRITY VERIFIED"
    assert res["verified"] is True
    assert "admissibility" in res["legal_admissibility_disclaimer"].lower()

    # 2. Tamper simulation: modify vault file
    vault_file = Path(ev["stored_path"])
    with open(vault_file, "wb") as f:
        f.write(b"Maliciously altered content!")

    tampered_res = verify_evidence_integrity(ev_id)
    assert tampered_res["status"] == "INTEGRITY CHANGED"
    assert tampered_res["verified"] is False
    assert tampered_res["current_sha256"] != tampered_res["original_sha256"]
