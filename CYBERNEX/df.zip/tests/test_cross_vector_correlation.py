from app.correlation_engine import run_cross_artifact_correlation
from app.db import (
    add_normalized_event,
    create_case,
    delete_case,
    delete_correlations,
    delete_normalized_events,
    init_db,
    list_correlations,
)

def test_cross_vector_correlation_engine():
    init_db()
    case_id = "CASE-TEST-CORR"
    delete_case(case_id)
    create_case(case_id=case_id, incident_type="Phishing", incident_description="Correlation test")

    # 1. Email extracted URL and domain
    add_normalized_event(
        event_id="EVT-001",
        case_id=case_id,
        evidence_id="EV-EMAIL",
        event_type="EMAIL_RECEIVED",
        timestamp="2026-08-01 10:00:00 UTC",
        source="Email Forensics",
        url="https://secure-bank-login.net/auth",
        domain="secure-bank-login.net",
        description="Phishing lure email",
    )
    add_normalized_event(
        event_id="EVT-002",
        case_id=case_id,
        evidence_id="EV-EMAIL",
        event_type="URL_EXTRACTED",
        timestamp="2026-08-01 10:00:00 UTC",
        source="Email Forensics",
        url="https://secure-bank-login.net/auth",
        domain="secure-bank-login.net",
        description="Extracted lure URL",
    )

    # 2. Browser visited URL (2 minutes later)
    add_normalized_event(
        event_id="EVT-003",
        case_id=case_id,
        evidence_id="EV-BROWSER",
        event_type="URL_VISITED",
        timestamp="2026-08-01 10:02:00 UTC",
        source="Browser Forensics",
        url="https://secure-bank-login.net/auth",
        domain="secure-bank-login.net",
        description="Visited lure URL in browser",
    )

    # 3. DNS query and network connection
    add_normalized_event(
        event_id="EVT-004",
        case_id=case_id,
        evidence_id="EV-NET",
        event_type="DNS_QUERY",
        timestamp="2026-08-01 10:01:59 UTC",
        source="NetFlow",
        domain="secure-bank-login.net",
        description="DNS query resolved host",
    )
    add_normalized_event(
        event_id="EVT-005",
        case_id=case_id,
        evidence_id="EV-NET",
        event_type="NETWORK_CONNECTION",
        timestamp="2026-08-01 10:02:00 UTC",
        source="NetFlow",
        ip="45.33.11.9",
        domain="secure-bank-login.net",
        description="HTTP connection established",
    )

    correlations = run_cross_artifact_correlation(case_id, time_window_seconds=900)
    rule_names = [c["rule_name"] for c in correlations]

    assert "URL Correlation" in rule_names
    assert "Domain Correlation" in rule_names
    assert "DNS-Network Correlation" in rule_names
    assert "Temporal Correlation" in rule_names

    # Check that each correlation carries required evidence IDs and reasons
    for corr in correlations:
        assert len(corr["evidence_ids"]) >= 1
        assert corr["reason"]
        assert corr["matching_entity"]
