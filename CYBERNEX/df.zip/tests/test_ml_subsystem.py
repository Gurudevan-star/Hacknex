from __future__ import annotations

import numpy as np
import pandas as pd
import pytest

from ml.ablation import ABLATION_CONFIGS, run_ablation_experiment
from ml.dataset_audit import audit_dataset
from ml.explain import explain_case_prediction, verify_shap_reconstruction
from ml.feature_dictionary import (
    FEATURE_DICTIONARY,
    FEATURE_NAMES,
    get_feature_dictionary,
    get_vector_feature_mapping,
)
from ml.metrics import calculate_metrics
from ml.model_comparison import run_model_comparison
from ml.model_registry import ModelRegistry
from ml.preprocessing import ForensicPreprocessor, normalize_auth_status, prepare_benchmark_splits
from ml.train import train_all_models


def test_feature_validation_and_dictionary():
    """Validates the 11 canonical features, dictionary metadata, and vector mappings."""
    assert len(FEATURE_NAMES) == 11
    dict_meta = get_feature_dictionary()
    assert len(dict_meta) == 11

    expected_features = [
        "https",
        "spf_result",
        "dkim_result",
        "dmarc_result",
        "url_risk",
        "domain_risk",
        "number_of_suspicious_words",
        "reply_to_mismatch",
        "sender_domain_mismatch",
        "suspicious_network_indicator",
        "browser_risk_score",
    ]
    for feat in expected_features:
        assert feat in dict_meta
        assert "allowed_range" in dict_meta[feat]
        assert "source_module" in dict_meta[feat]
        assert "calculation_methodology" in dict_meta[feat]
        assert "dfir_caveat" in dict_meta[feat]

    vector_map = get_vector_feature_mapping()
    assert "Email" in vector_map
    assert "Browser" in vector_map
    assert "Network" in vector_map
    assert "Website/NLP" in vector_map


def test_auth_status_normalization():
    """Verifies that authentication strings normalize cleanly according to specification."""
    assert normalize_auth_status("pass") == 1
    assert normalize_auth_status("PASS") == 1
    assert normalize_auth_status(1) == 1
    assert normalize_auth_status(True) == 1
    assert normalize_auth_status("fail") == 0
    assert normalize_auth_status("softfail") == 0
    assert normalize_auth_status("none") == 0
    assert normalize_auth_status("temperror") == 0
    assert normalize_auth_status("unknown") == 0
    assert normalize_auth_status(None) == 0


def test_metric_calculations_mathematical_precision():
    """Tests metric definitions with known expected outputs for precision, recall, FPR, FNR."""
    # Constructed test case:
    # 40 TN (y=0, pred=0)
    # 10 FP (y=0, pred=1)
    #  5 FN (y=1, pred=0)
    # 45 TP (y=1, pred=1)
    # Total = 100 samples
    y_true = [0] * 50 + [1] * 50
    y_pred = ([0] * 40 + [1] * 10) + ([0] * 5 + [1] * 45)

    metrics = calculate_metrics(y_true, y_pred)

    assert metrics["accuracy"] == 0.85
    # FPR = FP / (FP + TN) = 10 / 50 = 0.20
    assert metrics["fpr"] == 0.20
    # FNR = FN / (FN + TP) = 5 / 50 = 0.10
    assert metrics["fnr"] == 0.10
    # Precision = TP / (TP + FP) = 45 / 55 = 0.8182
    assert round(metrics["precision"], 4) == 0.8182
    # Recall = TP / (TP + FN) = 45 / 50 = 0.9000
    assert metrics["recall"] == 0.90
    # F1 = 2 * (0.81818 * 0.9) / (0.81818 + 0.9) = 0.8571
    assert round(metrics["f1"], 4) == 0.8571
    assert metrics["confusion_matrix"]["tn"] == 40
    assert metrics["confusion_matrix"]["fp"] == 10
    assert metrics["confusion_matrix"]["fn"] == 5
    assert metrics["confusion_matrix"]["tp"] == 45


def test_forensic_preprocessor_leakage_and_ordering():
    """Verifies that preprocessor enforces schema, avoids data leakage, and handles scaling."""
    preprocessor = ForensicPreprocessor(FEATURE_NAMES)
    with pytest.raises(RuntimeError):
        preprocessor.transform({"https": 1})

    # Fit on synthetic training set
    df_train = pd.DataFrame([
        {f: 1.0 if "result" in f or "mismatch" in f or f in ["https", "suspicious_network_indicator"] else 50.0 for f in FEATURE_NAMES}
    ])
    preprocessor.fit(df_train)
    assert preprocessor.is_fitted is True

    # Transform unscaled
    out_unscaled = preprocessor.transform(df_train, scale=False)
    assert list(out_unscaled.columns) == FEATURE_NAMES
    assert out_unscaled["url_risk"].iloc[0] == 50.0

    # Scrambled input feature ordering should be normalized to canonical ordering
    scrambled = {
        "browser_risk_score": 75.0,
        "https": 0,
        "url_risk": 90,
        "spf_result": "pass",
    }
    out_scrambled = preprocessor.transform(scrambled, scale=False)
    assert list(out_scrambled.columns) == FEATURE_NAMES
    assert out_scrambled["spf_result"].iloc[0] == 1.0  # Normalized string 'pass'
    assert out_scrambled["https"].iloc[0] == 0.0
    assert out_scrambled["url_risk"].iloc[0] == 90.0
    assert out_scrambled["browser_risk_score"].iloc[0] == 75.0


def test_dataset_audit_unmodified_provenance():
    """Audits the genuine benchmark dataset file without assumptions."""
    audit = audit_dataset()
    assert audit["status"] == "VALID"
    assert audit["num_rows"] == 200
    assert audit["num_columns"] == 14
    assert audit["total_missing_values"] == 0
    assert audit["total_duplicate_rows"] == 0
    assert audit["label_distribution"]["0"] == 100
    assert audit["label_distribution"]["1"] == 100
    assert len(audit["sha256"]) == 64


def test_prepare_benchmark_splits_no_leakage():
    """Verifies stratified split and confirms zero overlap between train and test feature rows."""
    X_train, X_test, y_train, y_test, preproc, meta = prepare_benchmark_splits(test_size=0.3, random_state=42)
    assert len(X_train) == 140
    assert len(X_test) == 60
    assert len(y_train) == 140
    assert len(y_test) == 60
    assert meta["feature_overlap_count"] == 0
    assert meta["leakage_check_passed"] is True


def test_model_training_and_registry_retrieval():
    """Verifies that all three models train, evaluate, and register with metadata."""
    res = train_all_models()
    assert "logistic_regression" in res["models"]
    assert "random_forest" in res["models"]
    assert "xgboost" in res["models"]

    reg = ModelRegistry()
    rf_pkg = reg.get_model("random_forest")
    assert rf_pkg.model_name == "Random Forest Classifier (100 Trees Baseline)"
    assert rf_pkg.metadata["hyperparameters"]["n_estimators"] == 100

    lr_pkg = reg.get_model("logistic_regression")
    assert lr_pkg.metadata["uses_scaled_features"] is True

    xgb_pkg = reg.get_model("xgboost")
    assert xgb_pkg.model_name == "XGBoost Classifier (Gradient Boosted Trees)"


def test_shap_mathematical_reconstruction_random_forest():
    """Verifies exact additive property: f(x) = phi_0 + sum(phi_i) on Random Forest."""
    sample = {
        "https": 0,
        "spf_result": 0,
        "dkim_result": 0,
        "dmarc_result": 0,
        "url_risk": 90,
        "domain_risk": 85,
        "number_of_suspicious_words": 6,
        "reply_to_mismatch": 1,
        "sender_domain_mismatch": 1,
        "suspicious_network_indicator": 1,
        "browser_risk_score": 88.0,
    }
    exp = explain_case_prediction(sample, model_type="random_forest")
    assert exp["shap_available"] is True
    assert exp["reconstruction_verified"] is True
    assert exp["reconstruction_discrepancy"] < 1e-3
    assert len(exp["shap_contributions"]) == 11

    # Check non-fabrication: individual directions and statements
    for item in exp["shap_contributions"]:
        assert "feature" in item
        assert "shap_value" in item
        assert "explanation_statement" in item
        assert "caused" not in item["explanation_statement"]  # No false causality assertion


def test_shap_mathematical_reconstruction_xgboost():
    """Verifies exact additive property on XGBoost model."""
    sample = {
        "https": 1,
        "spf_result": 1,
        "dkim_result": 1,
        "dmarc_result": 1,
        "url_risk": 10,
        "domain_risk": 15,
        "number_of_suspicious_words": 1,
        "reply_to_mismatch": 0,
        "sender_domain_mismatch": 0,
        "suspicious_network_indicator": 0,
        "browser_risk_score": 12.0,
    }
    exp = explain_case_prediction(sample, model_type="xgboost")
    assert exp["shap_available"] is True
    assert exp["reconstruction_verified"] is True
    assert exp["reconstruction_discrepancy"] < 1e-3


def test_model_comparison_execution():
    """Verifies model comparison runs with actual predictions and data-driven selection."""
    comp = run_model_comparison()
    assert "comparison_table" in comp
    assert len(comp["comparison_table"]) == 4  # Dummy, LR, RF, XGB
    assert comp["primary_metric"] == "F1-score"
    assert "selection_verdict" in comp

    for row in comp["comparison_table"]:
        if row["status"] == "EVALUATED":
            assert row["accuracy"] is not None
            assert row["precision"] is not None
            assert row["recall"] is not None
            assert row["f1"] is not None


def test_ablation_study_execution():
    """Verifies vector ablation study evaluates reduced feature subsets and computes delta-F1."""
    res = run_ablation_experiment()
    assert res["executed"] is True
    assert len(res["table"]) >= 5

    configs = [r["configuration"] for r in res["table"]]
    assert any("Full Model" in c for c in configs)
    assert any("No Email" in c for c in configs)
    assert any("No Browser" in c for c in configs)
    assert any("No Network" in c for c in configs)
    assert any("No Website/NLP" in c for c in configs)

    for row in res["table"]:
        assert 0.0 <= row["f1"] <= 1.0
        assert "delta_f1_vs_full" in row
        assert "confusion_matrix" in row
