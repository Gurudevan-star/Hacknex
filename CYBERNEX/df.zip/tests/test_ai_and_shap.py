from app.ai.phishing_model import explain_prediction, predict_class

def test_ai_prediction_bounds():
    features = {
        "https": 1,
        "spf_result": 1,
        "dkim_result": 1,
        "dmarc_result": 1,
        "url_risk": 5,
        "domain_risk": 5,
        "number_of_suspicious_words": 0,
        "reply_to_mismatch": 0,
        "sender_domain_mismatch": 0,
        "suspicious_network_indicator": 0,
        "browser_risk_score": 5.0,
    }
    pred = predict_class(features)
    assert pred["prediction"] in {"Safe", "Suspicious", "Phishing"}
    assert 0 <= pred["risk_score"] <= 100
    assert 0.0 <= pred["probability"] <= 1.0

def test_live_shap_tree_explainer():
    features = {
        "https": 0,
        "spf_result": 0,
        "dkim_result": 0,
        "dmarc_result": 0,
        "url_risk": 90,
        "domain_risk": 85,
        "number_of_suspicious_words": 7,
        "reply_to_mismatch": 1,
        "sender_domain_mismatch": 1,
        "suspicious_network_indicator": 1,
        "browser_risk_score": 92.0,
    }
    exp = explain_prediction(features)
    assert exp["shap_available"] is True
    assert exp["prediction"] == "Phishing"
    assert exp["risk_score"] >= 80
    assert len(exp["shap_contributions"]) == 11

    # Verify SHAP fields
    for item in exp["shap_contributions"]:
        assert "feature" in item
        assert "value" in item
        assert "shap_value" in item
        assert isinstance(item["shap_value"], float)
        assert item["direction"] in {"+", "-", "="}
        assert item["impact"] in {"Increases Risk", "Decreases Risk", "Neutral"}

    # Verify rule-based explanations exist alongside SHAP
    assert len(exp["rule_based_explanations"]) >= 1
    assert any("SPF" in r for r in exp["rule_based_explanations"])
