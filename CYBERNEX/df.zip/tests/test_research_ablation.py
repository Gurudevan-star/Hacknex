from app.research_evaluation import (
    get_ablation_results,
    get_dataset_metadata,
    load_benchmark_dataset,
    run_ablation_study,
)

def test_benchmark_dataset_integrity():
    df = load_benchmark_dataset()
    assert len(df) == 200
    assert (df["label"] == 0).sum() == 100
    assert (df["label"] == 1).sum() == 100

    meta = get_dataset_metadata()
    assert meta["total_samples"] == 200
    assert len(meta["features_list"]) == 11

def test_ablation_study_execution_and_metrics():
    results = run_ablation_study()
    assert results["executed"] is True
    assert len(results["table"]) == 6

    configs = [r["configuration"] for r in results["table"]]
    assert any("Full Model" in c for c in configs)
    assert any("Without Email" in c for c in configs)
    assert any("Without Browser" in c for c in configs)
    assert any("Without URL" in c for c in configs)
    assert any("Without Network" in c for c in configs)
    assert any("Without NLP" in c for c in configs)

    for row in results["table"]:
        assert 0.0 <= row["f1"] <= 1.0
        assert 0.0 <= row["precision"] <= 1.0
        assert 0.0 <= row["recall"] <= 1.0
        assert 0.0 <= row["roc_auc"] <= 1.0
        assert 0.0 <= row["fpr"] <= 1.0
        assert 0.0 <= row["fnr"] <= 1.0
        assert "confusion_matrix" in row
        cm = row["confusion_matrix"]
        assert cm["tn"] + cm["fp"] + cm["fn"] + cm["tp"] == 60  # 30% of 200
