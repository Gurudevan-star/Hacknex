from __future__ import annotations

import re
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ANDROID_ROOT = PROJECT_ROOT / "cybersafe_android"


def test_android_project_structure_exists():
    """Verifies that all required Android project configuration and source files exist."""
    assert ANDROID_ROOT.exists(), "cybersafe_android root directory must exist"
    assert (ANDROID_ROOT / "settings.gradle.kts").exists()
    assert (ANDROID_ROOT / "build.gradle.kts").exists()
    assert (ANDROID_ROOT / "gradle.properties").exists()
    assert (ANDROID_ROOT / "gradlew").exists()
    assert (ANDROID_ROOT / "gradlew.bat").exists()
    assert (ANDROID_ROOT / "README.md").exists()
    assert (ANDROID_ROOT / "app" / "build.gradle.kts").exists()
    assert (ANDROID_ROOT / "app" / "proguard-rules.pro").exists()


def test_android_manifest_and_permissions():
    """Verifies that AndroidManifest.xml exists and requests zero invasive permissions."""
    manifest_path = ANDROID_ROOT / "app" / "src" / "main" / "AndroidManifest.xml"
    assert manifest_path.exists()
    content = manifest_path.read_text(encoding="utf-8")

    # Verify no invasive permissions are requested
    invasive_permissions = [
        "READ_SMS",
        "RECEIVE_SMS",
        "READ_CONTACTS",
        "READ_CALL_LOG",
        "ACCESS_FINE_LOCATION",
        "CAMERA",
        "BIND_ACCESSIBILITY_SERVICE",
    ]
    for perm in invasive_permissions:
        assert perm not in content, f"Invasive permission {perm} must not be present in AndroidManifest.xml"

    assert "com.cybersafe.forensics.MainActivity" in content or "MainActivity" in content
    assert "CyberSafeApp" in content


def test_android_core_source_files_exist():
    """Verifies that all Kotlin data models, Room DAO, analysis rules, ViewModel, and screens exist."""
    src_main = ANDROID_ROOT / "app" / "src" / "main" / "java" / "com" / "cybersafe" / "forensics"

    expected_files = [
        # Root
        src_main / "CyberSafeApp.kt",
        src_main / "MainActivity.kt",
        # Data
        src_main / "data" / "model" / "RiskLevel.kt",
        src_main / "data" / "model" / "FindingIndicator.kt",
        src_main / "data" / "model" / "SafeNextStep.kt",
        src_main / "data" / "model" / "ScanType.kt",
        src_main / "data" / "model" / "AnalysisResult.kt",
        src_main / "data" / "local" / "HistoryEntity.kt",
        src_main / "data" / "local" / "HistoryDao.kt",
        src_main / "data" / "local" / "CyberSafeDatabase.kt",
        src_main / "data" / "repository" / "HistoryRepository.kt",
        src_main / "data" / "repository" / "AnalysisRepository.kt",
        # Analysis
        src_main / "analysis" / "InputValidator.kt",
        src_main / "analysis" / "UrlAnalysisRule.kt",
        src_main / "analysis" / "MessageAnalysisRule.kt",
        src_main / "analysis" / "LocalAnalysisEngine.kt",
        # UI
        src_main / "ui" / "navigation" / "NavRoutes.kt",
        src_main / "ui" / "theme" / "Color.kt",
        src_main / "ui" / "theme" / "Type.kt",
        src_main / "ui" / "theme" / "Theme.kt",
        src_main / "ui" / "viewmodel" / "CyberSafeUiState.kt",
        src_main / "ui" / "viewmodel" / "CyberSafeViewModel.kt",
        src_main / "ui" / "screens" / "HomeScreen.kt",
        src_main / "ui" / "screens" / "AnalysisScreen.kt",
        src_main / "ui" / "screens" / "ResultsScreen.kt",
        src_main / "ui" / "screens" / "HistoryScreen.kt",
        src_main / "ui" / "screens" / "SafetyTipsScreen.kt",
        src_main / "ui" / "screens" / "SettingsPrivacyScreen.kt",
    ]

    for f in expected_files:
        assert f.exists(), f"Expected Android source file missing: {f}"


def test_android_unit_test_files_exist():
    """Verifies that all automated unit test files exist for the Android application."""
    test_dir = ANDROID_ROOT / "app" / "src" / "test" / "java" / "com" / "cybersafe" / "forensics"

    expected_tests = [
        test_dir / "UrlAnalysisTest.kt",
        test_dir / "MessageAnalysisTest.kt",
        test_dir / "InputValidationTest.kt",
        test_dir / "RiskEvaluationTest.kt",
        test_dir / "PrivacySanitizationTest.kt",
    ]

    for t in expected_tests:
        assert t.exists(), f"Expected Android unit test file missing: {t}"


def test_android_rule_contract_consistency_with_python():
    """
    Verifies that key deterministic rules implemented in Kotlin mirror
    the core behavioral logic of the Python forensic engine.
    """
    url_rule_code = (
        ANDROID_ROOT / "app" / "src" / "main" / "java" / "com" / "cybersafe" / "forensics" / "analysis" / "UrlAnalysisRule.kt"
    ).read_text(encoding="utf-8")

    message_rule_code = (
        ANDROID_ROOT / "app" / "src" / "main" / "java" / "com" / "cybersafe" / "forensics" / "analysis" / "MessageAnalysisRule.kt"
    ).read_text(encoding="utf-8")

    # Verify IP host detection rule
    assert "RULE_IP_HOST" in url_rule_code
    assert "RULE_EXCESSIVE_SUBDOMAINS" in url_rule_code
    assert "RULE_SUSPICIOUS_TLD" in url_rule_code
    assert "RULE_CREDENTIAL_PATH" in url_rule_code
    assert "RULE_HTTP_UNENCRYPTED" in url_rule_code

    # Verify message rules
    assert "RULE_SOCIAL_URGENCY" in message_rule_code
    assert "RULE_CREDENTIAL_SOLICITATION" in message_rule_code
    assert "RULE_IMPERSONATION_AUTHORITY" in message_rule_code
    assert "RULE_PAYMENT_COERCION" in message_rule_code
