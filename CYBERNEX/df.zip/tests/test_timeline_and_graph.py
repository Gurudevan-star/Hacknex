from app.db import (
    add_evidence,
    add_normalized_event,
    create_case,
    delete_case,
    init_db,
)
from app.evidence_graph import build_evidence_relationship_graph
from app.timeline_generator import generate_incident_timeline

def test_timeline_sorting_and_unanchored_handling():
    init_db()
    case_id = "CASE-TEST-TIMELINE"
    delete_case(case_id)
    create_case(case_id=case_id, incident_type="Phishing")

    # Add events out of order, plus one with missing timestamp
    add_normalized_event(
        event_id="EVT-T3",
        case_id=case_id,
        evidence_id="EV-03",
        event_type="NETWORK_CONNECTION",
        timestamp="2026-08-01 10:15:00 UTC",
        source="Network",
        description="Event 3",
    )
    add_normalized_event(
        event_id="EVT-T1",
        case_id=case_id,
        evidence_id="EV-01",
        event_type="EMAIL_RECEIVED",
        timestamp="2026-08-01 10:00:00 UTC",
        source="Email",
        description="Event 1",
    )
    add_normalized_event(
        event_id="EVT-T2",
        case_id=case_id,
        evidence_id="EV-02",
        event_type="URL_VISITED",
        timestamp="2026-08-01 10:05:00 UTC",
        source="Browser",
        description="Event 2",
    )
    add_normalized_event(
        event_id="EVT-UNANCHORED",
        case_id=case_id,
        evidence_id="EV-01",
        event_type="SUSPICIOUS_LANGUAGE",
        timestamp="Timestamp unavailable",
        source="NLP",
        description="Urgency lure without header time",
    )

    timeline = generate_incident_timeline(case_id)
    assert timeline["anchored_count"] == 3
    assert timeline["unanchored_count"] == 1

    # Verify strict chronological sorting of anchored events
    anchored = timeline["anchored_events"]
    assert anchored[0]["event_id"] == "EVT-T1"
    assert anchored[1]["event_id"] == "EVT-T2"
    assert anchored[2]["event_id"] == "EVT-T3"

    # Verify unanchored segregation
    assert timeline["unanchored_events"][0]["event_id"] == "EVT-UNANCHORED"
    assert timeline["unanchored_events"][0]["timestamp"] == "Timestamp unavailable"

def test_evidence_graph_structure():
    case_id = "CASE-TEST-TIMELINE"
    graph = build_evidence_relationship_graph(case_id)
    assert graph["total_nodes"] >= 1
    assert any(n["type"] == "case" for n in graph["nodes"])
