import pytest
from app.dashboard import app


@pytest.fixture
def client():
    app.config['TESTING'] = True
    with app.test_client() as client:
        yield client


def test_index_page_structure(client):
    res = client.get('/')
    assert res.status_code == 200
    assert b'CYBER FORENSICS INVESTIGATION WORKSTATION' in res.data
    assert b'theme-toggle-btn' in res.data
    # Verify Demo tabs are removed from UI
    assert b'Curated Threat Benchmark Dataset' not in res.data
    assert b'Demo Threat Telemetry' not in res.data
    # Verify Real Ingestion tabs exist
    assert b'Active Browser Session Extraction' in res.data
    assert b'Evidence File Ingestion' in res.data
    assert b'Raw RFC822 Header Ingestion' in res.data
    assert b'Direct Workstation Extraction' in res.data
    assert b'Ingest History SQLite / CSV' in res.data


def test_email_raw_paste_analysis(client):
    raw_header = (
        "From: alert@fake-bank.com\n"
        "To: victim@company.com\n"
        "Subject: Urgent Security Warning\n"
        "Authentication-Results: spf=fail; dkim=fail; dmarc=fail\n\n"
        "Please visit: http://phishing-site.test/login"
    )
    res = client.post('/analyze-email', data={'consent': 'yes', 'email_source': 'paste', 'email_raw': raw_header})
    assert res.status_code == 200
    assert b'RFC822 FORENSIC EVIDENCE DOSSIER' in res.data
    assert b'theme-toggle-btn' in res.data


def test_browser_paste_analysis(client):
    urls = "http://45.33.11.9/login.php\nhttps://example-test.com"
    res = client.post('/analyze-browser', data={'consent': 'yes', 'browser_source': 'paste', 'browser_raw': urls})
    assert res.status_code == 200
    assert b'BROWSER TELEMETRY & ARTIFACT REPORT' in res.data
    assert b'theme-toggle-btn' in res.data


def test_url_scan_analysis(client, monkeypatch):
    class MockResponse:
        status_code = 200
        text = "<html><head><title>Test Page</title></head><body>Login: <input name='pass' type='password'></body></html>"
    
    import requests
    monkeypatch.setattr(requests, "get", lambda *args, **kwargs: MockResponse())

    res = client.post('/scan-url', data={'scan_url': 'http://45.33.11.9/login.php'})
    assert res.status_code == 200
    assert b'LIVE URL THREAT INTELLIGENCE DOSSIER' in res.data
    assert b'theme-toggle-btn' in res.data
