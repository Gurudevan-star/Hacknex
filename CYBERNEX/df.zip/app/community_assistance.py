from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.db import (
    add_community_activity,
    create_case,
    get_case,
    list_community_activities,
)
from app.evidence_integrity import ingest_evidence_file

TECHNICAL_TO_PLAIN_MAP = [
    (r"spf authentication failed|spf=fail", "The email sender claimed to represent an organization, but was actually sent from an unauthorized computer."),
    (r"spf verification passed|spf=pass", "The sending server was verified as an authorized email transmitter for this domain."),
    (r"dkim signature validation failed|dkim=fail", "The message's digital signature was invalid, indicating the email text may have been modified in transit."),
    (r"dkim cryptographic signature verified|dkim=pass", "The email's digital signature confirms the message was signed by the official domain owner."),
    (r"dmarc policy alignment failed|dmarc=fail", "The email's domain authentication did not pass the expected security policy verification."),
    (r"dmarc alignment verified|dmarc=pass", "The email complies with the domain's strict authentication and alignment policies."),
    (r"reply-to address points to a different domain|reply-to mismatch", "If you reply to this email, your reply will be secretly routed to a completely different email address than the sender shown."),
    (r"sender / reply-to domain mismatch", "The address shown on the email header differs from the address configured to receive responses."),
    (r"website uses http instead of https", "The website does not use secure encryption, meaning any entered information could be intercepted."),
    (r"login form detected", "The website asks you to enter your username or password."),
    (r"suspicious url structure|matches phishing lure", "The website address contains deceptive wording designed to resemble a legitimate service."),
    (r"originating mail server ip.*suspicious subnet", "The server sending this email originates from a network range known for hosting malicious campaigns."),
    (r"urgency.*keywords|urgency action required", "The message uses artificial urgency (threats of account suspension, deadlines) to pressure you into acting without thinking."),
    (r"url correlation", "The link contained inside the suspicious email was opened and visited in your web browser history."),
    (r"domain correlation", "The suspicious website domain identified in the email also appeared in your network and browsing activity."),
]


def translate_finding_to_plain_english(finding_text: str) -> str:
    """Translates dense DFIR technical terms into transparent plain English for non-experts."""
    lowered = finding_text.lower()
    for pattern, plain_desc in TECHNICAL_TO_PLAIN_MAP:
        if re.search(pattern, lowered):
            return plain_desc
    # Fallback to sanitized sentence
    return f"Observed indicator: {finding_text}"


def create_community_incident(
    incident_type: str,
    what_happened: str,
    victim_contact: str = "",
    clicked_link: bool = False,
    entered_credentials: bool = False,
    lost_money: bool = False,
) -> dict[str, Any]:
    """
    Creates a community assistance incident record in the case database.
    """
    now_dt = datetime.now(timezone.utc)
    date_str = now_dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    case_num = now_dt.strftime("%Y%m%d-%H%M")
    case_id = f"CASE-COMM-{case_num}"

    notes_str = (
        f"Victim Report | Contact: {victim_contact or 'Anonymous'}\n"
        f"Clicked Link: {'Yes' if clicked_link else 'No'}\n"
        f"Entered Credentials: {'Yes' if entered_credentials else 'No'}\n"
        f"Financial Loss Reported: {'Yes' if lost_money else 'No'}"
    )

    case_record = create_case(
        case_id=case_id,
        incident_type=incident_type,
        incident_description=what_happened,
        reported_date=date_str,
        status="Open",
        notes=notes_str,
    )

    return case_record


def get_community_validation_summary() -> dict[str, Any]:
    """
    Returns real community activity records.
    Anti-Fabrication Rule: If no physical sessions are recorded, status defaults to 'COMMUNITY VALIDATION: PENDING'.
    """
    activities = list_community_activities()
    if not activities:
        return {
            "status": "COMMUNITY VALIDATION: PENDING",
            "total_sessions": 0,
            "total_participants": 0,
            "sessions": [],
            "message": "No community awareness sessions or workshops have been logged yet. All metrics strictly reflect actual documented events.",
        }

    total_participants = sum(a.get("participant_count", 0) for a in activities)
    return {
        "status": "ACTIVE COMMUNITY ENGAGEMENT",
        "total_sessions": len(activities),
        "total_participants": total_participants,
        "sessions": activities,
        "message": f"{len(activities)} documented outreach sessions conducted with {total_participants} total community participants.",
    }
