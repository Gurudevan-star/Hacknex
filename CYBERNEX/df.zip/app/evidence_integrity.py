from __future__ import annotations

import hashlib
import os
import shutil
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from app.db import add_evidence, get_evidence, update_evidence_status

PROJECT_ROOT = Path(__file__).resolve().parents[1]
VAULT_DIR = PROJECT_ROOT / "uploads" / "evidence_vault"
WORKING_DIR = PROJECT_ROOT / "uploads" / "working_copies"
VAULT_DIR.mkdir(parents=True, exist_ok=True)
WORKING_DIR.mkdir(parents=True, exist_ok=True)


def calculate_sha256_for_file(file_path: str | Path) -> str:
    """Calculates the cryptographic SHA-256 hash of a file."""
    p = Path(file_path)
    if not p.is_file():
        raise FileNotFoundError(f"Evidence file not found: {file_path}")

    hasher = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            hasher.update(chunk)
    return hasher.hexdigest().lower()


def calculate_sha256_for_bytes(data: bytes) -> str:
    """Calculates the SHA-256 hash of raw bytes in memory."""
    return hashlib.sha256(data).hexdigest().lower()


def sanitize_filename(filename: str) -> str:
    """Sanitizes filename against path traversal and dangerous characters."""
    clean = os.path.basename(filename).strip()
    clean = "".join(c for c in clean if c.isalnum() or c in (".", "_", "-", " ")).strip()
    return clean or "unnamed_evidence.bin"


def ingest_evidence_file(
    case_id: str,
    original_filename: str,
    file_bytes: bytes,
    source: str = "Investigator Ingestion",
    description: str = "",
    file_type: str = "Generic Evidence",
    custom_evidence_id: str | None = None,
) -> dict[str, Any]:
    """
    Safely preserves original evidence in an immutable evidence vault,
    computes SHA-256, and creates a working copy for non-destructive analysis.
    """
    clean_name = sanitize_filename(original_filename)
    now_dt = datetime.now(timezone.utc)
    timestamp_str = now_dt.strftime("%Y-%m-%d %H:%M:%S UTC")
    tag = now_dt.strftime("%Y%m%d_%H%M%S")

    # Generate or use evidence ID
    evidence_id = custom_evidence_id or f"EV-{case_id.replace('CASE-', '')}-{tag[-4:]}"

    case_vault = VAULT_DIR / case_id
    case_working = WORKING_DIR / case_id
    case_vault.mkdir(parents=True, exist_ok=True)
    case_working.mkdir(parents=True, exist_ok=True)

    vault_file_path = case_vault / f"{evidence_id}_{clean_name}"
    working_file_path = case_working / f"{evidence_id}_{clean_name}"

    # Write original immutable copy to vault
    with open(vault_file_path, "wb") as f:
        f.write(file_bytes)

    # Compute SHA-256 of preserved vault copy
    sha256_hash = calculate_sha256_for_file(vault_file_path)

    # Write identical working copy for analysis
    with open(working_file_path, "wb") as f:
        f.write(file_bytes)

    file_size = len(file_bytes)

    record = add_evidence(
        evidence_id=evidence_id,
        case_id=case_id,
        filename=clean_name,
        file_type=file_type,
        file_size=file_size,
        sha256_hash=sha256_hash,
        stored_path=str(vault_file_path),
        working_copy_path=str(working_file_path),
        source=source,
        description=description,
        acquisition_timestamp=timestamp_str,
        processing_status="Preserved",
    )

    return record


def verify_evidence_integrity(evidence_id: str) -> dict[str, Any]:
    """
    Re-calculates the current SHA-256 of the stored vault copy and compares
    it with the original hash stored in the ledger.

    Reports:
      - 'INTEGRITY VERIFIED' if matches
      - 'INTEGRITY CHANGED' if altered

    Legal Note: Demonstrates cryptographic file-integrity checking;
    does not by itself establish legal chain-of-custody admissibility.
    """
    evidence = get_evidence(evidence_id)
    if not evidence:
        return {
            "evidence_id": evidence_id,
            "status": "NOT FOUND",
            "message": f"Evidence ID '{evidence_id}' does not exist in database.",
            "verified": False,
        }

    stored_path = Path(evidence["stored_path"])
    if not stored_path.exists():
        return {
            "evidence_id": evidence_id,
            "status": "FILE MISSING",
            "message": f"Original evidence file is missing from vault: {stored_path}",
            "verified": False,
        }

    current_hash = calculate_sha256_for_file(stored_path)
    recorded_hash = evidence["sha256_hash"].strip().lower()

    if current_hash == recorded_hash:
        verdict = "INTEGRITY VERIFIED"
        verified = True
        update_evidence_status(evidence_id, "Integrity Verified")
    else:
        verdict = "INTEGRITY CHANGED"
        verified = False
        update_evidence_status(evidence_id, "Integrity Compromised")

    return {
        "evidence_id": evidence_id,
        "case_id": evidence["case_id"],
        "filename": evidence["filename"],
        "status": verdict,
        "verified": verified,
        "original_sha256": recorded_hash,
        "current_sha256": current_hash,
        "verification_timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "legal_admissibility_disclaimer": (
            "Cryptographic integrity verification confirms that the stored bitstream "
            "matches its state upon initial system acquisition. This demonstrates file "
            "integrity checking; it does not by itself establish legal admissibility."
        ),
    }
