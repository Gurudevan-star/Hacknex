from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from app.db import add_correlation, delete_correlations, list_normalized_events
from app.utils import extract_domain, normalize_url

BENIGN_DOMAINS = {
    "google.com",
    "www.google.com",
    "github.com",
    "microsoft.com",
    "mozilla.org",
    "w3.org",
    "example.com",
}


def _parse_event_datetime(ts_str: str) -> datetime | None:
    """Parses event timestamp string to datetime object if valid, else None."""
    if not ts_str or "unavailable" in ts_str.lower() or "unknown" in ts_str.lower():
        return None
    clean = ts_str.replace(" UTC", "").strip()
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%Y-%m-%dT%H:%M:%SZ",
        "%Y-%m-%dT%H:%M:%S",
    ):
        try:
            return datetime.strptime(clean, fmt).replace(tzinfo=timezone.utc)
        except Exception:
            continue
    return None


def run_cross_artifact_correlation(case_id: str, time_window_seconds: int = 900) -> list[dict[str, Any]]:
    """
    Executes transparent, evidence-backed cross-artifact correlation:
      1. URL Correlation (Email extracted URL == Browser visited URL)
      2. Domain Correlation (Shared domain between Email, Browser, and Network)
      3. DNS -> Network Correlation (DNS host query matches Network destination host or IP)
      4. Temporal Correlation (Email arrival followed by Browser/Network activity within delta window)

    Every correlation includes:
      - Evidence IDs
      - matching entity
      - timestamps
      - correlation rule
      - reason
    """
    # Clear prior correlations for fresh analysis
    delete_correlations(case_id)
    events = list_normalized_events(case_id)
    if not events:
        return []

    correlations = []
    corr_idx = 1

    email_events = [e for e in events if "EMAIL" in e["event_type"] or "Email" in e["source"]]
    browser_events = [e for e in events if "URL_VISITED" in e["event_type"] or "Browser" in e["source"]]
    network_events = [e for e in events if e["event_type"] in ("DNS_QUERY", "NETWORK_CONNECTION", "IP_DETECTED") or "Network" in e["source"]]

    # ──────────────────────────────────────────────
    # 1. URL Correlation (Email -> Browser)
    # ──────────────────────────────────────────────
    email_urls = {}
    for ev in email_events:
        if ev.get("url"):
            norm = normalize_url(ev["url"]).rstrip("/")
            email_urls.setdefault(norm, []).append(ev)

    for ev in browser_events:
        if ev.get("url"):
            norm = normalize_url(ev["url"]).rstrip("/")
            if norm in email_urls:
                matching_email_evs = email_urls[norm]
                ev_ids = sorted(set([m["evidence_id"] for m in matching_email_evs] + [ev["evidence_id"]]))
                ts_list = [m["timestamp"] for m in matching_email_evs if m.get("timestamp")]
                if ev.get("timestamp"):
                    ts_list.append(ev["timestamp"])

                corr_id = f"CORR-{case_id.replace('CASE-', '')}-{corr_idx:03d}"
                corr_idx += 1
                reason = (
                    f"A URL extracted from suspicious email ({norm}) was actively visited "
                    f"in browser history. This establishes direct victim interaction with the lure."
                )
                corr = add_correlation(
                    correlation_id=corr_id,
                    case_id=case_id,
                    rule_name="URL Correlation",
                    matching_entity=norm,
                    evidence_ids=ev_ids,
                    timestamps=ts_list,
                    reason=reason,
                )
                correlations.append(corr)

    # ──────────────────────────────────────────────
    # 2. Domain Correlation (Multi-vector domain match)
    # ──────────────────────────────────────────────
    domain_map: dict[str, list[dict[str, Any]]] = {}
    for ev in events:
        d = (ev.get("domain") or "").strip().lower()
        if d and d not in BENIGN_DOMAINS and "." in d:
            domain_map.setdefault(d, []).append(ev)

    for domain, ev_group in domain_map.items():
        # Check if the domain appears across at least TWO different vectors or distinct evidence IDs
        vector_sources = set()
        evidence_ids = set()
        timestamps = []
        for ev in ev_group:
            evidence_ids.add(ev["evidence_id"])
            vector_sources.add(ev["event_type"])
            if ev.get("timestamp") and "unavailable" not in ev["timestamp"].lower():
                timestamps.append(ev["timestamp"])

        # Cross-vector match if present in both email and (browser or network)
        has_email = any("EMAIL" in s or "URL_EXTRACTED" in s for s in vector_sources)
        has_browser = any("URL_VISITED" in s for s in vector_sources)
        has_network = any("DNS_QUERY" in s or "NETWORK" in s for s in vector_sources)

        if (has_email and (has_browser or has_network)) or (has_browser and has_network):
            corr_id = f"CORR-{case_id.replace('CASE-', '')}-{corr_idx:03d}"
            corr_idx += 1
            vectors_str = ", ".join(sorted(vector_sources))
            reason = (
                f"Domain '{domain}' was detected across multiple forensic vectors: [{vectors_str}]. "
                f"Confirms cross-vector consistency of suspicious host artifact."
            )
            corr = add_correlation(
                correlation_id=corr_id,
                case_id=case_id,
                rule_name="Domain Correlation",
                matching_entity=domain,
                evidence_ids=sorted(evidence_ids),
                timestamps=sorted(set(timestamps)),
                reason=reason,
            )
            correlations.append(corr)

    # ──────────────────────────────────────────────
    # 3. DNS -> Network Correlation
    # ──────────────────────────────────────────────
    dns_events = [e for e in network_events if e["event_type"] == "DNS_QUERY"]
    conn_events = [e for e in network_events if e["event_type"] == "NETWORK_CONNECTION"]

    for dns_ev in dns_events:
        queried_host = (dns_ev.get("domain") or "").lower()
        if not queried_host:
            continue
        for conn_ev in conn_events:
            conn_host = (conn_ev.get("domain") or "").lower()
            if queried_host and conn_host and queried_host == conn_host:
                corr_id = f"CORR-{case_id.replace('CASE-', '')}-{corr_idx:03d}"
                corr_idx += 1
                ev_ids = sorted(set([dns_ev["evidence_id"], conn_ev["evidence_id"]]))
                ts_list = [t for t in [dns_ev.get("timestamp"), conn_ev.get("timestamp")] if t]
                reason = (
                    f"DNS query for host '{queried_host}' directly matches the target host in "
                    f"subsequent network connection flow to destination IP {conn_ev.get('ip', 'N/A')}."
                )
                corr = add_correlation(
                    correlation_id=corr_id,
                    case_id=case_id,
                    rule_name="DNS-Network Correlation",
                    matching_entity=f"{queried_host} -> {conn_ev.get('ip')}",
                    evidence_ids=ev_ids,
                    timestamps=ts_list,
                    reason=reason,
                )
                correlations.append(corr)

    # ──────────────────────────────────────────────
    # 4. Temporal Correlation (Primary action sequence: Email delivery -> User visit / network connection)
    # ──────────────────────────────────────────────
    primary_email_events = [e for e in email_events if e.get("event_type") == "EMAIL_RECEIVED"]
    primary_act_events = [e for e in (browser_events + network_events) if e.get("event_type") in ("URL_VISITED", "NETWORK_CONNECTION")]

    for em_ev in primary_email_events:
        em_dt = _parse_event_datetime(em_ev.get("timestamp", ""))
        if not em_dt:
            continue

        for act_ev in primary_act_events:
            act_dt = _parse_event_datetime(act_ev.get("timestamp", ""))
            if not act_dt:
                continue

            delta_sec = (act_dt - em_dt).total_seconds()
            if 0 <= delta_sec <= time_window_seconds:
                corr_id = f"CORR-{case_id.replace('CASE-', '')}-{corr_idx:03d}"
                corr_idx += 1
                ev_ids = sorted(set([em_ev["evidence_id"], act_ev["evidence_id"]]))
                reason = (
                    f"Temporal proximity detected: {act_ev['event_type']} occurred {int(delta_sec)}s "
                    f"after email receipt ({em_ev.get('timestamp')}). "
                    f"Fits rapid phishing delivery and user interaction timeframe (window: {time_window_seconds}s)."
                )
                corr = add_correlation(
                    correlation_id=corr_id,
                    case_id=case_id,
                    rule_name="Temporal Correlation",
                    matching_entity=f"{int(delta_sec)}s delta ({em_ev['event_type']} -> {act_ev['event_type']})",
                    evidence_ids=ev_ids,
                    timestamps=[em_ev.get("timestamp", ""), act_ev.get("timestamp", "")],
                    reason=reason,
                )
                correlations.append(corr)

    return correlations
