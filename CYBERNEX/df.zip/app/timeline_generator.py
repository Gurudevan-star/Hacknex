from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from app.correlation_engine import _parse_event_datetime
from app.db import list_correlations, list_normalized_events


def generate_incident_timeline(case_id: str) -> dict[str, Any]:
    """
    Constructs a verifiable incident timeline from normalized forensic events.

    Structure:
      - 'anchored_events': Events with observed timestamps, strictly sorted chronologically.
      - 'unanchored_events': Events with missing timestamps, explicitly labeled 'Timestamp unavailable'.
      - 'correlation_badges': Highlight correlated multi-vector triggers linked to specific events.

    Absolute Anti-Fabrication Rule: No invented timestamps or events.
    """
    events = list_normalized_events(case_id)
    correlations = list_correlations(case_id)

    # Map evidence IDs and entities to correlations for cross-referencing
    evidence_corr_map: dict[str, list[dict[str, Any]]] = {}
    for corr in correlations:
        for ev_id in corr.get("evidence_ids", []):
            evidence_corr_map.setdefault(ev_id, []).append(corr)

    anchored = []
    unanchored = []

    for ev in events:
        ts_str = ev.get("timestamp", "")
        dt = _parse_event_datetime(ts_str)

        # Attach linked correlations
        linked_corrs = evidence_corr_map.get(ev.get("evidence_id", ""), [])

        item = {
            "event_id": ev["event_id"],
            "evidence_id": ev["evidence_id"],
            "event_type": ev["event_type"],
            "timestamp": ts_str,
            "parsed_dt": dt,
            "source": ev["source"],
            "url": ev.get("url", ""),
            "domain": ev.get("domain", ""),
            "ip": ev.get("ip", ""),
            "description": ev["description"],
            "confidence": ev.get("confidence", "Observed"),
            "raw_ref": ev.get("raw_ref", ""),
            "correlations": linked_corrs,
        }

        if dt is not None:
            anchored.append(item)
        else:
            unanchored.append(item)

    # Sort anchored chronologically
    anchored.sort(key=lambda x: x["parsed_dt"])

    # Clean up internal parsed_dt before returning
    for item in anchored:
        item.pop("parsed_dt", None)

    return {
        "case_id": case_id,
        "total_events": len(events),
        "anchored_count": len(anchored),
        "unanchored_count": len(unanchored),
        "anchored_events": anchored,
        "unanchored_events": unanchored,
        "correlations_count": len(correlations),
        "correlations": correlations,
    }
