from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
DATA_DIR.mkdir(parents=True, exist_ok=True)
DB_PATH = DATA_DIR / "dfir_cases.db"


def get_connection() -> sqlite3.Connection:
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db():
    """Initializes the SQLite schema for Case and Evidence Management."""
    with get_connection() as conn:
        cursor = conn.cursor()

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS cases (
            case_id TEXT PRIMARY KEY,
            incident_type TEXT NOT NULL,
            incident_description TEXT,
            reported_date TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'Open',
            notes TEXT,
            created_at TEXT NOT NULL
        );
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS evidence (
            evidence_id TEXT PRIMARY KEY,
            case_id TEXT NOT NULL,
            filename TEXT NOT NULL,
            file_type TEXT NOT NULL,
            file_size INTEGER NOT NULL,
            sha256_hash TEXT NOT NULL,
            stored_path TEXT NOT NULL,
            working_copy_path TEXT NOT NULL,
            acquisition_timestamp TEXT NOT NULL,
            source TEXT NOT NULL,
            description TEXT,
            processing_status TEXT NOT NULL DEFAULT 'Preserved',
            FOREIGN KEY(case_id) REFERENCES cases(case_id) ON DELETE CASCADE
        );
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS normalized_events (
            event_id TEXT PRIMARY KEY,
            case_id TEXT NOT NULL,
            evidence_id TEXT NOT NULL,
            event_type TEXT NOT NULL,
            timestamp TEXT NOT NULL,
            source TEXT NOT NULL,
            url TEXT,
            domain TEXT,
            ip TEXT,
            description TEXT,
            confidence TEXT,
            raw_ref TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY(case_id) REFERENCES cases(case_id) ON DELETE CASCADE
        );
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS correlations (
            correlation_id TEXT PRIMARY KEY,
            case_id TEXT NOT NULL,
            rule_name TEXT NOT NULL,
            matching_entity TEXT NOT NULL,
            evidence_ids_json TEXT NOT NULL,
            timestamps_json TEXT NOT NULL,
            reason TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY(case_id) REFERENCES cases(case_id) ON DELETE CASCADE
        );
        """)

        cursor.execute("""
        CREATE TABLE IF NOT EXISTS community_activities (
            activity_id TEXT PRIMARY KEY,
            title TEXT NOT NULL,
            activity_date TEXT NOT NULL,
            participant_count INTEGER NOT NULL DEFAULT 0,
            feedback_summary TEXT,
            status TEXT NOT NULL DEFAULT 'COMMUNITY VALIDATION: PENDING',
            notes TEXT,
            created_at TEXT NOT NULL
        );
        """)

        conn.commit()


# ──────────────────────────────────────────────
#  Case Management CRUD
# ──────────────────────────────────────────────

def create_case(
    case_id: str,
    incident_type: str,
    incident_description: str = "",
    reported_date: str | None = None,
    status: str = "Open",
    notes: str = "",
) -> dict[str, Any]:
    init_db()
    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    rep_date = reported_date or now_iso

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT OR REPLACE INTO cases (case_id, incident_type, incident_description, reported_date, status, notes, created_at)
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (case_id.strip(), incident_type.strip(), incident_description.strip(), rep_date, status, notes.strip(), now_iso),
        )
        conn.commit()

    return get_case(case_id)


def get_case(case_id: str) -> dict[str, Any] | None:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM cases WHERE case_id = ?", (case_id.strip(),))
        row = cursor.fetchone()
        return dict(row) if row else None


def list_cases() -> list[dict[str, Any]]:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM cases ORDER BY created_at DESC")
        return [dict(row) for row in cursor.fetchall()]


def update_case(
    case_id: str,
    status: str | None = None,
    incident_type: str | None = None,
    incident_description: str | None = None,
    notes: str | None = None,
) -> dict[str, Any] | None:
    existing = get_case(case_id)
    if not existing:
        return None

    new_status = status if status is not None else existing["status"]
    new_type = incident_type if incident_type is not None else existing["incident_type"]
    new_desc = incident_description if incident_description is not None else existing["incident_description"]
    new_notes = notes if notes is not None else existing["notes"]

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            UPDATE cases
            SET status = ?, incident_type = ?, incident_description = ?, notes = ?
            WHERE case_id = ?
            """,
            (new_status, new_type, new_desc, new_notes, case_id.strip()),
        )
        conn.commit()

    return get_case(case_id)


def delete_case(case_id: str) -> bool:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM evidence WHERE case_id = ?", (case_id.strip(),))
        cursor.execute("DELETE FROM normalized_events WHERE case_id = ?", (case_id.strip(),))
        cursor.execute("DELETE FROM correlations WHERE case_id = ?", (case_id.strip(),))
        cursor.execute("DELETE FROM cases WHERE case_id = ?", (case_id.strip(),))
        conn.commit()
        return cursor.rowcount > 0


# ──────────────────────────────────────────────
#  Evidence Management CRUD
# ──────────────────────────────────────────────

def add_evidence(
    evidence_id: str,
    case_id: str,
    filename: str,
    file_type: str,
    file_size: int,
    sha256_hash: str,
    stored_path: str,
    working_copy_path: str,
    source: str,
    description: str = "",
    acquisition_timestamp: str | None = None,
    processing_status: str = "Preserved",
) -> dict[str, Any]:
    init_db()
    acq_time = acquisition_timestamp or datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT OR REPLACE INTO evidence (
                evidence_id, case_id, filename, file_type, file_size,
                sha256_hash, stored_path, working_copy_path, acquisition_timestamp,
                source, description, processing_status
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                evidence_id.strip(),
                case_id.strip(),
                filename.strip(),
                file_type.strip(),
                file_size,
                sha256_hash.strip().lower(),
                stored_path,
                working_copy_path,
                acq_time,
                source.strip(),
                description.strip(),
                processing_status,
            ),
        )
        conn.commit()

    return get_evidence(evidence_id)


def get_evidence(evidence_id: str) -> dict[str, Any] | None:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM evidence WHERE evidence_id = ?", (evidence_id.strip(),))
        row = cursor.fetchone()
        return dict(row) if row else None


def list_evidence(case_id: str | None = None) -> list[dict[str, Any]]:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        if case_id:
            cursor.execute("SELECT * FROM evidence WHERE case_id = ? ORDER BY acquisition_timestamp ASC", (case_id.strip(),))
        else:
            cursor.execute("SELECT * FROM evidence ORDER BY acquisition_timestamp DESC")
        return [dict(row) for row in cursor.fetchall()]


def update_evidence_status(evidence_id: str, processing_status: str) -> dict[str, Any] | None:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "UPDATE evidence SET processing_status = ? WHERE evidence_id = ?",
            (processing_status, evidence_id.strip()),
        )
        conn.commit()
    return get_evidence(evidence_id)


# ──────────────────────────────────────────────
#  Normalized Events CRUD
# ──────────────────────────────────────────────

def add_normalized_event(
    event_id: str,
    case_id: str,
    evidence_id: str,
    event_type: str,
    timestamp: str,
    source: str,
    url: str = "",
    domain: str = "",
    ip: str = "",
    description: str = "",
    confidence: str = "Observed",
    raw_ref: str = "",
) -> dict[str, Any]:
    init_db()
    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO normalized_events (
                event_id, case_id, evidence_id, event_type, timestamp,
                source, url, domain, ip, description, confidence, raw_ref, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                event_id.strip(),
                case_id.strip(),
                evidence_id.strip(),
                event_type.strip(),
                timestamp.strip(),
                source.strip(),
                url.strip(),
                domain.strip(),
                ip.strip(),
                description.strip(),
                confidence.strip(),
                raw_ref.strip(),
                now_iso,
            ),
        )
        conn.commit()

    return {
        "event_id": event_id,
        "case_id": case_id,
        "evidence_id": evidence_id,
        "event_type": event_type,
        "timestamp": timestamp,
        "source": source,
        "url": url,
        "domain": domain,
        "ip": ip,
        "description": description,
        "confidence": confidence,
        "raw_ref": raw_ref,
    }


def list_normalized_events(case_id: str) -> list[dict[str, Any]]:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM normalized_events WHERE case_id = ? ORDER BY rowid ASC",
            (case_id.strip(),),
        )
        return [dict(row) for row in cursor.fetchall()]


def delete_normalized_events(case_id: str):
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM normalized_events WHERE case_id = ?", (case_id.strip(),))
        conn.commit()


# ──────────────────────────────────────────────
#  Correlations CRUD
# ──────────────────────────────────────────────

def add_correlation(
    correlation_id: str,
    case_id: str,
    rule_name: str,
    matching_entity: str,
    evidence_ids: list[str],
    timestamps: list[str],
    reason: str,
) -> dict[str, Any]:
    init_db()
    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO correlations (
                correlation_id, case_id, rule_name, matching_entity,
                evidence_ids_json, timestamps_json, reason, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                correlation_id.strip(),
                case_id.strip(),
                rule_name.strip(),
                matching_entity.strip(),
                json.dumps(evidence_ids),
                json.dumps(timestamps),
                reason.strip(),
                now_iso,
            ),
        )
        conn.commit()

    return {
        "correlation_id": correlation_id,
        "case_id": case_id,
        "rule_name": rule_name,
        "matching_entity": matching_entity,
        "evidence_ids": evidence_ids,
        "timestamps": timestamps,
        "reason": reason,
        "created_at": now_iso,
    }


def list_correlations(case_id: str) -> list[dict[str, Any]]:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            "SELECT * FROM correlations WHERE case_id = ? ORDER BY created_at ASC",
            (case_id.strip(),),
        )
        items = []
        for row in cursor.fetchall():
            d = dict(row)
            try:
                d["evidence_ids"] = json.loads(d.get("evidence_ids_json") or "[]")
            except Exception:
                d["evidence_ids"] = []
            try:
                d["timestamps"] = json.loads(d.get("timestamps_json") or "[]")
            except Exception:
                d["timestamps"] = []
            items.append(d)
        return items


def delete_correlations(case_id: str):
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("DELETE FROM correlations WHERE case_id = ?", (case_id.strip(),))
        conn.commit()


# ──────────────────────────────────────────────
#  Community Activities CRUD
# ──────────────────────────────────────────────

def list_community_activities() -> list[dict[str, Any]]:
    init_db()
    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM community_activities ORDER BY activity_date DESC")
        return [dict(row) for row in cursor.fetchall()]


def add_community_activity(
    activity_id: str,
    title: str,
    activity_date: str,
    participant_count: int,
    feedback_summary: str = "",
    status: str = "COMMUNITY VALIDATION: PENDING",
    notes: str = "",
) -> dict[str, Any]:
    init_db()
    now_iso = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")

    with get_connection() as conn:
        cursor = conn.cursor()
        cursor.execute(
            """
            INSERT INTO community_activities (
                activity_id, title, activity_date, participant_count,
                feedback_summary, status, notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                activity_id.strip(),
                title.strip(),
                activity_date.strip(),
                participant_count,
                feedback_summary.strip(),
                status.strip(),
                notes.strip(),
                now_iso,
            ),
        )
        conn.commit()

    return {
        "activity_id": activity_id,
        "title": title,
        "activity_date": activity_date,
        "participant_count": participant_count,
        "feedback_summary": feedback_summary,
        "status": status,
        "notes": notes,
    }


if __name__ == "__main__":
    init_db()
    print("Database initialized at:", DB_PATH)
