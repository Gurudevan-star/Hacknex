from __future__ import annotations

import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from app.db import add_normalized_event, delete_normalized_events
from app.utils import extract_domain, normalize_url


def parse_rfc2822_date(date_str: str | None) -> str:
    """Safely converts an RFC2822 email date header to ISO-8601 UTC string or 'Timestamp unavailable'."""
    if not date_str or not date_str.strip():
        return "Timestamp unavailable"
    
    clean_date = date_str.strip()
    # Try email.utils.parsedate_to_datetime
    try:
        from email.utils import parsedate_to_datetime
        dt = parsedate_to_datetime(clean_date)
        return dt.astimezone(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
    except Exception:
        pass

    # Try common formats
    for fmt in (
        "%Y-%m-%d %H:%M:%S",
        "%Y-%m-%d %H:%M",
        "%a, %d %b %Y %H:%M:%S %z",
        "%d %b %Y %H:%M:%S",
    ):
        try:
            dt = datetime.strptime(clean_date.split(" (")[0].strip(), fmt)
            return dt.strftime("%Y-%m-%d %H:%M:%S UTC")
        except Exception:
            continue

    return "Timestamp unavailable"


def normalize_events_from_email(
    case_id: str,
    evidence_id: str,
    email_data: dict[str, Any],
    source_label: str = "Email Analysis",
) -> list[dict[str, Any]]:
    """Generates normalized events from parsed email forensic data."""
    events = []
    idx = 1

    # 1. EMAIL_RECEIVED
    raw_date = email_data.get("date", "") or email_data.get("raw_headers", {}).get("date", "")
    timestamp = parse_rfc2822_date(raw_date)

    from_addr = email_data.get("from", "")
    to_addr = email_data.get("to", "")
    subject = email_data.get("subject", "")
    sender_domain = extract_domain(from_addr)

    ev_id = f"{evidence_id}-EVT-{idx:03d}"
    idx += 1
    events.append(add_normalized_event(
        event_id=ev_id,
        case_id=case_id,
        evidence_id=evidence_id,
        event_type="EMAIL_RECEIVED",
        timestamp=timestamp,
        source=source_label,
        domain=sender_domain,
        description=f"Email received from '{from_addr}' to '{to_addr}' with subject: '{subject}'",
        confidence="Observed",
        raw_ref=f"Subject: {subject}",
    ))

    # 2. DOMAIN_DETECTED (Sender Domain)
    if sender_domain:
        ev_id = f"{evidence_id}-EVT-{idx:03d}"
        idx += 1
        events.append(add_normalized_event(
            event_id=ev_id,
            case_id=case_id,
            evidence_id=evidence_id,
            event_type="DOMAIN_DETECTED",
            timestamp=timestamp,
            source=source_label,
            domain=sender_domain,
            description=f"Sender domain detected: {sender_domain}",
            confidence="Observed",
            raw_ref=f"From: {from_addr}",
        ))

    # 3. IP_DETECTED (Originating sender IP)
    sender_ip = email_data.get("sender_ip", "")
    if sender_ip:
        ev_id = f"{evidence_id}-EVT-{idx:03d}"
        idx += 1
        events.append(add_normalized_event(
            event_id=ev_id,
            case_id=case_id,
            evidence_id=evidence_id,
            event_type="IP_DETECTED",
            timestamp=timestamp,
            source=source_label,
            ip=sender_ip,
            description=f"Originating mail server IP identified: {sender_ip}",
            confidence="Observed",
            raw_ref=f"Received IP: {sender_ip}",
        ))

    # 4. URL_EXTRACTED for each URL in body/headers
    urls = email_data.get("urls", [])
    for url in urls:
        u_domain = extract_domain(url)
        ev_id = f"{evidence_id}-EVT-{idx:03d}"
        idx += 1
        events.append(add_normalized_event(
            event_id=ev_id,
            case_id=case_id,
            evidence_id=evidence_id,
            event_type="URL_EXTRACTED",
            timestamp=timestamp,
            source=source_label,
            url=url,
            domain=u_domain,
            description=f"URL extracted from email body: {url}",
            confidence="Observed",
            raw_ref=url,
        ))

        # Domain event for URL domain if different from sender
        if u_domain and u_domain != sender_domain:
            ev_id = f"{evidence_id}-EVT-{idx:03d}"
            idx += 1
            events.append(add_normalized_event(
                event_id=ev_id,
                case_id=case_id,
                evidence_id=evidence_id,
                event_type="DOMAIN_DETECTED",
                timestamp=timestamp,
                source=source_label,
                domain=u_domain,
                description=f"Lure destination domain detected in email URL: {u_domain}",
                confidence="Observed",
                raw_ref=url,
            ))

    # 5. CREDENTIAL_REQUEST / SUSPICIOUS_LANGUAGE
    reasons = email_data.get("reasons", [])
    for reason in reasons:
        if "Urgency" in reason or "keywords" in reason:
            ev_id = f"{evidence_id}-EVT-{idx:03d}"
            idx += 1
            events.append(add_normalized_event(
                event_id=ev_id,
                case_id=case_id,
                evidence_id=evidence_id,
                event_type="SUSPICIOUS_LANGUAGE",
                timestamp=timestamp,
                source=source_label,
                description=f"Suspicious social-engineering language indicator: {reason}",
                confidence="Detected Indicator",
                raw_ref=reason,
            ))
        elif "Reply-To" in reason or "mismatch" in reason:
            ev_id = f"{evidence_id}-EVT-{idx:03d}"
            idx += 1
            events.append(add_normalized_event(
                event_id=ev_id,
                case_id=case_id,
                evidence_id=evidence_id,
                event_type="CREDENTIAL_REQUEST" if "password" in reason.lower() else "DOMAIN_DETECTED",
                timestamp=timestamp,
                source=source_label,
                description=f"Header anomaly indicator: {reason}",
                confidence="Detected Indicator",
                raw_ref=reason,
            ))

    return events


def normalize_events_from_browser(
    case_id: str,
    evidence_id: str,
    browser_data: dict[str, Any],
    source_label: str = "Browser Telemetry",
) -> list[dict[str, Any]]:
    """Generates normalized events from browser history records."""
    events = []
    records = browser_data.get("records", [])
    idx = 1

    for record in records:
        url = record.get("url", "")
        if not url:
            continue
        domain = extract_domain(url)
        raw_ts = record.get("timestamp", "")
        ts = raw_ts.strip() if raw_ts and raw_ts.strip() and "Unknown" not in raw_ts else "Timestamp unavailable"

        ev_id = f"{evidence_id}-EVT-{idx:03d}"
        idx += 1
        events.append(add_normalized_event(
            event_id=ev_id,
            case_id=case_id,
            evidence_id=evidence_id,
            event_type="URL_VISITED",
            timestamp=ts,
            source=source_label,
            url=url,
            domain=domain,
            description=f"Browser visited URL: '{url}' (Title: '{record.get('title', 'No title')}') [Visits: {record.get('visit_count', 1)}]",
            confidence="Observed",
            raw_ref=f"URL: {url}",
        ))

        if domain:
            ev_id = f"{evidence_id}-EVT-{idx:03d}"
            idx += 1
            events.append(add_normalized_event(
                event_id=ev_id,
                case_id=case_id,
                evidence_id=evidence_id,
                event_type="DOMAIN_DETECTED",
                timestamp=ts,
                source=source_label,
                domain=domain,
                description=f"Host navigation domain observed in browser history: {domain}",
                confidence="Observed",
                raw_ref=domain,
            ))

    return events


def normalize_events_from_network(
    case_id: str,
    evidence_id: str,
    network_flows: list[dict[str, Any]],
    source_label: str = "Network Telemetry",
) -> list[dict[str, Any]]:
    """Generates normalized events from network flows."""
    events = []
    idx = 1

    for flow in network_flows:
        raw_ts = flow.get("timestamp", "")
        ts = raw_ts.strip() if raw_ts and raw_ts.strip() else "Timestamp unavailable"
        dst_ip = flow.get("dst_ip", "")
        host = flow.get("host", "")
        dns_query = flow.get("dns_query", "")
        protocol = (flow.get("protocol") or "TCP").upper()

        if dns_query:
            ev_id = f"{evidence_id}-EVT-{idx:03d}"
            idx += 1
            events.append(add_normalized_event(
                event_id=ev_id,
                case_id=case_id,
                evidence_id=evidence_id,
                event_type="DNS_QUERY",
                timestamp=ts,
                source=source_label,
                domain=dns_query,
                description=f"DNS query resolved host: {dns_query}",
                confidence="Observed",
                raw_ref=f"DNS: {dns_query}",
            ))

        if dst_ip:
            ev_id = f"{evidence_id}-EVT-{idx:03d}"
            idx += 1
            events.append(add_normalized_event(
                event_id=ev_id,
                case_id=case_id,
                evidence_id=evidence_id,
                event_type="IP_DETECTED",
                timestamp=ts,
                source=source_label,
                ip=dst_ip,
                domain=host,
                description=f"Network destination IP detected: {dst_ip}",
                confidence="Observed",
                raw_ref=f"IP: {dst_ip}",
            ))

            ev_id = f"{evidence_id}-EVT-{idx:03d}"
            idx += 1
            events.append(add_normalized_event(
                event_id=ev_id,
                case_id=case_id,
                evidence_id=evidence_id,
                event_type="NETWORK_CONNECTION",
                timestamp=ts,
                source=source_label,
                ip=dst_ip,
                domain=host,
                description=f"{protocol} connection established to {dst_ip} (Host: '{host or 'N/A'}')",
                confidence="Observed",
                raw_ref=f"{protocol} -> {dst_ip}",
            ))

    return events
