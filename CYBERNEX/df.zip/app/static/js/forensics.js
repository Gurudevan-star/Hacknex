/**
 * Enterprise DFIR Forensics Workstation JavaScript Toolkit
 * Includes Dynamic Dark / Light Mode Theme Switching
 */

// Initialize Theme, Case ID, and Timestamp on DOM ready
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initCaseMetadata();
});

// ════════════════════════════════════════════════════════════════════════════════
// THEME MANAGER (DARK / LIGHT MODE)
// ════════════════════════════════════════════════════════════════════════════════
function initTheme() {
  const savedTheme = localStorage.getItem('dfir_theme') || 'dark';
  applyTheme(savedTheme);
}

function toggleTheme() {
  const current = document.documentElement.getAttribute('data-theme') || 'dark';
  const newTheme = current === 'dark' ? 'light' : 'dark';
  applyTheme(newTheme);
  localStorage.setItem('dfir_theme', newTheme);
  showToast(`Switched to ${newTheme === 'dark' ? 'Dark' : 'Light'} Mode`);
}

function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme);
  const btn = document.getElementById('theme-toggle-btn');
  if (btn) {
    if (theme === 'dark') {
      btn.innerHTML = `
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
        </svg>
        <span>Dark Mode</span>
      `;
      btn.title = "Click to switch to Light Mode";
    } else {
      btn.innerHTML = `
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="12" cy="12" r="5"/>
          <line x1="12" y1="1" x2="12" y2="3"/>
          <line x1="12" y1="21" x2="12" y2="23"/>
          <line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/>
          <line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/>
          <line x1="1" y1="12" x2="3" y2="12"/>
          <line x1="21" y1="12" x2="23" y2="12"/>
          <line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/>
          <line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
        </svg>
        <span>Light Mode</span>
      `;
      btn.title = "Click to switch to Dark Mode";
    }
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// CASE & SESSION METADATA
// ════════════════════════════════════════════════════════════════════════════════
function initCaseMetadata() {
  const caseIdElem = document.getElementById('case-id-display');
  if (caseIdElem && !caseIdElem.getAttribute('data-set')) {
    const existing = sessionStorage.getItem('dfir_case_id');
    const caseId = existing || ('CASE-' + new Date().getFullYear() + '-' + Math.floor(1000 + Math.random() * 9000));
    sessionStorage.setItem('dfir_case_id', caseId);
    caseIdElem.textContent = caseId;
    caseIdElem.setAttribute('data-set', 'true');
  }

  const timeElem = document.getElementById('sys-time-display');
  if (timeElem) {
    const updateTime = () => {
      const now = new Date();
      timeElem.textContent = now.toISOString().replace('T', ' ').substring(0, 19) + ' UTC';
    };
    updateTime();
    setInterval(updateTime, 1000);
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// VECTOR & TAB NAVIGATION
// ════════════════════════════════════════════════════════════════════════════════
function selectVector(vectorId, elem) {
  document.querySelectorAll('.vector-dock').forEach(dock => dock.classList.remove('active'));
  if (elem) {
    elem.classList.add('active');
  } else {
    const target = document.getElementById('dock-' + vectorId);
    if (target) target.classList.add('active');
  }

  document.querySelectorAll('.investigation-panel').forEach(panel => panel.classList.remove('active'));
  const targetPanel = document.getElementById('panel-' + vectorId);
  if (targetPanel) targetPanel.classList.add('active');
}

function switchSubTab(prefix, tabId) {
  document.querySelectorAll('.' + prefix + '-tab-btn').forEach(btn => btn.classList.remove('active'));
  document.querySelectorAll('.' + prefix + '-pane').forEach(pane => pane.classList.remove('active'));

  const btn = document.getElementById('btn-' + prefix + '-' + tabId);
  const pane = document.getElementById('pane-' + prefix + '-' + tabId);
  const hiddenInput = document.getElementById(prefix + '-source-input');

  if (btn) btn.classList.add('active');
  if (pane) pane.classList.add('active');
  if (hiddenInput) hiddenInput.value = tabId;
}

function selectBrowserTarget(browserId) {
  document.querySelectorAll('.telemetry-target-card').forEach(card => card.classList.remove('selected'));
  const target = document.getElementById('target-card-' + browserId);
  if (target) target.classList.add('selected');

  const input = document.getElementById('browser-choice-input');
  if (input) input.value = browserId;
}

// ════════════════════════════════════════════════════════════════════════════════
// FILE INGESTION DROPZONE
// ════════════════════════════════════════════════════════════════════════════════
function setupDropzone(dropzoneId, inputId, stagedPillId) {
  const dropzone = document.getElementById(dropzoneId);
  const input = document.getElementById(inputId);
  const pill = document.getElementById(stagedPillId);

  if (!dropzone || !input) return;

  ['dragenter', 'dragover'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.add('dragover');
    }, false);
  });

  ['dragleave', 'drop'].forEach(eventName => {
    dropzone.addEventListener(eventName, (e) => {
      e.preventDefault();
      e.stopPropagation();
      dropzone.classList.remove('dragover');
    }, false);
  });

  dropzone.addEventListener('drop', (e) => {
    if (e.dataTransfer.files.length > 0) {
      input.files = e.dataTransfer.files;
      renderStagedFileInfo(input, pill);
    }
  });

  input.addEventListener('change', () => {
    renderStagedFileInfo(input, pill);
  });
}

function renderStagedFileInfo(input, pill) {
  if (!pill) return;
  if (input.files && input.files.length > 0) {
    if (input.files.length === 1) {
      const f = input.files[0];
      pill.innerHTML = `<span>📎 Staged Evidence: <strong>${escapeHtml(f.name)}</strong> (${(f.size / 1024).toFixed(1)} KB)</span>`;
    } else {
      pill.innerHTML = `<span>📎 Staged Evidence: <strong>${input.files.length} forensic files</strong> ready for batch analysis</span>`;
    }
    pill.style.display = 'flex';
  } else {
    pill.style.display = 'none';
  }
}

// ════════════════════════════════════════════════════════════════════════════════
// CLIPBOARD & TOAST HELPERS
// ════════════════════════════════════════════════════════════════════════════════
function copyToClipboard(text, label = 'Evidence artifact') {
  if (navigator.clipboard && navigator.clipboard.writeText) {
    navigator.clipboard.writeText(text).then(() => {
      showToast(`Copied ${label} to clipboard`);
    }).catch(() => {
      fallbackCopy(text, label);
    });
  } else {
    fallbackCopy(text, label);
  }
}

function fallbackCopy(text, label) {
  const ta = document.createElement('textarea');
  ta.value = text;
  ta.style.position = 'fixed';
  ta.style.opacity = '0';
  document.body.appendChild(ta);
  ta.focus();
  ta.select();
  try {
    document.execCommand('copy');
    showToast(`Copied ${label} to clipboard`);
  } catch (err) {
    showToast('Failed to copy to clipboard', true);
  }
  document.body.removeChild(ta);
}

function showToast(message, isError = false) {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    container.className = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = 'toast';
  if (isError) {
    toast.style.borderColor = 'var(--threat-critical-border)';
    toast.style.color = 'var(--threat-critical)';
  }
  toast.innerHTML = `<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6L9 17l-5-5"/></svg> <span>${escapeHtml(message)}</span>`;
  container.appendChild(toast);

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateY(10px)';
    toast.style.transition = 'all 0.2s ease';
    setTimeout(() => toast.remove(), 200);
  }, 2500);
}

// ════════════════════════════════════════════════════════════════════════════════
// TABLE FILTERS & SEARCH
// ════════════════════════════════════════════════════════════════════════════════
function filterDossierTable(filterType, btn, rowSelector) {
  document.querySelectorAll('.filter-btn').forEach(b => b.classList.remove('active'));
  if (btn) btn.classList.add('active');

  const rows = document.querySelectorAll(rowSelector);
  rows.forEach(row => {
    const status = (row.getAttribute('data-status') || row.getAttribute('data-risk') || '').toLowerCase();
    if (filterType === 'all') {
      row.style.display = '';
    } else if (filterType === 'phishing' || filterType === 'high') {
      row.style.display = (status === 'phishing' || status === 'high') ? '' : 'none';
    } else if (filterType === 'suspicious' || filterType === 'medium') {
      row.style.display = (status === 'suspicious' || status === 'medium') ? '' : 'none';
    } else if (filterType === 'safe' || filterType === 'clean' || filterType === 'low') {
      row.style.display = (status === 'safe' || status === 'clean' || status === 'low') ? '' : 'none';
    }
  });
}

function searchDossierTable(query, rowSelector) {
  const q = query.toLowerCase().trim();
  const rows = document.querySelectorAll(rowSelector);
  rows.forEach(row => {
    const text = row.innerText.toLowerCase();
    row.style.display = text.includes(q) ? '' : 'none';
  });
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}
