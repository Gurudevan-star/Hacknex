from __future__ import annotations

import json
from typing import Any

from app.db import get_case, list_correlations, list_evidence, list_normalized_events
from app.utils import extract_domain, normalize_url


def build_evidence_relationship_graph(case_id: str) -> dict[str, Any]:
    """
    Constructs an evidence-backed directed relationship graph.

    Nodes represent verified entities:
      - Case
      - Evidence files (Email, Browser, Network)
      - Extracted Entities (URL, Domain, DNS host, IP address)

    Edges represent forensic links:
      - CONTAINS
      - EXTRACTED_URL
      - SHARED_DOMAIN
      - VISITED_IN_BROWSER
      - RESOLVED_BY_DNS
      - COMMUNICATED_WITH_IP
      - CROSS_CORRELATION

    Every relationship is evidence-backed and traceable.
    """
    case = get_case(case_id)
    evidence_items = list_evidence(case_id)
    events = list_normalized_events(case_id)
    correlations = list_correlations(case_id)

    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    node_ids: set[str] = set()

    def add_node(node_id: str, label: str, node_type: str, evidence_id: str = "", timestamp: str = "", source: str = "", details: str = ""):
        if node_id not in node_ids:
            node_ids.add(node_id)
            nodes.append({
                "id": node_id,
                "label": label,
                "type": node_type,
                "evidence_id": evidence_id,
                "timestamp": timestamp or "N/A",
                "source": source or "Forensic Extraction",
                "details": details,
            })

    def add_edge(source_id: str, target_id: str, label: str, rule: str = "", evidence_id: str = ""):
        edges.append({
            "source": source_id,
            "target": target_id,
            "label": label,
            "rule": rule,
            "evidence_id": evidence_id,
        })

    # 1. Root Case Node
    case_node_id = f"case_{case_id}"
    add_node(
        case_node_id,
        case_id,
        "case",
        evidence_id="CASE_ROOT",
        timestamp=case.get("reported_date", "") if case else "",
        source="Case Management",
        details=case.get("incident_description", "") if case else "Incident investigation",
    )

    # 2. Evidence nodes
    for ev in evidence_items:
        ev_node_id = f"ev_{ev['evidence_id']}"
        add_node(
            ev_node_id,
            f"{ev['evidence_id']}: {ev['filename']}",
            "evidence",
            evidence_id=ev["evidence_id"],
            timestamp=ev.get("acquisition_timestamp", ""),
            source=ev.get("source", "Vault"),
            details=f"SHA-256: {ev.get('sha256_hash', '')[:16]}... | Status: {ev.get('processing_status', '')}",
        )
        add_edge(case_node_id, ev_node_id, "CONTAINS_EVIDENCE", rule="Evidence Preservation", evidence_id=ev["evidence_id"])

    # 3. Entity nodes and links from normalized events
    for ev in events:
        ev_id = ev.get("evidence_id", "")
        ev_node_id = f"ev_{ev_id}"
        event_type = ev.get("event_type", "")
        ts = ev.get("timestamp", "")
        src = ev.get("source", "")

        # URL entity
        url = ev.get("url")
        if url:
            norm_u = normalize_url(url).rstrip("/")
            u_node_id = f"url_{norm_u}"
            u_domain = extract_domain(norm_u)
            add_node(
                u_node_id,
                norm_u if len(norm_u) <= 35 else norm_u[:32] + "...",
                "url",
                evidence_id=ev_id,
                timestamp=ts,
                source=src,
                details=f"Full URL: {norm_u}\nEvent: {event_type}\nTimestamp: {ts}",
            )
            if "EMAIL" in event_type or "EXTRACTED" in event_type:
                add_edge(ev_node_id, u_node_id, "EXTRACTED_URL", rule="RFC822 URL Parsing", evidence_id=ev_id)
            elif "VISITED" in event_type:
                add_edge(ev_node_id, u_node_id, "VISITED_URL", rule="Browser History Extraction", evidence_id=ev_id)

            # Link URL to its Domain
            if u_domain:
                d_node_id = f"domain_{u_domain.lower()}"
                add_node(
                    d_node_id,
                    u_domain,
                    "domain",
                    evidence_id=ev_id,
                    timestamp=ts,
                    source=src,
                    details=f"Extracted Domain: {u_domain}\nAssociated with: {norm_u}",
                )
                add_edge(u_node_id, d_node_id, "HOSTED_ON_DOMAIN", rule="URL Decomposition", evidence_id=ev_id)

        # Domain entity
        domain = ev.get("domain")
        if domain and not url:
            d_node_id = f"domain_{domain.lower()}"
            add_node(
                d_node_id,
                domain,
                "domain",
                evidence_id=ev_id,
                timestamp=ts,
                source=src,
                details=f"Domain: {domain}\nEvent Type: {event_type}\nSource: {src}",
            )
            add_edge(ev_node_id, d_node_id, "ASSOCIATED_DOMAIN", rule="Domain Extraction", evidence_id=ev_id)

        # IP entity
        ip = ev.get("ip")
        if ip:
            ip_node_id = f"ip_{ip}"
            add_node(
                ip_node_id,
                ip,
                "ip",
                evidence_id=ev_id,
                timestamp=ts,
                source=src,
                details=f"IP Address: {ip}\nOrigin/Destination Flow\nTimestamp: {ts}",
            )
            add_edge(ev_node_id, ip_node_id, "COMMUNICATED_WITH_IP", rule="Network Connection", evidence_id=ev_id)
            if domain:
                d_node_id = f"domain_{domain.lower()}"
                if d_node_id in node_ids:
                    add_edge(d_node_id, ip_node_id, "RESOLVES_TO_IP", rule="DNS Resolution Link", evidence_id=ev_id)

    # 4. Correlation Edges
    for corr in correlations:
        rule_name = corr.get("rule_name", "Correlation")
        entity = corr.get("matching_entity", "")
        ev_ids = corr.get("evidence_ids", [])
        if len(ev_ids) >= 2:
            src_node = f"ev_{ev_ids[0]}"
            tgt_node = f"ev_{ev_ids[1]}"
            if src_node in node_ids and tgt_node in node_ids:
                add_edge(
                    src_node,
                    tgt_node,
                    rule_name.upper(),
                    rule=f"{rule_name}: {entity} ({corr.get('reason', '')})",
                    evidence_id=",".join(ev_ids),
                )

    return {
        "case_id": case_id,
        "nodes": nodes,
        "edges": edges,
        "total_nodes": len(nodes),
        "total_edges": len(edges),
    }
