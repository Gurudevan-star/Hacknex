from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split

PROJECT_ROOT = Path(__file__).resolve().parents[1]
BENCHMARK_CSV = PROJECT_ROOT / "data" / "benchmark_forensic_dataset.csv"
ABLATION_JSON = PROJECT_ROOT / "data" / "ablation_results.json"

VECTOR_DEFINITIONS = {
    "Email": ["spf_result", "dkim_result", "dmarc_result", "reply_to_mismatch", "sender_domain_mismatch"],
    "Browser": ["browser_risk_score", "domain_risk"],
    "URL": ["https", "url_risk"],
    "Network": ["suspicious_network_indicator"],
    "NLP": ["number_of_suspicious_words"],
}

ALL_FEATURES = [
    "https",
    "spf_result",
    "dkim_result",
    "dmarc_result",
    "url_risk",
    "domain_risk",
    "number_of_suspicious_words",
    "reply_to_mismatch",
    "sender_domain_mismatch",
    "suspicious_network_indicator",
    "browser_risk_score",
]


def load_benchmark_dataset() -> pd.DataFrame:
    """Loads the benchmark forensic dataset."""
    if not BENCHMARK_CSV.exists():
        from scripts.generate_benchmark_dataset import generate_benchmark_dataset
        generate_benchmark_dataset()
    return pd.read_csv(BENCHMARK_CSV)


def get_dataset_metadata() -> dict[str, Any]:
    """Returns dataset properties without fabricating any statistics."""
    df = load_benchmark_dataset()
    total = len(df)
    legit_count = int((df["label"] == 0).sum())
    phish_count = int((df["label"] == 1).sum())

    return {
        "dataset_name": "Curated DFIR Cross-Vector Benchmark Dataset",
        "file_path": str(BENCHMARK_CSV.name),
        "total_samples": total,
        "class_distribution": {
            "Legitimate (Class 0)": legit_count,
            "Phishing (Class 1)": phish_count,
        },
        "features_count": len(ALL_FEATURES),
        "features_list": ALL_FEATURES,
        "split_method": "Stratified 70/30 train/test split, random_state=42",
        "leakage_prevention": "Deduplicated unique feature signatures across classes; stratified holdout test split.",
    }


def get_ablation_results() -> dict[str, Any]:
    """Retrieves saved ablation experiment results. If not yet run, returns 'N/A — PENDING EVALUATION'."""
    if not ABLATION_JSON.exists():
        return {
            "status": "N/A — PENDING EVALUATION",
            "executed": False,
            "experiment_timestamp": None,
            "table": [
                {"configuration": "Full Model", "f1": "N/A — PENDING EVALUATION", "precision": "N/A", "recall": "N/A", "roc_auc": "N/A", "fpr": "N/A", "fnr": "N/A", "features_used": len(ALL_FEATURES)},
                {"configuration": "Without Email", "f1": "N/A — PENDING EVALUATION", "precision": "N/A", "recall": "N/A", "roc_auc": "N/A", "fpr": "N/A", "fnr": "N/A", "features_used": len(ALL_FEATURES) - len(VECTOR_DEFINITIONS["Email"])},
                {"configuration": "Without Browser", "f1": "N/A — PENDING EVALUATION", "precision": "N/A", "recall": "N/A", "roc_auc": "N/A", "fpr": "N/A", "fnr": "N/A", "features_used": len(ALL_FEATURES) - len(VECTOR_DEFINITIONS["Browser"])},
                {"configuration": "Without URL", "f1": "N/A — PENDING EVALUATION", "precision": "N/A", "recall": "N/A", "roc_auc": "N/A", "fpr": "N/A", "fnr": "N/A", "features_used": len(ALL_FEATURES) - len(VECTOR_DEFINITIONS["URL"])},
                {"configuration": "Without Network", "f1": "N/A — PENDING EVALUATION", "precision": "N/A", "recall": "N/A", "roc_auc": "N/A", "fpr": "N/A", "fnr": "N/A", "features_used": len(ALL_FEATURES) - len(VECTOR_DEFINITIONS["Network"])},
                {"configuration": "Without NLP", "f1": "N/A — PENDING EVALUATION", "precision": "N/A", "recall": "N/A", "roc_auc": "N/A", "fpr": "N/A", "fnr": "N/A", "features_used": len(ALL_FEATURES) - len(VECTOR_DEFINITIONS["NLP"])},
            ],
        }

    try:
        with open(ABLATION_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {"status": "ERROR LOADING RESULTS", "executed": False, "table": []}


def run_ablation_study() -> dict[str, Any]:
    """
    Executes the empirical cross-vector ablation experiment.

    Ablation Configurations:
      1. Full model (All 11 features across Email, Browser, URL, Network, NLP)
      2. Full - Email
      3. Full - Browser
      4. Full - URL
      5. Full - Network
      6. Full - NLP

    Computes actual:
      F1, Precision, Recall, ROC-AUC, FPR, FNR, Confusion Matrix, Latency.
    """
    df = load_benchmark_dataset()
    y = df["label"]

    configs = [
        ("Full Model (Fused Cross-Vector)", ALL_FEATURES, "Baseline full multi-vector forensic model"),
        ("Without Email Vector", [f for f in ALL_FEATURES if f not in VECTOR_DEFINITIONS["Email"]], "Removes SPF, DKIM, DMARC, and Reply-To mismatches"),
        ("Without Browser Vector", [f for f in ALL_FEATURES if f not in VECTOR_DEFINITIONS["Browser"]], "Removes Browser history risk score and domain visit indicators"),
        ("Without URL Vector", [f for f in ALL_FEATURES if f not in VECTOR_DEFINITIONS["URL"]], "Removes HTTPS and suspicious URL lexical structure scores"),
        ("Without Network Vector", [f for f in ALL_FEATURES if f not in VECTOR_DEFINITIONS["Network"]], "Removes Network host patterns and destination IP subnet indicators"),
        ("Without NLP Vector", [f for f in ALL_FEATURES if f not in VECTOR_DEFINITIONS["NLP"]], "Removes NLP urgency and credential harvesting language keywords"),
    ]

    table_rows = []

    for name, feat_subset, desc in configs:
        X = df[feat_subset]
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.3, random_state=42, stratify=y
        )

        start_time = time.perf_counter()
        clf = RandomForestClassifier(n_estimators=100, random_state=42)
        clf.fit(X_train, y_train)
        pred = clf.predict(X_test)
        proba = clf.predict_proba(X_test)[:, 1]
        elapsed_ms = (time.perf_counter() - start_time) * 1000.0

        tn, fp, fn, tp = confusion_matrix(y_test, pred, labels=[0, 1]).ravel()
        fpr = float(fp / (fp + tn)) if (fp + tn) > 0 else 0.0
        fnr = float(fn / (fn + tp)) if (fn + tp) > 0 else 0.0

        acc = float(accuracy_score(y_test, pred))
        prec = float(precision_score(y_test, pred, zero_division=0))
        rec = float(recall_score(y_test, pred, zero_division=0))
        f1 = float(f1_score(y_test, pred, zero_division=0))
        roc_auc = float(roc_auc_score(y_test, proba))

        table_rows.append({
            "configuration": name,
            "description": desc,
            "features_used": len(feat_subset),
            "feature_names": feat_subset,
            "f1": round(f1, 4),
            "precision": round(prec, 4),
            "recall": round(rec, 4),
            "roc_auc": round(roc_auc, 4),
            "accuracy": round(acc, 4),
            "fpr": round(fpr, 4),
            "fnr": round(fnr, 4),
            "confusion_matrix": {"tn": int(tn), "fp": int(fp), "fn": int(fn), "tp": int(tp)},
            "latency_ms": round(elapsed_ms, 2),
        })

    full_f1 = table_rows[0]["f1"]
    for row in table_rows[1:]:
        delta_f1 = round(row["f1"] - full_f1, 4)
        row["delta_f1_vs_full"] = delta_f1

    result_payload = {
        "status": "EXPERIMENT EXECUTED",
        "executed": True,
        "experiment_timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "random_seed": 42,
        "test_size": 0.3,
        "total_samples": len(df),
        "test_samples": int(len(df) * 0.3),
        "table": table_rows,
        "conclusion": (
            "Empirical results demonstrate the detection performance impact when isolating individual "
            "forensic vectors vs fusing all 5 vectors into a cross-vector pipeline."
        ),
    }

    ABLATION_JSON.parent.mkdir(parents=True, exist_ok=True)
    with open(ABLATION_JSON, "w", encoding="utf-8") as f:
        json.dump(result_payload, f, indent=2)

    return result_payload


if __name__ == "__main__":
    res = run_ablation_study()
    print("Ablation Study completed at:", res["experiment_timestamp"])
    for row in res["table"]:
        print(f"  {row['configuration']}: F1={row['f1']}, Prec={row['precision']}, Rec={row['recall']}, ROC-AUC={row['roc_auc']}")
