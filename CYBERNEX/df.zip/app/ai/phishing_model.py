from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import joblib
import pandas as pd
import shap

from ml.dataset_audit import audit_dataset
from ml.explain import explain_case_prediction, verify_shap_reconstruction
from ml.feature_dictionary import FEATURE_DICTIONARY, FEATURE_NAMES
from ml.model_registry import ModelPackage, ModelRegistry
from ml.train import train_all_models

PROJECT_ROOT = Path(__file__).resolve().parents[2]
MODEL_PATH = PROJECT_ROOT / "models" / "phishing_model.joblib"
BENCHMARK_CSV = PROJECT_ROOT / "data" / "benchmark_forensic_dataset.csv"

FEATURES = list(FEATURE_NAMES)


def train_models() -> dict[str, Any]:
    """
    Trains candidate classifiers using the upgraded ml pipeline.
    Maintains full backward-compatible legacy payload while persisting to ModelRegistry.
    """
    results = train_all_models(BENCHMARK_CSV)
    reg = ModelRegistry()
    rf_pkg = reg.get_model("random_forest")
    lr_pkg = reg.get_model("logistic_regression")

    evaluation_dict = {
        "RandomForest": rf_pkg.metadata.get("evaluation_metrics", {}),
        "LogisticRegression": lr_pkg.metadata.get("evaluation_metrics", {}),
    }
    if "xgboost" in results["models"] and results["models"]["xgboost"]["status"] == "TRAINED":
        xgb_pkg = reg.get_model("xgboost")
        evaluation_dict["XGBoost"] = xgb_pkg.metadata.get("evaluation_metrics", {})

    payload = {
        "model": rf_pkg.estimator,
        "features": FEATURES,
        "evaluation": evaluation_dict,
        "best_model": "RandomForest",
        "model_version": rf_pkg.version,
    }
    MODEL_PATH.parent.mkdir(parents=True, exist_ok=True)
    joblib.dump(payload, MODEL_PATH)
    return payload


def get_model() -> dict[str, Any]:
    """Loads the trained model payload from disk, retraining via ml pipeline if missing."""
    if not MODEL_PATH.exists():
        return train_models()
    try:
        payload = joblib.load(MODEL_PATH)
        return payload
    except Exception:
        return train_models()


def predict_class(
    features_dict: dict[str, Any],
    model_type: str = "random_forest",
) -> dict[str, Any]:
    """
    Generates standard classification prediction, model probability, and risk score.
    Maintains 100% backward-compatible interface while supporting multi-model selection.
    """
    registry = ModelRegistry()
    try:
        package = registry.get_model(model_type)
    except Exception:
        train_models()
        package = registry.get_model(model_type)

    row: dict[str, float] = {}
    for f in package.feature_schema:
        val = features_dict.get(f, 0)
        if isinstance(val, bool):
            val = int(val)
        try:
            row[f] = float(val)
        except (ValueError, TypeError):
            row[f] = 0.0

    raw_frame = pd.DataFrame([row], columns=package.feature_schema)
    scaled = package.metadata.get("uses_scaled_features", False)
    trans_frame = package.preprocessor.transform(raw_frame, scale=scaled)

    pred = int(package.estimator.predict(trans_frame)[0])
    has_proba = hasattr(package.estimator, "predict_proba")
    proba_dist = package.estimator.predict_proba(trans_frame)[0] if has_proba else [0.5, 0.5]
    phish_proba = float(proba_dist[1]) if len(proba_dist) > 1 else float(proba_dist[0])

    if pred == 1:
        label = "Suspicious" if phish_proba < 0.55 else "Phishing"
    else:
        label = "Safe"

    risk_score = int(round(phish_proba * 100))
    if label == "Suspicious":
        risk_score = max(45, min(70, risk_score))

    legacy_payload = get_model()
    evaluation = legacy_payload.get("evaluation", {})

    return {
        "prediction": label,
        "risk_score": risk_score,
        "probability": round(phish_proba, 4),
        "model": package.model_name,
        "model_type": model_type,
        "model_version": package.version,
        "evaluation": evaluation,
        "features_evaluated": row,
    }


def explain_prediction(
    features_dict: dict[str, Any],
    model_type: str = "random_forest",
    case_id: str | None = None,
) -> dict[str, Any]:
    """
    Computes genuine, mathematically verified SHAP values for the given features.
    Delegates to ml.explain while preserving full backward compatibility with legacy consumers.
    """
    exp = explain_case_prediction(features_dict, model_type=model_type, case_id=case_id)

    # Legacy-compatible mapping
    rule_reasons = exp.get("deterministic_forensic_observations", [])
    legacy_format = {
        "prediction": exp["prediction"],
        "risk_score": exp["risk_score"],
        "model_probability": exp["model_probability"],
        "model_name": exp["model_name"],
        "model_type": exp["model_type"],
        "model_version": exp["model_version"],
        "shap_available": exp["shap_available"],
        "shap_baseline": exp["shap_baseline"],
        "shap_contributions": exp["shap_contributions"],
        "positive_contributors": exp["positive_contributors"],
        "negative_contributors": exp["negative_contributors"],
        "neutral_contributors": exp["neutral_contributors"],
        "shap_error": exp["shap_error"],
        "raw_model_output": exp["raw_model_output"],
        "reconstructed_output": exp["reconstructed_output"],
        "reconstruction_discrepancy": exp["reconstruction_discrepancy"],
        "reconstruction_verified": exp["reconstruction_verified"],
        "math_formulation": exp["math_formulation"],
        "rule_based_explanations": rule_reasons,
        "deterministic_forensic_observations": rule_reasons,
        "explanation_type": f"SHAP (TreeExplainer) on {exp['model_name']} + Rule-based forensic observations",
    }
    return legacy_format


if __name__ == "__main__":
    train_models()
    test_features = {
        "https": 0,
        "spf_result": 0,
        "dkim_result": 0,
        "dmarc_result": 0,
        "url_risk": 90,
        "domain_risk": 85,
        "number_of_suspicious_words": 6,
        "reply_to_mismatch": 1,
        "sender_domain_mismatch": 1,
        "suspicious_network_indicator": 1,
        "browser_risk_score": 88.0,
    }
    exp = explain_prediction(test_features)
    print("Prediction:", exp["prediction"])
    print("Risk Score:", exp["risk_score"])
    print("Model Probability:", exp["model_probability"])
    print("SHAP Verified:", exp["reconstruction_verified"])
    print("Top SHAP Contributions:")
    for item in exp["shap_contributions"][:5]:
        print(f"  {item['feature']}: {item['direction']}{abs(item['shap_value'])} ({item['impact']})")
