package com.cybersafe.forensics

import com.cybersafe.forensics.analysis.LocalAnalysisEngine
import com.cybersafe.forensics.data.model.RiskLevel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class HybridVerdictTest {

    @Test
    fun testDeterministicRedFlagAlwaysWinsOverMl() = runBlocking {
        // Direct IP address host is a deterministic red flag
        val input = "http://192.168.1.1/login.php"
        val result = LocalAnalysisEngine.analyze(input)
        assertEquals(RiskLevel.HIGH_WARNING, result.riskLevel)
        assertTrue(result.indicators.any { it.ruleId == "RULE_IP_HOST" })
    }

    @Test
    fun testBrandImpersonationTriggersDangerousVerdict() = runBlocking {
        val input = "http://sbi-verification-secure.xyz/login"
        val result = LocalAnalysisEngine.analyze(input)
        assertEquals(RiskLevel.HIGH_WARNING, result.riskLevel)
        assertTrue(result.indicators.any { it.ruleId == "RULE_BRAND_IMPERSONATION" })
    }

    @Test
    fun testUpiFraudTriggersDangerousVerdict() = runBlocking {
        val input = "Dear customer please scan QR to receive 25000 cashback"
        val result = LocalAnalysisEngine.analyze(input)
        assertEquals(RiskLevel.HIGH_WARNING, result.riskLevel)
        assertTrue(result.indicators.any { it.ruleId == "RULE_UPI_COLLECT_FRAUD" })
    }

    @Test
    fun testBenignMessageYieldsNoWarningSigns() = runBlocking {
        val input = "Can you send me the presentation slides before the meeting?"
        val result = LocalAnalysisEngine.analyze(input)
        assertEquals(RiskLevel.LOW_WARNING, result.riskLevel)
        assertEquals(0, result.indicators.size)
    }

    @Test
    fun testShortenedUrlYieldsCautionVerdict() = runBlocking {
        val input = "https://bit.ly/3xyzExample"
        val result = LocalAnalysisEngine.analyze(input)
        assertEquals(RiskLevel.CAUTION, result.riskLevel)
        assertTrue(result.indicators.any { it.ruleId == "RULE_URL_SHORTENER" })
    }
}
