package com.cybersafe.forensics

import com.cybersafe.forensics.analysis.UrlAnalysisRule
import com.cybersafe.forensics.data.model.IndicatorSeverity
import org.junit.Assert.*
import org.junit.Test

class UrlAnalysisTest {

    @Test
    fun testLegitimateDomainHasNoHighRiskIndicators() {
        val findings = UrlAnalysisRule.analyzeUrl("https://www.google.com/search?q=cybersecurity")
        val highSeverity = findings.filter { it.severity == IndicatorSeverity.HIGH }
        assertTrue("Legitimate standard URL should not have high severity indicators", highSeverity.isEmpty())
        assertFalse(findings.any { it.ruleId == "RULE_IP_HOST" })
        assertFalse(findings.any { it.ruleId == "RULE_PUNYCODE_HOMOGLYPH" })
    }

    @Test
    fun testDirectIpHostDetection() {
        val findings = UrlAnalysisRule.analyzeUrl("http://45.33.11.9/login.php")
        assertTrue(findings.any { it.ruleId == "RULE_IP_HOST" })
        val ipFinding = findings.first { it.ruleId == "RULE_IP_HOST" }
        assertEquals("Direct IP Address Host", ipFinding.title)
        assertEquals(IndicatorSeverity.HIGH, ipFinding.severity)
        assertTrue(ipFinding.explanation.contains("raw numerical IP address"))
        assertEquals("45.33.11.9", ipFinding.evidenceQuote)
    }

    @Test
    fun testCredentialPathDetection() {
        val findings = UrlAnalysisRule.analyzeUrl("https://update-account.com/secure/login/verify.html")
        assertTrue(findings.any { it.ruleId == "RULE_CREDENTIAL_PATH" })
        val pathFinding = findings.first { it.ruleId == "RULE_CREDENTIAL_PATH" }
        assertTrue(pathFinding.explanation.contains("login") || pathFinding.explanation.contains("verify"))
    }

    @Test
    fun testExcessiveSubdomainsDetection() {
        val findings = UrlAnalysisRule.analyzeUrl("http://paypal.com.verify.account-security.net/home")
        assertTrue(findings.any { it.ruleId == "RULE_EXCESSIVE_SUBDOMAINS" })
    }

    @Test
    fun testSuspiciousTldDetection() {
        val findings = UrlAnalysisRule.analyzeUrl("https://claim-free-gift.xyz/index.html")
        assertTrue(findings.any { it.ruleId == "RULE_SUSPICIOUS_TLD" })
        val tldFinding = findings.first { it.ruleId == "RULE_SUSPICIOUS_TLD" }
        assertTrue(tldFinding.evidenceQuote.contains(".xyz"))
    }

    @Test
    fun testPunycodeHomoglyphDetection() {
        val findings = UrlAnalysisRule.analyzeUrl("https://xn--pple-43d.com/store")
        assertTrue(findings.any { it.ruleId == "RULE_PUNYCODE_HOMOGLYPH" })
    }

    @Test
    fun testUnencryptedHttpProtocolWarning() {
        val findings = UrlAnalysisRule.analyzeUrl("http://example.com/page")
        assertTrue(findings.any { it.ruleId == "RULE_HTTP_UNENCRYPTED" })
    }

    @Test
    fun testNonStandardPortDetection() {
        val findings = UrlAnalysisRule.analyzeUrl("http://example.com:4444/admin")
        assertTrue(findings.any { it.ruleId == "RULE_NON_STANDARD_PORT" })
    }
}
