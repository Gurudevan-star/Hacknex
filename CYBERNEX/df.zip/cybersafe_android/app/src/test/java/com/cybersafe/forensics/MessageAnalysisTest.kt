package com.cybersafe.forensics

import com.cybersafe.forensics.analysis.MessageAnalysisRule
import com.cybersafe.forensics.data.model.IndicatorSeverity
import org.junit.Assert.*
import org.junit.Test

class MessageAnalysisTest {

    @Test
    fun testBenignMessageHasNoIndicators() {
        val benign = "Hi Team, the project review meeting is scheduled for tomorrow at 10 AM. See you there."
        val findings = MessageAnalysisRule.analyzeMessage(benign)
        assertTrue("Benign daily message should have 0 warning indicators", findings.isEmpty())
    }

    @Test
    fun testUrgencyAndFearTacticsDetection() {
        val message = "URGENT ACTION REQUIRED: Your bank account will be closed immediately within 24 hours."
        val findings = MessageAnalysisRule.analyzeMessage(message)
        assertTrue(findings.any { it.ruleId == "RULE_SOCIAL_URGENCY" })
        val finding = findings.first { it.ruleId == "RULE_SOCIAL_URGENCY" }
        assertEquals(IndicatorSeverity.HIGH, finding.severity)
        assertTrue(finding.explanation.contains("artificial panic"))
    }

    @Test
    fun testCredentialSolicitationDetection() {
        val message = "Dear Customer, please confirm your pin and send your otp to verify your banking access."
        val findings = MessageAnalysisRule.analyzeMessage(message)
        assertTrue(findings.any { it.ruleId == "RULE_CREDENTIAL_SOLICITATION" })
        val finding = findings.first { it.ruleId == "RULE_CREDENTIAL_SOLICITATION" }
        assertEquals(IndicatorSeverity.HIGH, finding.severity)
        assertTrue(finding.explanation.contains("credentials"))
    }

    @Test
    fun testAuthorityImpersonationDetection() {
        val message = "Notice from the Income Tax Department Fraud Prevention Unit regarding an audit."
        val findings = MessageAnalysisRule.analyzeMessage(message)
        assertTrue(findings.any { it.ruleId == "RULE_IMPERSONATION_AUTHORITY" })
    }

    @Test
    fun testPaymentCoercionAndPrizeClaimDetection() {
        val message = "Congratulations! Claim your cash prize now. A small processing fee required via gift card."
        val findings = MessageAnalysisRule.analyzeMessage(message)
        assertTrue(findings.any { it.ruleId == "RULE_PAYMENT_COERCION" })
    }
}
