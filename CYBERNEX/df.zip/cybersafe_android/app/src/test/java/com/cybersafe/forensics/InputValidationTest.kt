package com.cybersafe.forensics

import com.cybersafe.forensics.analysis.InputValidator
import com.cybersafe.forensics.data.model.ScanType
import org.junit.Assert.*
import org.junit.Test

class InputValidationTest {

    @Test
    fun testEmptyInputRejection() {
        val result = InputValidator.validate("")
        assertTrue(result is InputValidator.ValidationResult.Invalid)
        val invalid = result as InputValidator.ValidationResult.Invalid
        assertTrue(invalid.reason.contains("empty", ignoreCase = true))
    }

    @Test
    fun testWhitespaceOnlyInputRejection() {
        val result = InputValidator.validate("    \n\t  ")
        assertTrue(result is InputValidator.ValidationResult.Invalid)
    }

    @Test
    fun testExcessiveLengthInputRejection() {
        val hugeInput = "A".repeat(100_001)
        val result = InputValidator.validate(hugeInput)
        assertTrue(result is InputValidator.ValidationResult.Invalid)
        val invalid = result as InputValidator.ValidationResult.Invalid
        assertTrue(invalid.reason.contains("maximum", ignoreCase = true))
    }

    @Test
    fun testUrlClassification() {
        val result = InputValidator.validate("https://example.com/login")
        assertTrue(result is InputValidator.ValidationResult.Valid)
        val valid = result as InputValidator.ValidationResult.Valid
        assertEquals(ScanType.URL, valid.scanType)
        assertEquals(1, valid.detectedUrls.size)
        assertEquals("https://example.com/login", valid.detectedUrls[0])
    }

    @Test
    fun testMessageClassificationWithEmbeddedUrl() {
        val result = InputValidator.validate("Urgent: your account is on hold. Please visit https://secure.update.net to fix it.")
        assertTrue(result is InputValidator.ValidationResult.Valid)
        val valid = result as InputValidator.ValidationResult.Valid
        assertEquals(ScanType.MESSAGE, valid.scanType)
        assertEquals(1, valid.detectedUrls.size)
        assertEquals("https://secure.update.net", valid.detectedUrls[0])
    }

    @Test
    fun testSanitizePreviewStripsSensitiveTokens() {
        val dirty = "https://bank.com/reset?token=SUPER_SECRET_TOKEN_12345&user=john"
        val clean = InputValidator.sanitizePreview(dirty)
        assertFalse(clean.contains("SUPER_SECRET_TOKEN_12345"))
        assertTrue(clean.contains("token=[REDACTED]"))
        assertTrue(clean.contains("user=john"))
    }
}
