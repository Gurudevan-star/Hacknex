package com.cybersafe.forensics

import com.cybersafe.forensics.analysis.LocalAnalysisEngine
import com.cybersafe.forensics.data.model.RiskLevel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class RiskEvaluationTest {

    @Test
    fun testHighWarningAssignmentForSevereIndicators() = runBlocking {
        val severe = "URGENT: Click http://45.33.11.9/login.php immediately within 24 hours to confirm your pin."
        val result = LocalAnalysisEngine.analyze(severe)

        assertEquals(RiskLevel.HIGH_WARNING, result.riskLevel)
        assertTrue(result.indicators.isNotEmpty())
        assertTrue(result.nextSteps.isNotEmpty())
        assertTrue(result.limitations.isNotEmpty())
        assertTrue(result.isOfflineVerified)

        // Verify indicators adhere to data contract
        for (ind in result.indicators) {
            assertTrue(ind.ruleId.startsWith("RULE_"))
            assertTrue(ind.title.isNotBlank())
            assertTrue(ind.explanation.isNotBlank())
        }
    }

    @Test
    fun testCautionAssignmentForModerateIndicators() = runBlocking {
        val moderate = "Check out our new community project page at https://ourproject.xyz/about"
        val result = LocalAnalysisEngine.analyze(moderate)

        assertEquals(RiskLevel.CAUTION, result.riskLevel)
        assertTrue(result.indicators.any { it.ruleId == "RULE_SUSPICIOUS_TLD" })
    }

    @Test
    fun testLowWarningAssignmentForBenignInput() = runBlocking {
        val benign = "Hi Alex, dinner is ready at 7pm tonight. Let me know when you arrive."
        val result = LocalAnalysisEngine.analyze(benign)

        assertEquals(RiskLevel.LOW_WARNING, result.riskLevel)
        assertTrue(result.indicators.isEmpty())
        // Crucial requirement: absence of indicators must be disclosed
        assertTrue(result.limitations.any { it.contains("Absence of detected warning signs does NOT guarantee") })
    }

    @Test
    fun testInvalidInputHandledSafelyWithoutCrash() = runBlocking {
        val result = LocalAnalysisEngine.analyze("   ")
        assertEquals(RiskLevel.INVALID_INPUT, result.riskLevel)
        assertFalse(result.indicators.isEmpty())
    }
}
