package com.cybersafe.forensics

import com.cybersafe.forensics.analysis.LocalAnalysisEngine
import com.cybersafe.forensics.data.repository.AnalysisRepository
import com.cybersafe.forensics.data.repository.HistoryRepository
import com.cybersafe.forensics.ui.viewmodel.CyberSafeViewModel
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test
import org.mockito.Mockito

class PrivacySanitizationTest {

    @Test
    fun testSharedReportExcludesSecretQueryParameters() = runBlocking {
        val input = "Urgent: Please verify your credentials at https://phish-site.com/login?token=SECRET_JWT_AUTH_TOKEN_9999&pin=1234"
        val result = LocalAnalysisEngine.analyze(input)

        // Mock repositories for ViewModel helper test
        val analysisRepo = Mockito.mock(AnalysisRepository::class.java)
        val historyRepo = Mockito.mock(HistoryRepository::class.java)
        val viewModel = CyberSafeViewModel(analysisRepo, historyRepo)

        val sharedReport = viewModel.buildShareableReport(result)

        // Verify secret values are not present
        assertFalse(sharedReport.contains("SECRET_JWT_AUTH_TOKEN_9999"))
        assertFalse(sharedReport.contains("pin=1234"))
        assertTrue(sharedReport.contains("CyberSafe Inspection Report"))
        assertTrue(sharedReport.contains("Recommended Safe Next Steps"))
    }
}
