package com.cybersafe.forensics

import com.cybersafe.forensics.analysis.IndiaScamRules
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class IndiaScamRulesTest {

    @Test
    fun testUpiCollectFraudDetected() {
        val msg = "Sir please scan QR to receive 50000 rupees cashback immediately"
        val findings = IndiaScamRules.analyze(msg)
        assertTrue(findings.any { it.ruleId == "RULE_UPI_COLLECT_FRAUD" })
    }

    @Test
    fun testElectricityDisconnectionScamDetected() {
        val msg = "Dear consumer your electricity power cut tonight at 9:30 pm because bill unpaid. Call officer immediately."
        val findings = IndiaScamRules.analyze(msg)
        assertTrue(findings.any { it.ruleId == "RULE_ELECTRICITY_GAS_DISCONNECTION" })
    }

    @Test
    fun testFakeKycPanAlertDetected() {
        val msg = "Important: your PAN card update pending. Complete your KYC immediately to prevent account closure."
        val findings = IndiaScamRules.analyze(msg)
        assertTrue(findings.any { it.ruleId == "RULE_FAKE_KYC_PAN_AADHAAR" })
    }

    @Test
    fun testRemoteAccessAppScamDetected() {
        val msg = "Please download AnyDesk app from play store so our technical team can solve your banking issue."
        val findings = IndiaScamRules.analyze(msg)
        assertTrue(findings.any { it.ruleId == "RULE_REMOTE_ACCESS_APP" })
    }

    @Test
    fun testOtpSolicitationDetected() {
        val msg = "Dear customer, to confirm your delivery please share OTP sent to your registered mobile."
        val findings = IndiaScamRules.analyze(msg)
        assertTrue(findings.any { it.ruleId == "RULE_OTP_PIN_CVV_SOLICITATION" })
    }

    @Test
    fun testFakeJobScamDetected() {
        val msg = "Earn 5000 daily from home by completing simple telegram task like youtube videos."
        val findings = IndiaScamRules.analyze(msg)
        assertTrue(findings.any { it.ruleId == "RULE_FAKE_JOB_OFFERS" })
    }

    @Test
    fun testBenignMessageHasZeroIndiaScamFlags() {
        val msg = "Mom, I have reached Bangalore safely. Will call you after dinner."
        val findings = IndiaScamRules.analyze(msg)
        assertEquals(0, findings.size)
    }
}
