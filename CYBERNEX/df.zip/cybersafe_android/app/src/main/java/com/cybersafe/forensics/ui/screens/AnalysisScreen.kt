package com.cybersafe.forensics.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybersafe.forensics.ui.viewmodel.CyberSafeViewModel

@Composable
fun AnalysisScreen(
    viewModel: CyberSafeViewModel,
    onAnalysisFinished: () -> Unit,
    onCancel: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()

    // When analysis finishes and a result exists, navigate to results
    LaunchedEffect(state.isAnalyzing, state.currentResult) {
        if (!state.isAnalyzing && state.currentResult != null) {
            onAnalysisFinished()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.fillMaxWidth()
        ) {
            Icon(
                Icons.Default.Security,
                contentDescription = "Scanning",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(56.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "Inspecting Warning Signs",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Real Linear Progress Indicator
            LinearProgressIndicator(
                progress = { state.analysisProgress },
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .height(8.dp),
                color = MaterialTheme.colorScheme.primary,
                trackColor = MaterialTheme.colorScheme.surfaceVariant
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Real step description
            Text(
                text = state.analysisStep.ifEmpty { "Executing on-device verification..." },
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth(0.9f)
            )

            Spacer(modifier = Modifier.height(32.dp))

            // Cancellation Button
            OutlinedButton(
                onClick = {
                    viewModel.cancelAnalysis()
                    onCancel()
                },
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Stop Inspection")
            }
        }
    }
}
