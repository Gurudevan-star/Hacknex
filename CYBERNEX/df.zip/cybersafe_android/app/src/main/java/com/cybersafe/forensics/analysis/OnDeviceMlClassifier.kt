package com.cybersafe.forensics.analysis

import kotlin.math.exp

/**
 * On-Device Machine Learning Classifier for Mobile Phishing & Scam Detection.
 * 
 * Uses ONLY features available locally on a mobile phone (10 dimensions).
 * Zero email-only features (No SPF, DKIM, DMARC).
 * Normalizes features with StandardScaler parameters fitted on training data,
 * and performs calibrated forward-pass logistic inference on-device.
 */
object OnDeviceMlClassifier {

    data class MlPrediction(
        val probability: Float,
        val isMaliciousScore: Boolean,
        val topContributingFeatures: List<String>
    )

    // Feature names in exact order
    val FEATURE_NAMES = listOf(
        "url_length",
        "is_ip_host",
        "has_suspicious_tld",
        "has_brand_mismatch",
        "has_at_symbol",
        "link_count",
        "urgency_keyword_count",
        "credential_keyword_count",
        "financial_keyword_count",
        "remote_access_flag"
    )

    // StandardScaler parameters (means) fitted strictly on training partition
    private val SCALER_MEANS = doubleArrayOf(
        28.857142857142858,
        0.08571428571428572,
        0.2571428571428571,
        0.2571428571428571,
        0.08571428571428572,
        0.6285714285714286,
        1.1714285714285715,
        0.9428571428571428,
        0.9714285714285714,
        0.08571428571428572
    )

    // StandardScaler parameters (scales / std dev) fitted strictly on training partition
    private val SCALER_SCALES = doubleArrayOf(
        29.27128564421635,
        0.27994168488950605,
        0.4370588154508102,
        0.4370588154508102,
        0.27994168488950605,
        0.5390846361175202,
        1.1584648532979025,
        1.0675166681296804,
        0.9995917534020514,
        0.2799416848895061
    )

    // Regularized model weights
    private val MODEL_WEIGHTS = doubleArrayOf(
        0.20474254900841068,  // url_length
        0.10437392149552138,  // is_ip_host
        0.5358209735441458,   // has_suspicious_tld
        0.3442836970874965,   // has_brand_mismatch
        0.40341139851813534,  // has_at_symbol
        -0.07481058153516516, // link_count
        0.9379705748157741,   // urgency_keyword_count
        0.9378208189985088,   // credential_keyword_count
        1.1746558431223693,   // financial_keyword_count
        0.34671526099094      // remote_access_flag
    )

    private const val MODEL_INTERCEPT = 0.31350314516611033
    private const val DECISION_THRESHOLD = 0.50

    private val URGENCY_WORDS = listOf(
        "urgent", "immediately", "today", "blocked", "suspended", "closed", "expire", "hurry", "quick", "warning"
    )
    private val CREDENTIAL_WORDS = listOf(
        "otp", "pin", "password", "cvv", "kyc", "pan", "aadhaar", "login", "verify", "credentials"
    )
    private val FINANCIAL_WORDS = listOf(
        "upi", "bank", "account", "money", "cash", "rupees", "rs", "payment", "prize", "lottery", "fee", "refund"
    )
    private val REMOTE_WORDS = listOf(
        "anydesk", "teamviewer", "quicksupport", "rustdesk"
    )

    /**
     * Extracts phone-local lexical and keyword features from the raw input text and URLs.
     */
    fun extractFeatures(text: String, urls: List<String>): DoubleArray {
        val lowerText = text.lowercase()
        val firstUrl = urls.firstOrNull() ?: ""
        val lowerUrl = firstUrl.lowercase()

        val urlLength = firstUrl.length.toDouble()
        val isIpHost = if (firstUrl.contains(Regex("^https?://(\\d{1,3}\\.){3}\\d{1,3}"))) 1.0 else 0.0
        val hasSuspiciousTld = if (listOf(".xyz", ".top", ".icu", ".tk", ".ml", ".cf", ".gq", ".buzz", ".vip").any { lowerUrl.contains(it) }) 1.0 else 0.0
        val hasBrandMismatch = if (listOf("sbi", "hdfc", "icici", "paytm", "amazon", "google").any { lowerUrl.contains(it) } &&
            !listOf("sbi.co.in", "hdfcbank.com", "icicibank.com", "paytm.com", "amazon.in", "google.com").any { lowerUrl.contains(it) }
        ) 1.0 else 0.0
        val hasAtSymbol = if (firstUrl.contains("@")) 1.0 else 0.0
        val linkCount = urls.size.toDouble()

        val urgencyCount = URGENCY_WORDS.count { lowerText.contains(it) }.toDouble()
        val credCount = CREDENTIAL_WORDS.count { lowerText.contains(it) }.toDouble()
        val finCount = FINANCIAL_WORDS.count { lowerText.contains(it) }.toDouble()
        val remoteFlag = if (REMOTE_WORDS.any { lowerText.contains(it) }) 1.0 else 0.0

        return doubleArrayOf(
            urlLength,
            isIpHost,
            hasSuspiciousTld,
            hasBrandMismatch,
            hasAtSymbol,
            linkCount,
            urgencyCount,
            credCount,
            finCount,
            remoteFlag
        )
    }

    /**
     * Executes forward-pass on-device inference with calibrated probability calculation.
     */
    fun predict(text: String, urls: List<String>): MlPrediction {
        val rawFeatures = extractFeatures(text, urls)
        var logit = MODEL_INTERCEPT
        val contributions = mutableListOf<Pair<String, Double>>()

        for (i in rawFeatures.indices) {
            // Apply training-fitted z-score scaling: (x - mean) / scale
            val scaledValue = (rawFeatures[i] - SCALER_MEANS[i]) / SCALER_SCALES[i]
            val contribution = MODEL_WEIGHTS[i] * scaledValue
            logit += contribution

            if (rawFeatures[i] > 0.0 && contribution > 0.0) {
                contributions.add(FEATURE_NAMES[i] to contribution)
            }
        }

        // Logistic sigmoid: 1 / (1 + exp(-z))
        val probability = (1.0 / (1.0 + exp(-logit))).toFloat().coerceIn(0.0f, 1.0f)
        val isMalicious = probability >= DECISION_THRESHOLD

        val topFeatures = contributions
            .sortedByDescending { it.second }
            .take(3)
            .map { formatFeatureName(it.first) }

        return MlPrediction(
            probability = probability,
            isMaliciousScore = isMalicious,
            topContributingFeatures = topFeatures
        )
    }

    private fun formatFeatureName(name: String): String {
        return when (name) {
            "urgency_keyword_count" -> "Urgency & panic language patterns"
            "credential_keyword_count" -> "Password / OTP / PIN request keywords"
            "financial_keyword_count" -> "Payment, bank, or lottery references"
            "has_brand_mismatch" -> "Brand mismatch in website domain"
            "is_ip_host" -> "Raw numerical IP address host"
            "has_suspicious_tld" -> "High-risk top-level domain"
            "remote_access_flag" -> "Screen-sharing application reference"
            "has_at_symbol" -> "Deceptive '@' link structure"
            else -> name.replace("_", " ")
        }
    }
}
