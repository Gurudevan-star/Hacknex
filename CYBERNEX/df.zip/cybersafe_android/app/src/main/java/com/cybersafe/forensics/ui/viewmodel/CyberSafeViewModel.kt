package com.cybersafe.forensics.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.cybersafe.forensics.data.model.AnalysisResult
import com.cybersafe.forensics.data.repository.AnalysisRepository
import com.cybersafe.forensics.data.repository.HistoryRepository
import kotlinx.coroutines.Job
import kotlinx.coroutines.channels.BufferOverflow
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class CyberSafeViewModel(
    private val analysisRepository: AnalysisRepository,
    private val historyRepository: HistoryRepository
) : ViewModel() {

    private val _uiState = MutableStateFlow(CyberSafeUiState())
    val uiState: StateFlow<CyberSafeUiState> = _uiState.asStateFlow()

    private val _navigationEvent = MutableSharedFlow<String>(
        replay = 1,
        onBufferOverflow = BufferOverflow.DROP_OLDEST
    )
    val navigationEvent: SharedFlow<String> = _navigationEvent.asSharedFlow()

    private var currentAnalysisJob: Job? = null

    init {
        // Observe local Room scan history
        viewModelScope.launch {
            historyRepository.allHistory.collect { history ->
                _uiState.update { it.copy(historyList = history) }
            }
        }
    }

    fun onInputTextChanged(text: String) {
        _uiState.update { it.copy(inputText = text, statusMessage = null) }
    }

    fun clearInput() {
        _uiState.update { it.copy(inputText = "", statusMessage = null) }
    }

    fun setSaveHistoryEnabled(enabled: Boolean) {
        _uiState.update { it.copy(saveHistoryEnabled = enabled) }
    }

    /**
     * Handles instant analysis when content is shared directly from another app (WhatsApp, SMS, Telegram, Browser).
     * Automatically triggers scanning and navigates straight to the result screen.
     */
    fun handleIncomingSharedText(text: String, onNavigateToResult: () -> Unit = {}) {
        val clean = text.trim()
        if (clean.isBlank()) return

        _uiState.update {
            it.copy(
                inputText = clean,
                isAnalyzing = true,
                analysisProgress = 0.2f,
                analysisStep = "Scanning shared content on-device...",
                statusMessage = null
            )
        }

        currentAnalysisJob?.cancel()
        currentAnalysisJob = viewModelScope.launch {
            try {
                val result = analysisRepository.analyze(clean) { step, progress ->
                    _uiState.update {
                        it.copy(
                            analysisStep = step,
                            analysisProgress = progress
                        )
                    }
                }

                if (_uiState.value.saveHistoryEnabled && result.indicators.isNotEmpty()) {
                    historyRepository.saveScanResult(result)
                }

                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        analysisProgress = 1.0f,
                        currentResult = result
                    )
                }
                _navigationEvent.emit("results")
                onNavigateToResult()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        statusMessage = "Scan could not be completed."
                    )
                }
            }
        }
    }

    fun startAnalysis(onComplete: () -> Unit) {
        val input = _uiState.value.inputText
        if (input.isBlank()) {
            _uiState.update { it.copy(statusMessage = "Please enter or paste text to analyze.") }
            return
        }

        currentAnalysisJob?.cancel()
        _uiState.update {
            it.copy(
                isAnalyzing = true,
                analysisProgress = 0.1f,
                analysisStep = "Initializing local inspection engine...",
                statusMessage = null
            )
        }

        currentAnalysisJob = viewModelScope.launch {
            try {
                val result = analysisRepository.analyze(input) { step, progress ->
                    _uiState.update {
                        it.copy(
                            analysisStep = step,
                            analysisProgress = progress
                        )
                    }
                }

                if (_uiState.value.saveHistoryEnabled && result.indicators.isNotEmpty()) {
                    historyRepository.saveScanResult(result)
                }

                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        analysisProgress = 1.0f,
                        currentResult = result
                    )
                }
                onComplete()
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        isAnalyzing = false,
                        statusMessage = "Analysis cancelled or encountered an error."
                    )
                }
            }
        }
    }

    fun cancelAnalysis() {
        currentAnalysisJob?.cancel()
        _uiState.update {
            it.copy(
                isAnalyzing = false,
                analysisProgress = 0f,
                analysisStep = "",
                statusMessage = "Analysis was stopped."
            )
        }
    }

    fun deleteHistoryItem(id: String) {
        viewModelScope.launch {
            historyRepository.deleteScanById(id)
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            historyRepository.clearAllHistory()
        }
    }

    /**
     * Formats a clean, safe report for sharing that omits sensitive credentials.
     */
    fun buildShareableReport(result: AnalysisResult): String {
        val sb = StringBuilder()
        sb.append("CyberSafe Inspection Report\n")
        sb.append("Outcome: ${result.riskLevel.displayName}\n")
        sb.append("Summary: ${result.summaryHeadline}\n\n")

        if (result.indicators.isNotEmpty()) {
            sb.append("Observed Warning Indicators:\n")
            for (ind in result.indicators) {
                sb.append("• [${ind.severity}] ${ind.title}: ${ind.explanation}\n")
            }
            sb.append("\n")
        }

        sb.append("Recommended Safe Next Steps:\n")
        for (step in result.nextSteps) {
            sb.append("${step.priority}. ${step.action}: ${step.description}\n")
        }

        sb.append("\nNotice: Analysis performed on-device by CyberSafe. Absence of warning signs does not guarantee safety.")
        return sb.toString()
    }
}
