package com.cybersafe.forensics.data.model

import java.util.UUID

/**
 * Complete outcome of an on-device local analysis.
 * Stores sanitized input snippet (excluding sensitive tokens/credentials),
 * structured indicators, safe next steps, and realistic limitations.
 */
data class AnalysisResult(
    val id: String = UUID.randomUUID().toString(),
    val timestamp: Long = System.currentTimeMillis(),
    val scanType: ScanType,
    val sanitizedSnippet: String,
    val riskLevel: RiskLevel,
    val summaryHeadline: String,
    val indicators: List<FindingIndicator>,
    val nextSteps: List<SafeNextStep>,
    val limitations: List<String>,
    val isOfflineVerified: Boolean = true
)
