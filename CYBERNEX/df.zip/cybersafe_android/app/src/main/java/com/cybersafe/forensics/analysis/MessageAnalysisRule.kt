package com.cybersafe.forensics.analysis

import com.cybersafe.forensics.data.model.FindingIndicator
import com.cybersafe.forensics.data.model.IndicatorSeverity

object MessageAnalysisRule {

    private val URGENCY_TRIGGERS = listOf(
        "immediately", "within 24 hours", "account will be closed", "account suspended",
        "temporarily locked", "unauthorized transaction", "final notice", "urgent action required",
        "act now", "action required immediately", "suspended within", "deactivated today"
    )

    private val CREDENTIAL_SOLICITATIONS = listOf(
        "enter your password", "confirm your pin", "send your otp", "verify your otp",
        "provide bank details", "share your cvv", "secret recovery phrase", "confirm your credentials",
        "login to avoid suspension", "update your billing", "verify account immediately"
    )

    private val AUTHORITY_FRAMING = listOf(
        "security department", "fraud prevention", "income tax department", "customs clearance",
        "federal police", "cyber crime unit", "lottery department", "official support team",
        "central bank notification", "account protection team"
    )

    private val PAYMENT_COERCION = listOf(
        "pay via gift card", "scan qr code to receive", "crypto transfer", "processing fee required",
        "claim your cash prize", "wire money", "prepayment fee", "lottery winnings"
    )

    fun analyzeMessage(text: String): List<FindingIndicator> {
        val indicators = mutableListOf<FindingIndicator>()
        val lowerText = text.lowercase()

        // 1. Artificial Urgency & Fear Tactics
        val matchedUrgency = URGENCY_TRIGGERS.filter { lowerText.contains(it) }
        if (matchedUrgency.isNotEmpty()) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_SOCIAL_URGENCY",
                    title = "Artificial Urgency & Threat Framing",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message creates artificial panic ('${matchedUrgency.first()}') to rush your decision and prevent you from consulting others.",
                    evidenceQuote = matchedUrgency.joinToString(", "),
                    caveat = "Legitimate critical security alerts can also express urgency, but they do not demand immediate action through unofficial links."
                )
            )
        }

        // 2. Sensitive Credential or OTP Solicitation
        val matchedCredential = CREDENTIAL_SOLICITATIONS.filter { lowerText.contains(it) }
        if (matchedCredential.isNotEmpty()) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_CREDENTIAL_SOLICITATION",
                    title = "Direct Credential or OTP Solicitation",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message asks you to provide, confirm, or enter secret credentials ('${matchedCredential.first()}'). Legitimate banks and services will never ask you to disclose your PIN or OTP.",
                    evidenceQuote = matchedCredential.joinToString(", "),
                    caveat = "Genuine login pages ask for credentials, but unsolicited messages should never be trusted with sensitive data."
                )
            )
        }

        // 3. Official Authority Framing & Impersonation
        val matchedAuthority = AUTHORITY_FRAMING.filter { lowerText.contains(it) }
        if (matchedAuthority.isNotEmpty()) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_IMPERSONATION_AUTHORITY",
                    title = "Official Authority Claim",
                    severity = IndicatorSeverity.MEDIUM,
                    explanation = "The sender claims official organizational authority ('${matchedAuthority.first()}'). Scammers frequently impersonate government, police, or bank departments to intimidate victims.",
                    evidenceQuote = matchedAuthority.joinToString(", "),
                    caveat = "Legitimate institutions also use these team names; verify through their known official customer care number."
                )
            )
        }

        // 4. Irregular Payment Coercion or Prize Claims
        val matchedPayment = PAYMENT_COERCION.filter { lowerText.contains(it) }
        if (matchedPayment.isNotEmpty()) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_PAYMENT_COERCION",
                    title = "Irregular Payment or Prize Claim",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message mentions unconventional payment methods or claims you won money requiring a fee ('${matchedPayment.first()}'). This is a classic scam pattern.",
                    evidenceQuote = matchedPayment.joinToString(", "),
                    caveat = "Never send money or share bank details to claim refunds or prizes."
                )
            )
        }

        return indicators
    }
}
