package com.cybersafe.forensics.analysis

import com.cybersafe.forensics.data.model.FindingIndicator
import com.cybersafe.forensics.data.model.IndicatorSeverity

object IndiaScamRules {

    // 1. UPI Collect & Reverse QR Code Fraud
    private val UPI_FRAUD_PATTERNS = listOf(
        "scan qr to receive", "scan qr code to receive", "enter upi pin to receive",
        "pay 1 rupee to verify", "pay rs 1 to verify", "pay re 1 to receive",
        "upi collect request", "approve request to claim refund", "receive cashback scan qr",
        "scan to accept payment", "enter pin to get refund"
    )

    // 2. Fake KYC, PAN, and Aadhaar Updates
    private val KYC_PAN_PATTERNS = listOf(
        "pan card update", "update your pan", "aadhaar verification pending",
        "complete your kyc", "kyc suspended", "sim kyc update", "kyc verification immediately",
        "link pan to account", "biometric kyc update", "ebil kyc", "bsnl kyc", "jio kyc"
    )

    // 3. Electricity & Utility Bill Disconnection Threats
    private val ELECTRICITY_PATTERNS = listOf(
        "electricity bill unpaid", "power will be disconnected", "electricity power cut tonight",
        "power disconnect at 9.30 pm", "power disconnect at 9:30", "contact electricity officer",
        "call electricity helpline", "bill payment pending tonight", "gas supply will be stopped"
    )

    // 4. Parcel / Postal Delivery Fee Scam
    private val PARCEL_PATTERNS = listOf(
        "india post parcel held", "parcel cannot be delivered", "update delivery address",
        "customs fee unpaid", "pay courier fee", "unpaid delivery charge", "parcel delayed at depot",
        "postal tracking address wrong"
    )

    // 5. Lottery, Prize & KBC Lucky Draw Fraud
    private val LOTTERY_PATTERNS = listOf(
        "kaun banega crorepati", "kbc lucky draw", "won cash prize of", "won 25,00,000",
        "congratulations you have won", "selected for lottery", "claim your prize money",
        "lucky winner of rs", "car winner in lucky draw"
    )

    // 6. Fake Work-From-Home & Part-Time Job Scams
    private val JOB_SCAM_PATTERNS = listOf(
        "part time job like youtube", "earn 5000 daily from home", "earn 3000 daily without investment",
        "telegram task job", "hotel review task earn money", "daily payout work from home",
        "google maps review job", "simple typing task daily income"
    )

    // 7. Predatory Instant Loan Apps
    private val LOAN_APP_PATTERNS = listOf(
        "pre-approved instant loan", "loan without cibil", "instant loan in 5 minutes",
        "personal loan approved 50,000", "zero cibil loan disbursal", "instant money without documents"
    )

    // 8. "Account Blocked / Frozen" Scare Tactics
    private val ACCOUNT_BLOCKED_PATTERNS = listOf(
        "your account is blocked", "account has been suspended", "debit card temporarily blocked",
        "netbanking disabled", "yono account blocked", "sbi netbanking closed",
        "unauthorized transaction detected on your account"
    )

    // 9. Remote Access Screen-Sharing Tools (AnyDesk, TeamViewer, QuickSupport)
    private val REMOTE_ACCESS_APPS = listOf(
        "anydesk", "teamviewer", "quicksupport", "rustdesk", "airdroid", "screen share app"
    )

    // 10. Direct OTP, PIN & CVV Solicitation
    private val CREDENTIAL_SECRETS = listOf(
        "share otp", "send 6 digit otp", "tell your pin", "enter your atm pin",
        "cvv number", "card expiry and cvv", "secret mpin", "upi pin"
    )

    fun analyze(text: String): List<FindingIndicator> {
        val indicators = mutableListOf<FindingIndicator>()
        val lower = text.lowercase()

        // 1. UPI Fraud Check
        val matchedUpi = UPI_FRAUD_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedUpi != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_UPI_COLLECT_FRAUD",
                    title = "UPI Payment & Reverse QR Scam",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message tells you to scan a QR code or enter a UPI PIN to receive money ('$matchedUpi'). In real UPI, you NEVER need to enter your PIN or scan a QR code to receive money. Entering your PIN transfers money OUT of your account.",
                    evidenceQuote = matchedUpi,
                    caveat = "Entering a UPI PIN always deducts money; it never deposits money."
                )
            )
        }

        // 2. Fake KYC / PAN / Aadhaar Alert
        val matchedKyc = KYC_PAN_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedKyc != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_FAKE_KYC_PAN_AADHAAR",
                    title = "Fake KYC / PAN Disconnection Alert",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message claims your account or SIM will stop working unless you update your KYC or PAN immediately ('$matchedKyc'). Legitimate banks never threaten immediate closure via SMS or WhatsApp links.",
                    evidenceQuote = matchedKyc,
                    caveat = "Always update KYC in person at your branch or through your bank's official app."
                )
            )
        }

        // 3. Electricity Bill Disconnection Threat
        val matchedPower = ELECTRICITY_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedPower != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_ELECTRICITY_GAS_DISCONNECTION",
                    title = "Electricity Disconnection Threat",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "This is a widespread extortion scam claiming power or gas will be disconnected tonight ('$matchedPower'). Electricity boards do not send personal mobile numbers for bill payments or disconnect power without formal written notice.",
                    evidenceQuote = matchedPower,
                    caveat = "Pay utility bills only through official board websites or verified payment apps."
                )
            )
        }

        // 4. Parcel / Courier Delivery Fee Scam
        val matchedParcel = PARCEL_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedParcel != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_PARCEL_COURIER_FEE",
                    title = "Parcel Held / Delivery Fee Scam",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message claims a parcel cannot be delivered without paying an urgent fee ('$matchedParcel'). India Post and major couriers do not ask for card details through unofficial links.",
                    evidenceQuote = matchedParcel,
                    caveat = "Verify tracking numbers on the official courier website."
                )
            )
        }

        // 5. Lottery & KBC Lucky Draw Fraud
        val matchedLottery = LOTTERY_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedLottery != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_LOTTERY_PRIZE_SCAM",
                    title = "Fake Lottery / Prize Award Scam",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message announces an unexpected prize, lottery, or KBC reward ('$matchedLottery'). If you did not enter a contest, you cannot win it. Attackers demand 'processing fees' to steal money.",
                    evidenceQuote = matchedLottery,
                    caveat = "Legitimate lotteries never ask winners to pay an advance fee."
                )
            )
        }

        // 6. Fake Work-From-Home Job Scam
        val matchedJob = JOB_SCAM_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedJob != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_FAKE_JOB_OFFERS",
                    title = "Fake Task / Part-Time Job Scam",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message promises easy daily income for simple tasks like liking videos or rating hotels ('$matchedJob'). These are 'task scams' that initially pay small sums, then demand large deposits and disappear.",
                    evidenceQuote = matchedJob,
                    caveat = "Legitimate employers never demand money for training or job tasks."
                )
            )
        }

        // 7. Predatory Instant Loan Apps
        val matchedLoan = LOAN_APP_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedLoan != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_PREDATORY_LOAN_APP",
                    title = "Unregulated Instant Loan App",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message advertises instant loans without CIBIL verification ('$matchedLoan'). Illegal lending apps steal phone contacts and photos to harass and blackmail borrowers.",
                    evidenceQuote = matchedLoan,
                    caveat = "Borrow only from RBI-registered banks and verified NBFCs."
                )
            )
        }

        // 8. "Account Blocked" Panic Framing
        val matchedBlock = ACCOUNT_BLOCKED_PATTERNS.firstOrNull { lower.contains(it) }
        if (matchedBlock != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_ACCOUNT_BLOCKED_SCARE",
                    title = "Account Suspended Scare Tactic",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message creates artificial panic by stating your account or card is blocked ('$matchedBlock'). Scammers use fear to trick you into entering credentials on fake pages.",
                    evidenceQuote = matchedBlock,
                    caveat = "Open your official banking app directly to check your real account status."
                )
            )
        }

        // 9. Remote Access Screen Sharing Apps
        val matchedRemote = REMOTE_ACCESS_APPS.firstOrNull { lower.contains(it) }
        if (matchedRemote != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_REMOTE_ACCESS_APP",
                    title = "Dangerous Remote-Access App Request ($matchedRemote)",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message directs you to download or use screen-sharing software ('$matchedRemote'). If installed, scammers can see your phone screen, read incoming OTPs, and take full control of your banking apps.",
                    evidenceQuote = matchedRemote,
                    caveat = "Never install screen-sharing apps on instructions from unknown callers."
                )
            )
        }

        // 10. Direct OTP, PIN, or CVV Solicitation
        val matchedSecret = CREDENTIAL_SECRETS.firstOrNull { lower.contains(it) }
        if (matchedSecret != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_OTP_PIN_CVV_SOLICITATION",
                    title = "Secret Banking Credential Solicitation",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The message requests private banking credentials like an OTP, PIN, or CVV ('$matchedSecret'). Banks never ask customers to disclose their secret authentication codes.",
                    evidenceQuote = matchedSecret,
                    caveat = "Anyone asking for your OTP or PIN is attempting to steal your money."
                )
            )
        }

        return indicators
    }
}
