package com.cybersafe.forensics.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SafetyTipsScreen(onNavigateBack: () -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cyber Safety Guide", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 14.dp)
        ) {
            Text(
                text = "Practical Defense for Everyday Users",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "Simple rules to protect your money, identity, and personal accounts from scams.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(18.dp))

            SafetyTipCard(
                icon = Icons.Default.Lock,
                title = "1. The Golden Rule for OTPs & PINs",
                description = "Never share your One-Time Password (OTP), UPI PIN, ATM PIN, or card CVV with anyone. Real bank employees or customer support representatives will NEVER ask you for your OTP."
            )

            SafetyTipCard(
                icon = Icons.Default.Link,
                title = "2. Spotting Deceptive Links",
                description = "Attackers often use slight spelling changes (like 'paypa1.com' or 'amaz0n-orders.xyz') or long subdomain prefixes. Avoid clicking links in unexpected text messages; open the company's official app or type the web address manually."
            )

            SafetyTipCard(
                icon = Icons.Default.Warning,
                title = "3. Panic & Urgent Deadlines",
                description = "Scammers create artificial panic with phrases like 'Account will be permanently blocked in 2 hours' or 'Unauthorized debit of $950'. Pause and take a breath. Scammers rely on panic to rush your judgment."
            )

            SafetyTipCard(
                icon = Icons.Default.Badge,
                title = "4. Authority & Government Impersonation",
                description = "Scammers pose as police officers, tax inspectors, customs agents, or courier delivery personnel demanding payment to clear a parcel or avoid arrest. Official agencies never settle legal matters via instant messaging or gift cards."
            )

            SafetyTipCard(
                icon = Icons.Default.QrCode,
                title = "5. QR Code & Refund Traps",
                description = "Scanning a QR code only SENDS money from your account; you NEVER need to scan a QR code or enter your UPI PIN to RECEIVE funds or a refund."
            )

            SafetyTipCard(
                icon = Icons.Default.Restore,
                title = "6. What To Do If You Were Tricked",
                description = "If you typed your credentials or sent money: (1) Immediately change passwords and enable Two-Factor Authentication. (2) Call your bank's fraud helpline to freeze compromised cards. (3) Report the incident to your local cybercrime police portal."
            )
        }
    }
}

@Composable
private fun SafetyTipCard(
    icon: ImageVector,
    title: String,
    description: String
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(bottom = 12.dp),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(modifier = Modifier.padding(14.dp)) {
            Icon(
                icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(12.dp))
            Column {
                Text(
                    text = title,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = description,
                    fontSize = 12.5.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    lineHeight = 18.sp
                )
            }
        }
    }
}
