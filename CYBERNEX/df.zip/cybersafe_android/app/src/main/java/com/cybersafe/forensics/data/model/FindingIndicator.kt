package com.cybersafe.forensics.data.model

enum class IndicatorSeverity {
    HIGH,
    MEDIUM,
    LOW,
    INFO
}

/**
 * A specific, evidence-backed warning indicator found during analysis.
 * Contains stable ruleId for auditability, plain-English explanation, and matching evidence.
 */
data class FindingIndicator(
    val ruleId: String,
    val title: String,
    val severity: IndicatorSeverity,
    val explanation: String,
    val evidenceQuote: String,
    val caveat: String = ""
)
