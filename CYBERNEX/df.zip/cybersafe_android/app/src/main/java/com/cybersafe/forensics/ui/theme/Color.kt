package com.cybersafe.forensics.ui.theme

import androidx.compose.ui.graphics.Color

val Blue80 = Color(0xFFBAE6FD)
val BlueGrey80 = Color(0xFFCBD5E1)
val Cyan80 = Color(0xFFA5F3FC)

val Blue40 = Color(0xFF0284C7)
val BlueGrey40 = Color(0xFF64748B)
val Cyan40 = Color(0xFF0891B2)

val DarkBackground = Color(0xFF0B132B)
val DarkSurface = Color(0xFF1C2541)
val DarkSurfaceVariant = Color(0xFF3A506B)

val ThreatHigh = Color(0xFFEF4444)
val ThreatCaution = Color(0xFFF59E0B)
val ThreatLow = Color(0xFF10B981)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
