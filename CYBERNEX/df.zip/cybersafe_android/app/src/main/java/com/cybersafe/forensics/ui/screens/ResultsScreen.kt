package com.cybersafe.forensics.ui.screens

import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cybersafe.forensics.data.model.RiskLevel
import com.cybersafe.forensics.ui.viewmodel.CyberSafeViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ResultsScreen(
    viewModel: CyberSafeViewModel,
    onNavigateHome: () -> Unit
) {
    val state by viewModel.uiState.collectAsState()
    val result = state.currentResult
    val context = LocalContext.current
    var isExpertDetailsExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Result", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateHome) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back to Home")
                    }
                },
                actions = {
                    if (result != null) {
                        IconButton(onClick = {
                            val shareText = viewModel.buildShareableReport(result)
                            val sendIntent = Intent().apply {
                                action = Intent.ACTION_SEND
                                putExtra(Intent.EXTRA_TEXT, shareText)
                                type = "text/plain"
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Share CyberSafe Report"))
                        }) {
                            Icon(Icons.Default.Share, contentDescription = "Share report")
                        }
                    }
                }
            )
        }
    ) { padding ->
        if (result == null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("No check results available.", fontSize = 16.sp)
                    Spacer(modifier = Modifier.height(16.dp))
                    Button(onClick = onNavigateHome) {
                        Text("Back to Home")
                    }
                }
            }
            return@Scaffold
        }

        // Color & text styling strictly aligned with Play Store / Common-User safety rules
        val verdictTheme = when (result.riskLevel) {
            RiskLevel.HIGH_WARNING -> {
                VerdictVisual(
                    containerColor = Color(0xFFDC2626), // Red
                    contentColor = Color.White,
                    icon = Icons.Default.Dangerous,
                    headline = "Dangerous",
                    subtitle = "Do not open this link or reply.",
                    adviceTitle = "Why this is dangerous"
                )
            }
            RiskLevel.CAUTION -> {
                VerdictVisual(
                    containerColor = Color(0xFFD97706), // Orange
                    contentColor = Color.White,
                    icon = Icons.Default.Warning,
                    headline = "Suspicious",
                    subtitle = "Be careful. Proceed with caution.",
                    adviceTitle = "Why this looks suspicious"
                )
            }
            RiskLevel.LOW_WARNING -> {
                VerdictVisual(
                    containerColor = Color(0xFF16A34A), // Green
                    contentColor = Color.White,
                    icon = Icons.Default.CheckCircle,
                    headline = "No warning signs found",
                    subtitle = "Still stay alert. Never share OTPs or PINs.",
                    adviceTitle = "Important safety reminders"
                )
            }
            RiskLevel.INVALID_INPUT -> {
                VerdictVisual(
                    containerColor = Color(0xFF64748B), // Slate Grey
                    contentColor = Color.White,
                    icon = Icons.Default.Info,
                    headline = "Could Not Check",
                    subtitle = "The input text was empty or unsupported.",
                    adviceTitle = "Guidance"
                )
            }
        }

        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 18.dp, vertical = 12.dp)
        ) {
            // ─────────────────────────────────────────────────────────────
            // 1. BIG COLOR VERDICT CARD
            // ─────────────────────────────────────────────────────────────
            Card(
                colors = CardDefaults.cardColors(containerColor = verdictTheme.containerColor),
                shape = RoundedCornerShape(18.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp, horizontal = 20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        imageVector = verdictTheme.icon,
                        contentDescription = verdictTheme.headline,
                        tint = verdictTheme.contentColor,
                        modifier = Modifier.size(60.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = verdictTheme.headline,
                        color = verdictTheme.contentColor,
                        fontWeight = FontWeight.ExtraBold,
                        fontSize = 24.sp,
                        textAlign = TextAlign.Center
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = verdictTheme.subtitle,
                        color = verdictTheme.contentColor.copy(alpha = 0.95f),
                        fontWeight = FontWeight.Medium,
                        fontSize = 15.sp,
                        textAlign = TextAlign.Center,
                        lineHeight = 20.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ─────────────────────────────────────────────────────────────
            // 2. 2 TO 3 PLAIN-LANGUAGE REASONS
            // ─────────────────────────────────────────────────────────────
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = verdictTheme.adviceTitle,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val plainReasons = extractPlainLanguageReasons(result)
                    plainReasons.take(3).forEach { reason ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Text(
                                text = "• ",
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary,
                                fontSize = 16.sp
                            )
                            Text(
                                text = reason,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurface,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ─────────────────────────────────────────────────────────────
            // 3. IMMEDIATE SAFE ACTIONS ("What should I do?")
            // ─────────────────────────────────────────────────────────────
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surface
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "What should you do right now?",
                        fontWeight = FontWeight.Bold,
                        fontSize = 14.5.sp,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    if (result.riskLevel == RiskLevel.HIGH_WARNING || result.riskLevel == RiskLevel.CAUTION) {
                        ActionItem(
                            number = "1",
                            boldText = "Do not tap any link or download attachments.",
                            subText = "Delete this message immediately from your chats."
                        )
                        ActionItem(
                            number = "2",
                            boldText = "Never share OTP, PIN, or card details.",
                            subText = "Official banks, electricity boards, and courier services will never ask for them."
                        )
                        ActionItem(
                            number = "3",
                            boldText = "If you already sent money or entered passwords:",
                            subText = "Call 1930 (National Cyber Crime Helpline) or contact your bank immediately to block transactions."
                        )
                    } else {
                        ActionItem(
                            number = "1",
                            boldText = "Stay vigilant.",
                            subText = "Always verify the sender's identity before making payments or sharing private information."
                        )
                        ActionItem(
                            number = "2",
                            boldText = "Remember:",
                            subText = "A green padlock (HTTPS) only encrypts communication; it does not guarantee the site is benign."
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // ─────────────────────────────────────────────────────────────
            // 4. COLLAPSED "DETAILS FOR EXPERTS" SECTION
            // ─────────────────────────────────────────────────────────────
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f)
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { isExpertDetailsExpanded = !isExpertDetailsExpanded },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Code,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Details for experts",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Icon(
                            imageVector = if (isExpertDetailsExpanded) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = if (isExpertDetailsExpanded) "Collapse details" else "Expand details",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    AnimatedVisibility(
                        visible = isExpertDetailsExpanded,
                        enter = fadeIn() + expandVertically(),
                        exit = fadeOut() + shrinkVertically()
                    ) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = "Analyzed Snippet:",
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 11.5.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(4.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text(
                                    text = result.sanitizedSnippet,
                                    modifier = Modifier.padding(8.dp),
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            if (result.indicators.isNotEmpty()) {
                                Text(
                                    text = "Triggered Rule Identifiers (${result.indicators.size}):",
                                    fontWeight = FontWeight.SemiBold,
                                    fontSize = 11.5.sp,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                result.indicators.forEach { ind ->
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(bottom = 8.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Text(
                                                text = ind.title,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp
                                            )
                                            Text(
                                                text = ind.ruleId,
                                                fontFamily = FontFamily.Monospace,
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                        if (ind.evidenceQuote.isNotBlank()) {
                                            Text(
                                                text = "Evidence: ${ind.evidenceQuote}",
                                                fontSize = 10.5.sp,
                                                fontFamily = FontFamily.Monospace,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        if (ind.caveat.isNotBlank()) {
                                            Text(
                                                text = "Caveat: ${ind.caveat}",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                                            )
                                        }
                                    }
                                }
                            } else {
                                Text(
                                    text = "Deterministic heuristics: 0 flags triggered.",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Engine: 100% On-device Kotlin parser. Zero remote network transmission.",
                                fontSize = 10.5.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            Spacer(modifier = Modifier.height(20.dp))

            // ─────────────────────────────────────────────────────────────
            // 5. REPORT SCAM BUTTONS (1930 HELPLINE, CYBERCRIME.GOV.IN, COPY SANITIZED REPORT)
            // ─────────────────────────────────────────────────────────────
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.25f)
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.ReportProblem,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Report this Scam to Authorities",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "If you lost money or received an extortion threat, report it immediately to the Ministry of Home Affairs:",
                        fontSize = 12.5.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 17.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Call 1930 Dialer Button
                    FilledTonalButton(
                        onClick = {
                            val dialIntent = Intent(Intent.ACTION_DIAL).apply {
                                data = android.net.Uri.parse("tel:1930")
                            }
                            context.startActivity(dialIntent)
                        },
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = MaterialTheme.colorScheme.error,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Call 1930 Cyber Helpline", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Open cybercrime.gov.in Browser Button
                    OutlinedButton(
                        onClick = {
                            val portalIntent = Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://cybercrime.gov.in"))
                            context.startActivity(portalIntent)
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Open cybercrime.gov.in Portal", fontSize = 13.5.sp)
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Copy Sanitized Report Button
                    val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
                    var copyConfirmed by remember { mutableStateOf(false) }

                    OutlinedButton(
                        onClick = {
                            val sanitizedDossier = com.cybersafe.forensics.utils.ReportSanitizer.buildSanitizedComplaintText(result)
                            clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(sanitizedDossier))
                            copyConfirmed = true
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(
                            if (copyConfirmed) Icons.Default.Check else Icons.Default.ContentCopy,
                            contentDescription = null,
                            modifier = Modifier.size(18.dp),
                            tint = if (copyConfirmed) Color(0xFF16A34A) else MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (copyConfirmed) "Sanitized Report Copied!" else "Copy Sanitized Report (No OTPs/Cards)",
                            fontSize = 13.sp,
                            fontWeight = if (copyConfirmed) FontWeight.Bold else FontWeight.Normal
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // ─────────────────────────────────────────────────────────────
            // 6. ACTION BUTTONS
            // ─────────────────────────────────────────────────────────────
            Button(
                onClick = onNavigateHome,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp),
                shape = RoundedCornerShape(10.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text("Check Another Link or Message", fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            }
        }
    }
}

@Composable
private fun ActionItem(number: String, boldText: String, subText: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(20.dp)
                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = number,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.primary
            )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(
                text = boldText,
                fontWeight = FontWeight.SemiBold,
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = subText,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                lineHeight = 16.sp
            )
        }
    }
}

/**
 * Extracts 2 to 3 plain-English, non-technical explanations directly from the scan findings.
 * Avoids jargon like RFC822, entropy, and heuristics.
 */
private fun extractPlainLanguageReasons(result: com.cybersafe.forensics.data.model.AnalysisResult): List<String> {
    if (result.indicators.isEmpty()) {
        return listOf(
            "No known scam links, urgent payment threats, or credential requests were found.",
            "Official banks and agencies never ask for passwords or OTPs over chat or phone.",
            "Always verify any unexpected request directly through the official website or customer support."
        )
    }

    val reasons = mutableListOf<String>()
    for (ind in result.indicators) {
        when {
            ind.ruleId.contains("IP_HOST") -> {
                reasons.add("The link uses raw numbers instead of a real company website name.")
            }
            ind.ruleId.contains("CREDENTIAL") || ind.ruleId.contains("OTP") -> {
                reasons.add("The message asks for an OTP, password, or login credentials. Banks never ask for secret codes.")
            }
            ind.ruleId.contains("URGENCY") -> {
                reasons.add("The message creates fake panic (e.g. 'account blocked', 'power cut tonight') to pressure you into acting without thinking.")
            }
            ind.ruleId.contains("PAYMENT") || ind.ruleId.contains("UPI") -> {
                reasons.add("The message asks you to pay money or approve a payment request.")
            }
            ind.ruleId.contains("SUBDOMAIN") -> {
                reasons.add("The link pretends to belong to a trusted brand, but the real destination is a different website.")
            }
            ind.ruleId.contains("HTTP_UNENCRYPTED") -> {
                reasons.add("The link is unencrypted (HTTP), making any information you type visible to outsiders.")
            }
            else -> {
                reasons.add(ind.explanation)
            }
        }
    }

    return reasons.distinct()
}

private data class VerdictVisual(
    val containerColor: Color,
    val contentColor: Color,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val headline: String,
    val subtitle: String,
    val adviceTitle: String
)
