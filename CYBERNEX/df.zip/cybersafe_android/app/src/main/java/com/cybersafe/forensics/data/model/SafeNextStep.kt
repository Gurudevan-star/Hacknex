package com.cybersafe.forensics.data.model

/**
 * Proportionate, non-alarmist practical next step recommendation for common users.
 */
data class SafeNextStep(
    val priority: Int,
    val action: String,
    val description: String
)
