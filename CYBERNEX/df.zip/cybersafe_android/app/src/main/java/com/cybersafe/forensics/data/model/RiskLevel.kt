package com.cybersafe.forensics.data.model

/**
 * Risk classification for on-device analysis.
 * Explicitly designed as non-definitive warning levels for common users.
 * Never claims an input is 100% definitively safe or definitively fraudulent.
 */
enum class RiskLevel(val displayName: String, val badgeColorHex: String) {
    HIGH_WARNING(
        displayName = "High Warning Sign",
        badgeColorHex = "#EF4444"
    ),
    CAUTION(
        displayName = "Caution Advised",
        badgeColorHex = "#F59E0B"
    ),
    LOW_WARNING(
        displayName = "Low Warning",
        badgeColorHex = "#10B981"
    ),
    INVALID_INPUT(
        displayName = "Invalid Input",
        badgeColorHex = "#64748B"
    )
}
