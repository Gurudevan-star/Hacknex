package com.cybersafe.forensics.data.model

enum class ScanType(val label: String) {
    URL("Web Link"),
    MESSAGE("Message / Text"),
    FILE_EML("Email (.eml) File")
}
