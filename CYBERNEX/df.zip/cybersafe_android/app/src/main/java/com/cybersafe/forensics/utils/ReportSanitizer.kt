package com.cybersafe.forensics.utils

import com.cybersafe.forensics.data.model.AnalysisResult

/**
 * Utility for sanitizing and preparing privacy-first scam incident reports.
 * 
 * CRITICAL PRIVACY & SECURITY RULES:
 * - Redacts 4-6 digit OTPs, PINs, and MPINs.
 * - Redacts 16-digit credit/debit card numbers.
 * - Redacts 10-digit mobile phone numbers.
 * - Redacts sensitive URL parameters (tokens, passwords, session IDs).
 */
object ReportSanitizer {

    private val OTP_REGEX = Regex("\\b\\d{4,6}\\b")
    private val CARD_REGEX = Regex("\\b\\d{4}[ -]?\\d{4}[ -]?\\d{4}[ -]?\\d{4}\\b")
    private val PHONE_REGEX = Regex("\\b(?:\\+91[ -]?)?[6-9]\\d{9}\\b")
    private val URL_AUTH_PARAM_REGEX = Regex("(?i)([?&](token|auth|password|pwd|pass|key|secret)=)[^&\\s]+")

    /**
     * Replaces sensitive private data with privacy redaction markers.
     */
    fun sanitizeText(rawText: String): String {
        var text = rawText
        // Redact Credit / Debit Card Numbers first (longer digit sequences)
        text = text.replace(CARD_REGEX, "[REDACTED_CARD_NUMBER]")
        // Redact Phone Numbers
        text = text.replace(PHONE_REGEX, "[REDACTED_PHONE_NUMBER]")
        // Redact URL Auth query parameters
        text = text.replace(URL_AUTH_PARAM_REGEX, "$1[REDACTED_TOKEN]")
        // Redact 4 to 6 digit OTP / PIN codes
        text = text.replace(OTP_REGEX) { match ->
            val num = match.value
            // Keep common years (e.g. 2024, 2025, 2026) unredacted for context
            if (num.toIntOrNull() in 1950..2030) num else "[REDACTED_OTP_PIN]"
        }
        return text
    }

    /**
     * Builds a clean, official incident complaint text ready to copy or submit to 1930 / cybercrime.gov.in.
     */
    fun buildSanitizedComplaintText(result: AnalysisResult): String {
        val sb = StringBuilder()
        sb.append("=== CYBERSAFE INCIDENT COMPLAINT DOSSIER ===\n")
        sb.append("Incident Classification: ${result.riskLevel.displayName}\n")
        sb.append("Summary: ${result.summaryHeadline}\n\n")

        sb.append("--- SANITIZED EVIDENCE SNIPPET ---\n")
        sb.append("\"${sanitizeText(result.sanitizedSnippet)}\"\n\n")

        if (result.indicators.isNotEmpty()) {
            sb.append("--- DETECTED SCAM PATTERNS ---\n")
            for (ind in result.indicators) {
                sb.append("• [${ind.ruleId}] ${ind.title}\n")
                sb.append("  Explanation: ${ind.explanation}\n")
            }
            sb.append("\n")
        }

        sb.append("--- SAFE ACTIONS ADVICE ---\n")
        for (step in result.nextSteps) {
            sb.append("${step.priority}. ${step.action}: ${step.description}\n")
        }

        sb.append("\n============================================\n")
        sb.append("National Cyber Crime Helpline: 1930\n")
        sb.append("National Cyber Crime Reporting Portal: https://cybercrime.gov.in\n")
        sb.append("Note: Generated offline on-device by CyberSafe with sensitive credentials redacted.")
        return sb.toString()
    }
}
