package com.cybersafe.forensics

import android.app.Application
import com.cybersafe.forensics.data.local.CyberSafeDatabase
import com.cybersafe.forensics.data.repository.AnalysisRepository
import com.cybersafe.forensics.data.repository.HistoryRepository

class CyberSafeApp : Application() {

    lateinit var database: CyberSafeDatabase
        private set

    lateinit var historyRepository: HistoryRepository
        private set

    lateinit var analysisRepository: AnalysisRepository
        private set

    override fun onCreate() {
        super.onCreate()
        database = CyberSafeDatabase.getDatabase(this)
        historyRepository = HistoryRepository(database.historyDao())
        analysisRepository = AnalysisRepository()
    }
}
