package com.cybersafe.forensics.scanner

import android.content.Context
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

/**
 * QR Code Scanner implementation powered by Google Play Services Code Scanner API.
 * 
 * CRITICAL PRIVACY ARCHITECTURE:
 * - Requires ZERO camera permission in AndroidManifest.xml.
 * - Google Play Services handles the camera UI and barcode decoding in a sandboxed dialog.
 * - Only the decoded text/URL string is returned to CyberSafe for on-device threat evaluation.
 */
object QrCodeScanner {

    fun scanQrCode(
        context: Context,
        onSuccess: (decodedValue: String) -> Unit,
        onCanceled: () -> Unit = {},
        onFailure: (errorMessage: String) -> Unit = {}
    ) {
        val options = GmsBarcodeScannerOptions.Builder()
            .allowManualInput() // Allows entering code manually if camera/lighting fails
            .build()

        val scanner = GmsBarcodeScanning.getClient(context, options)

        scanner.startScan()
            .addOnSuccessListener { barcode ->
                val rawValue = barcode.rawValue ?: barcode.displayValue ?: ""
                if (rawValue.isNotBlank()) {
                    onSuccess(rawValue)
                } else {
                    onFailure("Could not read QR code content.")
                }
            }
            .addOnCanceledListener {
                onCanceled()
            }
            .addOnFailureListener { exception ->
                onFailure(exception.localizedMessage ?: "QR code scanning failed.")
            }
    }
}
