package com.cybersafe.forensics.data.repository

import com.cybersafe.forensics.analysis.LocalAnalysisEngine
import com.cybersafe.forensics.data.model.AnalysisResult

class AnalysisRepository {

    suspend fun analyze(
        input: String,
        onProgress: (stepDescription: String, progressFraction: Float) -> Unit = { _, _ -> }
    ): AnalysisResult {
        return LocalAnalysisEngine.analyze(input, onProgress)
    }
}
