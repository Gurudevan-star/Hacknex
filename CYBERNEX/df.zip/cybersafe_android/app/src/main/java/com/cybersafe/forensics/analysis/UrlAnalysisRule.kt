package com.cybersafe.forensics.analysis

import com.cybersafe.forensics.data.model.FindingIndicator
import com.cybersafe.forensics.data.model.IndicatorSeverity
import java.net.URI

object UrlAnalysisRule {

    private val IPV4_REGEX = Regex("^(\\d{1,3}\\.){3}\\d{1,3}$")
    private val SUSPICIOUS_TLDS = setOf(
        "xyz", "top", "icu", "tk", "ml", "cf", "gq", "buzz", "club", "work", "fit", "rest", "cam", "live", "vip"
    )
    private val URL_SHORTENERS = setOf(
        "bit.ly", "tinyurl.com", "is.gd", "t.co", "rebrand.ly", "rb.gy", "s.id", "cutt.ly", "shorturl.at", "ow.ly", "buff.ly"
    )
    private val TRUSTED_BRANDS = mapOf(
        "sbi" to listOf("sbi.co.in", "onlinesbi.sbi", "onlinesbi.com"),
        "hdfc" to listOf("hdfcbank.com"),
        "icici" to listOf("icicibank.com"),
        "axis" to listOf("axisbank.com"),
        "pnb" to listOf("pnbindia.in"),
        "paytm" to listOf("paytm.com"),
        "phonepe" to listOf("phonepe.com"),
        "gpay" to listOf("google.com"),
        "google" to listOf("google.com", "google.co.in"),
        "amazon" to listOf("amazon.in", "amazon.com"),
        "flipkart" to listOf("flipkart.com"),
        "apple" to listOf("apple.com"),
        "microsoft" to listOf("microsoft.com"),
        "netflix" to listOf("netflix.com"),
        "irctc" to listOf("irctc.co.in")
    )
    private val CREDENTIAL_PATH_KEYWORDS = listOf(
        "login", "signin", "sign-in", "log-in", "verify", "verification",
        "account", "update", "banking", "secure", "password", "wallet",
        "confirm", "authenticate", "wp-login", "wp-admin", "kyc", "pan-update"
    )

    fun analyzeUrl(rawUrl: String): List<FindingIndicator> {
        val indicators = mutableListOf<FindingIndicator>()
        var normalized = rawUrl.trim()
        if (!normalized.startsWith("http://", ignoreCase = true) &&
            !normalized.startsWith("https://", ignoreCase = true)
        ) {
            normalized = "http://$normalized"
        }

        val uri = try {
            URI(normalized)
        } catch (e: Exception) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_MALFORMED_URL",
                    title = "Malformed URL Structure",
                    severity = IndicatorSeverity.MEDIUM,
                    explanation = "The web address has unusual or malformed syntax that deviates from standard internet link conventions.",
                    evidenceQuote = rawUrl,
                    caveat = "Could be caused by a typographical error or intentional obfuscation."
                )
            )
            return indicators
        }

        val host = (uri.host ?: "").lowercase()
        val scheme = (uri.scheme ?: "").lowercase()
        val path = (uri.path ?: "").lowercase()
        val rawUserInfo = uri.userInfo ?: ""
        val port = uri.port

        // 1. IP Address as Host
        if (IPV4_REGEX.matches(host) || host.startsWith("[") && host.endsWith("]")) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_IP_HOST",
                    title = "Direct IP Address Host",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The link points directly to a raw numerical IP address ($host) rather than a verified registered domain name. Legitimate organizations almost always use official domain names.",
                    evidenceQuote = host,
                    caveat = "Internal network devices may legitimately use IP addresses, but public web services rarely do."
                )
            )
        }

        // 2. "@" Symbol in URL (Credential / Authority Obfuscation)
        if (rawUrl.contains("@") || rawUserInfo.isNotEmpty()) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_AT_SYMBOL_OBFUSCATION",
                    title = "Deceptive '@' Authority Prefix",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The link contains an '@' character. Browsers ignore everything before '@' and connect directly to the destination after it. Attackers use this to display trusted names like 'google.com@evil.com'.",
                    evidenceQuote = rawUrl,
                    caveat = "URLs rarely use the @ syntax except in malicious URL spoofing."
                )
            )
        }

        // 3. Brand Name in Wrong Domain (Impersonation)
        for ((brand, validDomains) in TRUSTED_BRANDS) {
            if (host.contains(brand)) {
                val isLegitimate = validDomains.any { host == it || host.endsWith(".$it") }
                if (!isLegitimate) {
                    indicators.add(
                        FindingIndicator(
                            ruleId = "RULE_BRAND_IMPERSONATION",
                            title = "Brand Impersonation ($brand)",
                            severity = IndicatorSeverity.HIGH,
                            explanation = "The link mentions '$brand', but the real website domain ($host) does not belong to the official company domain (${validDomains.first()}).",
                            evidenceQuote = host,
                            caveat = "Attackers register similar-sounding domains to deceive users."
                        )
                    )
                    break
                }
            }
        }

        // 4. URL Shortener Service (Hidden Destination)
        if (URL_SHORTENERS.contains(host)) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_URL_SHORTENER",
                    title = "Shortened Link (Hidden Destination)",
                    severity = IndicatorSeverity.MEDIUM,
                    explanation = "The web address uses a shortening service ($host) which conceals the real final destination page until you click it.",
                    evidenceQuote = host,
                    caveat = "Legitimate marketers also shorten links to save space, but scammers use them to hide phishing destinations."
                )
            )
        }

        // 5. Punycode / Internationalized Domain Impersonation
        if (host.contains("xn--", ignoreCase = true)) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_PUNYCODE_HOMOGLYPH",
                    title = "Punycode Character Impersonation",
                    severity = IndicatorSeverity.HIGH,
                    explanation = "The domain name contains punycode ('xn--'), which can look identical to a legitimate company name on your screen while directing your browser to an attacker's website.",
                    evidenceQuote = host,
                    caveat = "Punycode is also legitimately used for non-Latin writing scripts (e.g., Cyrillic, Chinese, Arabic)."
                )
            )
        }

        // 6. Excessive Subdomains or Misleading Brand Prefixes
        val hostLabels = host.split(".")
        if (hostLabels.size >= 4 && !IPV4_REGEX.matches(host)) {
            val potentialDeceptivePrefix = hostLabels.dropLast(2).joinToString(".")
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_EXCESSIVE_SUBDOMAINS",
                    title = "Deceptive Subdomain Structure",
                    severity = IndicatorSeverity.MEDIUM,
                    explanation = "The web address uses multiple subdomain prefixes ($potentialDeceptivePrefix). Attackers frequently include names like 'paypal.com' or 'apple' as prefixes to trick users about the actual destination domain.",
                    evidenceQuote = host,
                    caveat = "Large content delivery networks (CDNs) also use long subdomain structures."
                )
            )
        }

        // 7. Suspicious or High-Abuse TLDs
        val tld = hostLabels.lastOrNull() ?: ""
        if (SUSPICIOUS_TLDS.contains(tld)) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_SUSPICIOUS_TLD",
                    title = "High-Risk Top-Level Domain (.$tld)",
                    severity = IndicatorSeverity.MEDIUM,
                    explanation = "The domain ends with '.$tld'. This top-level domain extension is heavily abused for low-cost, disposable scam campaigns.",
                    evidenceQuote = host,
                    caveat = "Some startups or benign websites also register inexpensive modern TLDs."
                )
            )
        }

        // 8. Credential-Related Path Keywords
        val foundPathKeyword = CREDENTIAL_PATH_KEYWORDS.firstOrNull { path.contains(it) }
        if (foundPathKeyword != null) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_CREDENTIAL_PATH",
                    title = "Credential Entry Page Path",
                    severity = IndicatorSeverity.MEDIUM,
                    explanation = "The link points to a page path containing '$foundPathKeyword'. If this was received unexpectedly, verify the sender before typing any login information.",
                    evidenceQuote = path,
                    caveat = "Legitimate login pages also contain these keywords; check if you expected this link."
                )
            )
        }

        // 9. Unencrypted HTTP Protocol Warning
        if (scheme == "http") {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_HTTP_UNENCRYPTED",
                    title = "Unencrypted Connection (HTTP)",
                    severity = IndicatorSeverity.LOW,
                    explanation = "The website communicates over unencrypted HTTP protocol. Warning: Note that modern phishing sites also frequently use HTTPS, so HTTPS alone does NOT guarantee safety.",
                    evidenceQuote = scheme,
                    caveat = "HTTPS only confirms encryption in transit; it does not confirm who owns the site."
                )
            )
        }

        // 10. Non-Standard Port
        if (port != -1 && port != 80 && port != 443 && port != 8080) {
            indicators.add(
                FindingIndicator(
                    ruleId = "RULE_NON_STANDARD_PORT",
                    title = "Non-Standard Web Port (:$port)",
                    severity = IndicatorSeverity.MEDIUM,
                    explanation = "The link specifies an unusual network port ($port) rather than standard web ports (80 or 443).",
                    evidenceQuote = ":$port",
                    caveat = "Private developer test servers often use custom ports."
                )
            )
        }

        return indicators
    }
}
