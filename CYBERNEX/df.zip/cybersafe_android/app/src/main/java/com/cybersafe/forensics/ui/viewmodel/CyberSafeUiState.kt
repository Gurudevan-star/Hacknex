package com.cybersafe.forensics.ui.viewmodel

import com.cybersafe.forensics.data.local.HistoryEntity
import com.cybersafe.forensics.data.model.AnalysisResult

data class CyberSafeUiState(
    val inputText: String = "",
    val isAnalyzing: Boolean = false,
    val analysisStep: String = "",
    val analysisProgress: Float = 0f,
    val currentResult: AnalysisResult? = null,
    val historyList: List<HistoryEntity> = emptyList(),
    val saveHistoryEnabled: Boolean = true,
    val statusMessage: String? = null
)
