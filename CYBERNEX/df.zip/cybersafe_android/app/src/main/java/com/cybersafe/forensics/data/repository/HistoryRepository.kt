package com.cybersafe.forensics.data.repository

import com.cybersafe.forensics.data.local.HistoryDao
import com.cybersafe.forensics.data.local.HistoryEntity
import com.cybersafe.forensics.data.model.AnalysisResult
import kotlinx.coroutines.flow.Flow

class HistoryRepository(private val historyDao: HistoryDao) {

    val allHistory: Flow<List<HistoryEntity>> = historyDao.getAllHistory()
    val historyCount: Flow<Int> = historyDao.getHistoryCount()

    suspend fun saveScanResult(result: AnalysisResult): Long {
        val entity = HistoryEntity(
            id = result.id,
            timestamp = result.timestamp,
            scanType = result.scanType.label,
            sanitizedSnippet = result.sanitizedSnippet,
            riskLevel = result.riskLevel.name,
            summaryHeadline = result.summaryHeadline,
            indicatorsCount = result.indicators.size,
            isOfflineVerified = result.isOfflineVerified
        )
        return historyDao.insert(entity)
    }

    suspend fun deleteScanById(id: String): Int {
        return historyDao.deleteById(id)
    }

    suspend fun clearAllHistory(): Int {
        return historyDao.clearAll()
    }
}
