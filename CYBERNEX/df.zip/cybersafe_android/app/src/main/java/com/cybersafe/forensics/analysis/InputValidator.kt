package com.cybersafe.forensics.analysis

import com.cybersafe.forensics.data.model.ScanType
import java.net.URI

object InputValidator {

    const val MAX_INPUT_LENGTH = 100_000

    sealed class ValidationResult {
        data class Valid(val sanitizedText: String, val scanType: ScanType, val detectedUrls: List<String>) : ValidationResult()
        data class Invalid(val reason: String) : ValidationResult()
    }

    private val URL_REGEX = Regex(
        "(?i)\\b(?:https?://|ftp://|www\\.)[a-z0-9+&@#/%?=~_|!:,.;-]*[a-z0-9+&@#/%=~_|]",
        RegexOption.IGNORE_CASE
    )

    private val SENSITIVE_QUERY_PARAMS = listOf(
        "token", "password", "pwd", "auth", "key", "secret", "session", "code", "pin", "otp"
    )

    fun validate(raw: String?): ValidationResult {
        if (raw == null || raw.trim().isEmpty()) {
            return ValidationResult.Invalid("Input is empty. Please paste a link or message to inspect.")
        }

        val trimmed = raw.trim()
        if (trimmed.length > MAX_INPUT_LENGTH) {
            return ValidationResult.Invalid("Input exceeds maximum allowed size (100,000 characters). Please paste a shorter excerpt.")
        }

        val foundUrls = URL_REGEX.findAll(trimmed).map { it.value }.toList()

        // Check if the input is exclusively a single URL or primarily text message
        val isSingleUrl = foundUrls.size == 1 && (trimmed.startsWith("http://") || trimmed.startsWith("https://") || trimmed.startsWith("www."))
        val scanType = if (isSingleUrl) ScanType.URL else ScanType.MESSAGE

        val sanitized = sanitizePreview(trimmed)

        return ValidationResult.Valid(
            sanitizedText = sanitized,
            scanType = scanType,
            detectedUrls = foundUrls
        )
    }

    /**
     * Sanitizes input snippet to avoid storing or displaying sensitive authorization tokens/credentials.
     */
    fun sanitizePreview(text: String): String {
        var clean = text
        for (param in SENSITIVE_QUERY_PARAMS) {
            val pattern = Regex("([?&]$param=)[^&\\s]+", RegexOption.IGNORE_CASE)
            clean = clean.replace(pattern, "$1[REDACTED]")
        }
        return if (clean.length > 500) {
            clean.take(497) + "..."
        } else {
            clean
        }
    }
}
