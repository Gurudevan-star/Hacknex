package com.cybersafe.forensics

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.cybersafe.forensics.ui.navigation.Screen
import com.cybersafe.forensics.ui.screens.*
import com.cybersafe.forensics.ui.theme.CyberSafeTheme
import com.cybersafe.forensics.ui.viewmodel.CyberSafeViewModel

class MainActivity : ComponentActivity() {

    private lateinit var viewModel: CyberSafeViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val app = application as CyberSafeApp
        val factory = object : ViewModelProvider.Factory {
            override fun <T : ViewModel> create(modelClass: Class<T>): T {
                @Suppress("UNCHECKED_CAST")
                return CyberSafeViewModel(
                    analysisRepository = app.analysisRepository,
                    historyRepository = app.historyRepository
                ) as T
            }
        }
        viewModel = ViewModelProvider(this, factory)[CyberSafeViewModel::class.java]

        setContent {
            CyberSafeTheme {
                val navController = rememberNavController()

                // Instantly navigate to results when shared text is processed
                LaunchedEffect(Unit) {
                    viewModel.navigationEvent.collect { route ->
                        navController.navigate(route) {
                            launchSingleTop = true
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = Screen.Home.route
                ) {
                    composable(Screen.Home.route) {
                        HomeScreen(
                            viewModel = viewModel,
                            onNavigateToAnalysis = {
                                navController.navigate(Screen.Analysis.route)
                            },
                            onNavigateToHistory = {
                                navController.navigate(Screen.History.route)
                            },
                            onNavigateToSafetyTips = {
                                navController.navigate(Screen.SafetyTips.route)
                            },
                            onNavigateToSettings = {
                                navController.navigate(Screen.SettingsPrivacy.route)
                            }
                        )
                    }

                    composable(Screen.Analysis.route) {
                        AnalysisScreen(
                            viewModel = viewModel,
                            onAnalysisFinished = {
                                navController.navigate(Screen.Results.route) {
                                    popUpTo(Screen.Home.route)
                                }
                            },
                            onCancel = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.Results.route) {
                        ResultsScreen(
                            viewModel = viewModel,
                            onNavigateHome = {
                                navController.navigate(Screen.Home.route) {
                                    popUpTo(Screen.Home.route) { inclusive = true }
                                }
                            }
                        )
                    }

                    composable(Screen.History.route) {
                        HistoryScreen(
                            viewModel = viewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.SafetyTips.route) {
                        SafetyTipsScreen(
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }

                    composable(Screen.SettingsPrivacy.route) {
                        SettingsPrivacyScreen(
                            viewModel = viewModel,
                            onNavigateBack = {
                                navController.popBackStack()
                            }
                        )
                    }
                }
            }
        }

        // Process cold-start incoming share intent
        handleIncomingIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        // Process warm-start incoming share intent
        handleIncomingIntent(intent)
    }

    /**
     * Extracts text from ACTION_SEND (WhatsApp, Telegram, SMS, Chrome share menu)
     * and ACTION_PROCESS_TEXT (Android context menu selection).
     * Triggers instant on-device analysis and routes straight to the verdict screen.
     */
    private fun handleIncomingIntent(intent: Intent?) {
        if (intent == null) return

        val textToAnalyze: String? = when (intent.action) {
            Intent.ACTION_SEND -> {
                if (intent.type?.startsWith("text/") == true || intent.type == "text/plain") {
                    intent.getStringExtra(Intent.EXTRA_TEXT)
                        ?: intent.getCharSequenceExtra(Intent.EXTRA_TEXT)?.toString()
                } else null
            }
            Intent.ACTION_PROCESS_TEXT -> {
                if (intent.type?.startsWith("text/") == true || intent.type == "text/plain") {
                    intent.getStringExtra(Intent.EXTRA_PROCESS_TEXT)
                        ?: intent.getCharSequenceExtra(Intent.EXTRA_PROCESS_TEXT)?.toString()
                } else null
            }
            else -> null
        }

        if (!textToAnalyze.isNullOrBlank()) {
            viewModel.handleIncomingSharedText(textToAnalyze)
        }
    }
}
