package com.cybersafe.forensics.ui.navigation

sealed class Screen(val route: String, val title: String) {
    object Home : Screen("home", "Home")
    object Analysis : Screen("analysis", "Analyzing")
    object Results : Screen("results", "Results")
    object History : Screen("history", "Scan History")
    object SafetyTips : Screen("safety_tips", "Safety Tips")
    object SettingsPrivacy : Screen("settings_privacy", "Privacy & Settings")
}
