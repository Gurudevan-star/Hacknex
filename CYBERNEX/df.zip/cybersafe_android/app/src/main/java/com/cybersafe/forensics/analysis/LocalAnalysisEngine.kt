package com.cybersafe.forensics.analysis

import com.cybersafe.forensics.data.model.AnalysisResult
import com.cybersafe.forensics.data.model.FindingIndicator
import com.cybersafe.forensics.data.model.IndicatorSeverity
import com.cybersafe.forensics.data.model.RiskLevel
import com.cybersafe.forensics.data.model.SafeNextStep
import com.cybersafe.forensics.data.model.ScanType
import kotlinx.coroutines.delay

object LocalAnalysisEngine {

    suspend fun analyze(
        rawInput: String,
        onProgress: (stepDescription: String, progressFraction: Float) -> Unit = { _, _ -> }
    ): AnalysisResult {
        // Step 1: Input Validation
        onProgress("Validating input format and safety boundaries...", 0.15f)
        delay(30)

        val validation = InputValidator.validate(rawInput)
        if (validation is InputValidator.ValidationResult.Invalid) {
            return AnalysisResult(
                scanType = ScanType.MESSAGE,
                sanitizedSnippet = rawInput.take(100),
                riskLevel = RiskLevel.INVALID_INPUT,
                summaryHeadline = "Could Not Check Input",
                indicators = listOf(
                    FindingIndicator(
                        ruleId = "RULE_INVALID_INPUT",
                        title = "Input Validation Failed",
                        severity = IndicatorSeverity.INFO,
                        explanation = validation.reason,
                        evidenceQuote = rawInput.take(50),
                        caveat = "Please verify your input and try again."
                    )
                ),
                nextSteps = listOf(
                    SafeNextStep(
                        priority = 1,
                        action = "Check Your Input",
                        description = "Please paste a complete message or link starting with http or https."
                    )
                ),
                limitations = listOf("No analysis could be performed on invalid input."),
                isOfflineVerified = true
            )
        }

        val valid = validation as InputValidator.ValidationResult.Valid
        val allIndicators = mutableListOf<FindingIndicator>()

        // Step 2: Deterministic URL Inspection (IP, punycode, subdomains, shorteners, @ symbol, brand mismatch)
        onProgress("Running deterministic web address checks...", 0.35f)
        delay(30)

        for (url in valid.detectedUrls) {
            val urlFindings = UrlAnalysisRule.analyzeUrl(url)
            allIndicators.addAll(urlFindings)
        }

        // Step 3: Generic Social-Engineering & Threat Checks
        onProgress("Inspecting text for urgency and credential lures...", 0.55f)
        delay(30)

        val messageFindings = MessageAnalysisRule.analyzeMessage(valid.sanitizedText)
        allIndicators.addAll(messageFindings)

        // Step 4: India-Specific Targeted Scam Heuristics (UPI, KYC, Electricity, Loan, AnyDesk, OTP)
        onProgress("Checking India-specific fraud signatures (UPI, KYC, Utilities, OTP)...", 0.75f)
        delay(30)

        val indiaFindings = IndiaScamRules.analyze(valid.sanitizedText)
        allIndicators.addAll(indiaFindings)

        // Step 5: On-Device Machine Learning Inference
        onProgress("Running on-device machine learning evaluation...", 0.90f)
        delay(30)

        val mlPrediction = OnDeviceMlClassifier.predict(valid.sanitizedText, valid.detectedUrls)

        // Add ML indicator if model detected high statistical risk
        if (mlPrediction.probability >= 0.65f) {
            allIndicators.add(
                FindingIndicator(
                    ruleId = "RULE_ON_DEVICE_ML_EVALUATION",
                    title = "Machine Learning Statistical Risk",
                    severity = if (mlPrediction.probability >= 0.85f) IndicatorSeverity.HIGH else IndicatorSeverity.MEDIUM,
                    explanation = "The on-device machine learning model detected strong statistical similarity to known phishing/scam patterns (model score: ${(mlPrediction.probability * 100).toInt()}%).",
                    evidenceQuote = "Key contributing factors: " + mlPrediction.topContributingFeatures.joinToString(", "),
                    caveat = "Statistical ML predictions assist detection but are always subordinate to deterministic facts."
                )
            )
        }

        // Step 6: Hybrid Verdict Synthesis
        // HARD RULE: A confirmed deterministic red flag ALWAYS wins over the ML score!
        onProgress("Synthesizing final verdict...", 1.0f)

        val deterministicHighCount = allIndicators.count { 
            it.severity == IndicatorSeverity.HIGH && it.ruleId != "RULE_ON_DEVICE_ML_EVALUATION" 
        }
        val deterministicMediumCount = allIndicators.count { 
            it.severity == IndicatorSeverity.MEDIUM && it.ruleId != "RULE_ON_DEVICE_ML_EVALUATION" 
        }
        val deterministicLowCount = allIndicators.count { 
            it.severity == IndicatorSeverity.LOW 
        }

        val riskLevel = when {
            // A confirmed deterministic red flag ALWAYS wins -> HIGH_WARNING (Dangerous)
            deterministicHighCount >= 1 -> RiskLevel.HIGH_WARNING

            // Secondary high risk: multiple medium deterministic flags or very strong ML score
            deterministicMediumCount >= 2 || (deterministicMediumCount >= 1 && mlPrediction.probability >= 0.60f) || mlPrediction.probability >= 0.80f -> RiskLevel.HIGH_WARNING

            // Suspicious / Caution: isolated medium indicator or moderate ML score
            deterministicMediumCount == 1 || deterministicLowCount >= 1 || mlPrediction.probability >= 0.50f -> RiskLevel.CAUTION

            // Clean baseline (No warning signs found)
            else -> RiskLevel.LOW_WARNING
        }

        val headline = when (riskLevel) {
            RiskLevel.HIGH_WARNING -> "Dangerous. Do not open this link or reply."
            RiskLevel.CAUTION -> "Suspicious. Be careful."
            RiskLevel.LOW_WARNING -> "No warning signs found. Still stay alert."
            RiskLevel.INVALID_INPUT -> "Invalid Input"
        }

        val nextSteps = buildProportionateNextSteps(riskLevel, allIndicators)
        val limitations = listOf(
            "Analysis executed 100% on-device in offline mode without querying external servers.",
            "Absence of detected warning signs does NOT guarantee that a message or website is legitimate.",
            "HTTPS (green lock) only encrypts communication; it does not prove the website is honest.",
            "Never share OTPs, PINs, or banking passwords with anyone under any circumstances."
        )

        return AnalysisResult(
            scanType = valid.scanType,
            sanitizedSnippet = valid.sanitizedText,
            riskLevel = riskLevel,
            summaryHeadline = headline,
            indicators = allIndicators,
            nextSteps = nextSteps,
            limitations = limitations,
            isOfflineVerified = true
        )
    }

    private fun buildProportionateNextSteps(
        riskLevel: RiskLevel,
        indicators: List<FindingIndicator>
    ): List<SafeNextStep> {
        val steps = mutableListOf<SafeNextStep>()

        when (riskLevel) {
            RiskLevel.HIGH_WARNING -> {
                steps.add(
                    SafeNextStep(
                        priority = 1,
                        action = "Do Not Interact",
                        description = "Do not click links, reply, or send money. Delete the message immediately."
                    )
                )
                steps.add(
                    SafeNextStep(
                        priority = 2,
                        action = "Never Share OTPs or PINs",
                        description = "Banks and genuine services will never ask you to disclose secret authentication codes."
                    )
                )
                steps.add(
                    SafeNextStep(
                        priority = 3,
                        action = "If Already Compromised",
                        description = "Call 1930 (Cyber Crime Helpline) or contact your bank immediately to block your card and netbanking."
                    )
                )
            }
            RiskLevel.CAUTION -> {
                steps.add(
                    SafeNextStep(
                        priority = 1,
                        action = "Verify Independently",
                        description = "Check directly with the sender through an official phone number or app, not using any link from this message."
                    )
                )
                steps.add(
                    SafeNextStep(
                        priority = 2,
                        action = "Do Not Enter Passwords",
                        description = "Never type passwords or payment card details on unverified pages."
                    )
                )
            }
            RiskLevel.LOW_WARNING, RiskLevel.INVALID_INPUT -> {
                steps.add(
                    SafeNextStep(
                        priority = 1,
                        action = "Stay Alert",
                        description = "Always remember that banks never ask for OTPs or PINs over SMS or chat."
                    )
                )
                steps.add(
                    SafeNextStep(
                        priority = 2,
                        action = "Double Check Links",
                        description = "Look closely at website spelling before entering any login information."
                    )
                )
            }
        }

        return steps
    }
}
