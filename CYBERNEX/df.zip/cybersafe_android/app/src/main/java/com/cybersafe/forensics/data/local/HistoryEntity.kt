package com.cybersafe.forensics.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local Room Entity for optional on-device scan history.
 * Never stores full private messages or raw passwords/tokens.
 */
@Entity(tableName = "scan_history")
data class HistoryEntity(
    @PrimaryKey
    val id: String,
    val timestamp: Long,
    val scanType: String,
    val sanitizedSnippet: String,
    val riskLevel: String,
    val summaryHeadline: String,
    val indicatorsCount: Int,
    val isOfflineVerified: Boolean
)
