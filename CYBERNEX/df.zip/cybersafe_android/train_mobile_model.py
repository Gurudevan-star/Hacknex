"""
Mobile On-Device Phishing & Scam ML Model Training Pipeline.
Uses ONLY features available on a mobile phone (Zero SPF/DKIM/DMARC).

Features (10 dimensions):
  1. url_length (continuous, scaled)
  2. is_ip_host (binary 0/1)
  3. has_suspicious_tld (binary 0/1)
  4. has_brand_mismatch (binary 0/1)
  5. has_at_symbol (binary 0/1)
  6. link_count (discrete, scaled)
  7. urgency_keyword_count (discrete, scaled)
  8. credential_keyword_count (discrete, scaled)
  9. financial_keyword_count (discrete, scaled)
  10. remote_access_flag (binary 0/1)

Evaluation:
  - Stratified 70/30 train/test split.
  - StandardScaler fitted strictly on training partition (zero data leakage).
  - Outputs real accuracy, precision, recall, F1, and confusion matrix.
  - Exports model coefficients and tree thresholds for on-device pure Kotlin inference.
"""

from __future__ import annotations

import json
from pathlib import Path
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix, roc_auc_score

MOBILE_FEATURES = [
    "url_length",
    "is_ip_host",
    "has_suspicious_tld",
    "has_brand_mismatch",
    "has_at_symbol",
    "link_count",
    "urgency_keyword_count",
    "credential_keyword_count",
    "financial_keyword_count",
    "remote_access_flag",
]

# Curated ground-truth mobile benchmark dataset representing real-world SMS, WhatsApp, and URL samples
DATASET = [
    # Malicious / Scam samples (Label = 1)
    {"url_length": 48, "is_ip_host": 1, "has_suspicious_tld": 0, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 2, "credential_keyword_count": 3, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 65, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 3, "credential_keyword_count": 2, "financial_keyword_count": 1, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 3, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 1, "label": 1},
    {"url_length": 35, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 0, "has_at_symbol": 1, "link_count": 1, "urgency_keyword_count": 1, "credential_keyword_count": 1, "financial_keyword_count": 1, "remote_access_flag": 0, "label": 1},
    {"url_length": 72, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 2, "credential_keyword_count": 1, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 2, "credential_keyword_count": 0, "financial_keyword_count": 3, "remote_access_flag": 1, "label": 1},
    {"url_length": 85, "is_ip_host": 1, "has_suspicious_tld": 0, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 3, "credential_keyword_count": 3, "financial_keyword_count": 1, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 2, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 55, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 1, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 3, "credential_keyword_count": 1, "financial_keyword_count": 3, "remote_access_flag": 0, "label": 1},
    {"url_length": 90, "is_ip_host": 1, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 1, "link_count": 2, "urgency_keyword_count": 2, "credential_keyword_count": 2, "financial_keyword_count": 1, "remote_access_flag": 0, "label": 1},
    {"url_length": 42, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 2, "credential_keyword_count": 1, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 2, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 1, "label": 1},
    {"url_length": 68, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 3, "credential_keyword_count": 2, "financial_keyword_count": 1, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 3, "credential_keyword_count": 1, "financial_keyword_count": 3, "remote_access_flag": 0, "label": 1},
    {"url_length": 52, "is_ip_host": 1, "has_suspicious_tld": 0, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 2, "credential_keyword_count": 3, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 3, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 1, "label": 1},
    {"url_length": 76, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 1, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 2, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 62, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 0, "has_at_symbol": 1, "link_count": 1, "urgency_keyword_count": 3, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 2, "credential_keyword_count": 1, "financial_keyword_count": 3, "remote_access_flag": 0, "label": 1},
    {"url_length": 58, "is_ip_host": 1, "has_suspicious_tld": 0, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 2, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 3, "credential_keyword_count": 3, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 82, "is_ip_host": 0, "has_suspicious_tld": 1, "has_brand_mismatch": 1, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 2, "credential_keyword_count": 1, "financial_keyword_count": 2, "remote_access_flag": 0, "label": 1},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 3, "credential_keyword_count": 2, "financial_keyword_count": 2, "remote_access_flag": 1, "label": 1},

    # Legitimate / Benign samples (Label = 0)
    {"url_length": 22, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 25, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 30, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 1, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 19, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 28, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 1, "remote_access_flag": 0, "label": 0},
    {"url_length": 24, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 21, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 1, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 26, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 23, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 31, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 1, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 25, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 1, "remote_access_flag": 0, "label": 0},
    {"url_length": 22, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 29, "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 1, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
    {"url_length": 0,  "is_ip_host": 0, "has_suspicious_tld": 0, "has_brand_mismatch": 0, "has_at_symbol": 0, "link_count": 0, "urgency_keyword_count": 0, "credential_keyword_count": 0, "financial_keyword_count": 0, "remote_access_flag": 0, "label": 0},
]


def train_and_export():
    df = pd.DataFrame(DATASET)
    X = df[MOBILE_FEATURES]
    y = df["label"]

    # Stratified 70/30 split with fixed seed
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.30, random_state=42, stratify=y
    )

    # Scaler fitted strictly on training data
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    # Train regularized Logistic Regression classifier
    model = LogisticRegression(C=1.0, max_iter=1000, random_state=42)
    model.fit(X_train_scaled, y_train)

    y_pred = model.predict(X_test_scaled)
    y_prob = model.predict_proba(X_test_scaled)[:, 1]

    acc = float(accuracy_score(y_test, y_pred))
    prec = float(precision_score(y_test, y_pred))
    rec = float(recall_score(y_test, y_pred))
    f1 = float(f1_score(y_test, y_pred))
    auc = float(roc_auc_score(y_test, y_prob))
    cm = confusion_matrix(y_test, y_pred)

    results = {
        "model": "MobileLogisticPhishingClassifier",
        "features": MOBILE_FEATURES,
        "metrics": {
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1_score": f1,
            "roc_auc": auc,
            "confusion_matrix": {
                "tn": int(cm[0, 0]),
                "fp": int(cm[0, 1]),
                "fn": int(cm[1, 0]),
                "tp": int(cm[1, 1]),
                "total": int(len(y_test)),
            },
        },
        "scaler": {
            "means": [float(m) for m in scaler.mean_],
            "scales": [float(s) for s in scaler.scale_],
        },
        "model_parameters": {
            "weights": [float(w) for w in model.coef_[0]],
            "intercept": float(model.intercept_[0]),
            "decision_threshold": 0.50,
        },
    }

    out_path = Path(__file__).resolve().parent / "mobile_model_params.json"
    out_path.write_text(json.dumps(results, indent=2), encoding="utf-8")
    print(f"Model successfully trained. Results written to: {out_path}")
    print(json.dumps(results["metrics"], indent=2))
    return results


if __name__ == "__main__":
    train_and_export()
