# CyberSafe — Offline-First Mobile Cyber Safety & Scam Warning Assistant (Android)

**CyberSafe** is an English-only, offline-first native Android application designed to help ordinary citizens detect phishing links, suspicious messages, and social engineering lures directly on their personal mobile devices.

The mobile application is deliberately partitioned into a separate, clean Android module (`cybersafe_android/`) that preserves and operates independently from the primary workstation Python forensics engine (`app/`, `ml/`).

---

## 1. Architectural Overview

```text
cybersafe_android/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── AndroidManifest.xml          # Zero invasive permissions; SAF file integration
│   │   │   ├── java/com/cybersafe/forensics/
│   │   │   │   ├── CyberSafeApp.kt          # Application initialization & Room setup
│   │   │   │   ├── MainActivity.kt          # Compose NavHost & Intent.ACTION_SEND handler
│   │   │   │   ├── data/
│   │   │   │   │   ├── model/               # Immutable Data Contracts (AnalysisResult, RiskLevel)
│   │   │   │   │   ├── local/               # Room Database (CyberSafeDatabase, HistoryDao)
│   │   │   │   │   └── repository/          # HistoryRepository, AnalysisRepository
│   │   │   │   ├── analysis/                # Deterministic On-Device Inspection Engine
│   │   │   │   │   ├── InputValidator.kt    # Size checks & sensitive token redaction
│   │   │   │   │   ├── UrlAnalysisRule.kt   # URI parsing, IP hosts, TLDs, punycode
│   │   │   │   │   ├── MessageAnalysisRule.kt # Urgency, fear, OTP solicitation detection
│   │   │   │   │   └── LocalAnalysisEngine.kt # Multi-step execution & proportionate next steps
│   │   │   │   └── ui/
│   │   │   │       ├── navigation/          # Screen navigation routes
│   │   │   │       ├── theme/               # Material 3 dark/light themes
│   │   │   │       ├── viewmodel/           # CyberSafeViewModel (MVVM)
│   │   │   │       └── screens/             # Home, Analysis, Results, History, SafetyTips, Privacy
│   │   │   └── res/                         # Strings, colors, vector icons
│   │   └── test/java/com/cybersafe/forensics/ # Automated Unit Tests
│   └── build.gradle.kts                     # App module build definition
├── build.gradle.kts                         # Root project build definition
└── settings.gradle.kts                      # Gradle settings & repository resolution
```

### Technology Stack
- **Language:** Kotlin (1.9.23)
- **UI Framework:** Jetpack Compose with Material 3
- **Architecture:** Clean Architecture & MVVM with Repository Pattern
- **Local Persistence:** Room Database (`androidx.room:2.6.1`) for optional offline scan history
- **Concurrency:** Kotlin Coroutines & StateFlow for non-blocking analysis and cancellation
- **File Ingestion:** Android Storage Access Framework (SAF) via `ActivityResultContracts.OpenDocument`
- **Testing:** JUnit 4, Kotlinx Coroutines Test, Compose UI Test

---

## 2. Main Screens & User Experience

1. **Home Screen (`HomeScreen.kt`):**
   - App branding: **CyberSafe**
   - Welcoming, non-technical explanation
   - Flexible text input box for pasted URLs, SMS messages, or email excerpts
   - One-tap "Check for Warning Signs" button
   - Optional file importer for user-selected `.eml` or text files
   - Clear, prominent privacy banner confirming on-device execution
2. **Analysis Screen (`AnalysisScreen.kt`):**
   - Sequential, honest progress indication tracking active inspection stages
   - Zero simulated or fake progress stages
   - Live "Stop Inspection" cancellation button
3. **Results Screen (`ResultsScreen.kt`):**
   - Color-coded outcome badge: `HIGH WARNING`, `CAUTION`, `LOW WARNING`
   - Plain-English warning indicators with rule IDs, explanations, and verbatim evidence quotes
   - Categorized safe next steps (priority-ordered actions)
   - Mandatory technical limitations box:
     - Clarifies that HTTPS does *not* prove website legitimacy
     - Clarifies that absence of detected warning signs does *not* guarantee absolute safety
     - Explains that indicators are advisory heuristics, not legal proof of fraud
   - Privacy-conscious "Share Safe Summary" button (strips sensitive tokens and passwords)
4. **History Screen (`HistoryScreen.kt`):**
   - View past saved scans with timestamp, risk badge, and sanitized preview
   - Delete individual scan records
   - "Clear All History" action with confirmation dialog
5. **Safety Tips Screen (`SafetyTipsScreen.kt`):**
   - Clear guidance on OTPs & PINs ("The Golden Rule")
   - How to spot disguised URLs and homoglyphs
   - Identifying panic and artificial deadlines
   - Government and police authority impersonation tactics
   - QR code refund traps
   - Emergency next steps if already compromised
6. **Privacy & Settings Screen (`SettingsPrivacyScreen.kt`):**
   - Detailed disclosure of 100% on-device processing
   - Confirmation that zero network requests are made
   - Toggle to disable or enable local scan history saving
   - Immediate "Clear All Data" action

---

## 3. Core Deterministic Rule Engine

| Rule ID | Name | Trigger Criteria | Plain-English Explanation |
| :--- | :--- | :--- | :--- |
| `RULE_IP_HOST` | Direct IP Address Host | Host matches raw IPv4 or IPv6 pattern | Link connects to a raw computer IP address instead of an authenticated, registered domain name. |
| `RULE_EXCESSIVE_SUBDOMAINS` | Deceptive Subdomain Structure | Host contains $\ge 4$ dot-separated labels | Web address uses multiple subdomain prefixes, often crafted to disguise the true destination domain. |
| `RULE_SUSPICIOUS_TLD` | High-Risk Top-Level Domain | Domain ends in `.xyz`, `.top`, `.icu`, `.tk`, etc. | Uses a top-level domain extension heavily abused for disposable scam campaigns. |
| `RULE_CREDENTIAL_PATH` | Credential Entry Path | Path contains `/login`, `/verify`, `/account`, etc. | Link points to a credential entry or verification page. |
| `RULE_PUNYCODE_HOMOGLYPH` | Punycode Impersonation | Domain contains `xn--` prefix | Domain uses internationalized punycode characters that can visually mimic known brand names. |
| `RULE_HTTP_UNENCRYPTED` | Unencrypted Connection | URL scheme is `http://` | Website communicates over unencrypted HTTP protocol. (Caveat: HTTPS does not imply legitimacy). |
| `RULE_NON_STANDARD_PORT` | Non-Standard Port | Port is specified and $\neq 80, 443, 8080$ | Link connects on an unusual port often associated with unauthorized web services. |
| `RULE_SOCIAL_URGENCY` | Urgency & Threat Framing | "immediately", "within 24 hours", "suspended" | Creates artificial panic and urgency to rush your decision and prevent you from consulting others. |
| `RULE_CREDENTIAL_SOLICITATION` | Credential / OTP Solicitation | "enter your password", "confirm your pin", "otp" | Solicits private security credentials. Real banks never ask for your passwords or OTPs. |
| `RULE_IMPERSONATION_AUTHORITY` | Authority Impersonation | "Security Dept", "Fraud Prevention", "Tax Dept" | Sender claims official organizational authority to intimidate victims into compliance. |
| `RULE_PAYMENT_COERCION` | Irregular Payment Claim | "pay via gift card", "scan qr code to receive" | Requests unconventional payment methods or claims you won money requiring a fee. |

---

## 4. Privacy & Security Protections

1. **Zero Invasive Permissions:** The application requests NO runtime Android permissions (`READ_SMS`, `READ_CONTACTS`, `ACCESS_FINE_LOCATION`, `CAMERA`, etc.).
2. **On-Device Storage Access Framework (SAF):** When inspecting an `.eml` or text file, the app uses Android's native system file picker (`ActivityResultContracts.OpenDocument`), granting temporary read-only access to that single user-selected file.
3. **Sensitive Token Redaction:** The input validator actively identifies and strips secret query parameters (e.g. `?token=...`, `?password=...`, `?auth=...`, `?key=...`) from stored history snippets and shareable reports.
4. **Air-Gapped Operation:** All rules execute locally without network access.

---

## 5. Setup, Build, and Run Instructions

### Prerequisites
- **Android Studio:** Hedgehog (2023.1.1), Iguana (2023.2.1), Jellyfish (2023.3.1), or Ladybug (2024.2.1+)
- **JDK:** Java Development Kit version 17 or higher (configured in Android Studio under *Settings -> Build, Execution, Deployment -> Build Tools -> Gradle -> Gradle JDK*)
- **Android SDK:** API 34 (Android 14) platform and build tools

### Option A: Open & Run via Android Studio
1. Launch Android Studio.
2. Select **File -> Open...** and navigate to `cybersafe_android/`.
3. Allow Android Studio to sync the Gradle project automatically.
4. Connect an Android device with USB Debugging enabled, or select a running Android Virtual Device (AVD Emulator running API 24 or newer).
5. Click **Run 'app'** (`Shift + F10`) or **Debug 'app'**.

### Option B: Build via Command Line
On a machine with JDK 17+ and the Android SDK installed:

```powershell
# Navigate to the Android project root
cd "c:\DF ORGINAL PROJECT\dfproject\cybersafe_android"

# Run automated unit tests
.\gradlew.bat test

# Build debug APK
.\gradlew.bat assembleDebug
```

The resulting debug APK will be generated at:
`cybersafe_android/app/build/outputs/apk/debug/app-debug.apk`

### Option C: Install on Physical Android Device via ADB
With your phone connected and USB Debugging enabled:

```powershell
# Verify connected device
C:\DF\platform-tools\adb.exe devices

# Install APK to device
C:\DF\platform-tools\adb.exe install -r "c:\DF ORGINAL PROJECT\dfproject\cybersafe_android\app\build\outputs\apk/debug/app-debug.apk"
```

---

## 6. Future Python Forensic Engine Integration Options

The desktop/server system runs an air-gapped Python Flask workstation with Random Forest, Logistic Regression, XGBoost, and SHAP TreeExplainer. To integrate advanced models with the mobile app in future phases:

1. **Option 1: On-Device TFLite / ONNX Model (Recommended for Offline Operation):**
   - Export the trained 11-feature scikit-learn model to ONNX via `skl2onnx`, then run inference on-device using the `onnxruntime-android` lightweight runtime.
   - Preserves offline-first guarantee and complete user privacy.
2. **Option 2: Private / Enterprise Self-Hosted REST Bridge:**
   - Host the existing Python `app/dashboard.py` or a dedicated FastAPI container on an internal organizational network.
   - Mobile users explicitly opt in and configure their server URL in Settings before any input is sent over TLS.
   - Discloses network transmission and requires user consent.

*Note: Standard Python/Flask cannot run natively inside an Android APK sandbox without complex chroot environments; offline mobile deployment relies on native Kotlin or converted TFLite/ONNX binaries.*
