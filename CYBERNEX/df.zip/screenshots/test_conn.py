import time
import os
import urllib.request
import urllib.parse
from pathlib import Path

# Verify local flask server is up
try:
    with urllib.request.urlopen("http://127.0.0.1:5000/") as response:
        print("Flask status:", response.status)
except Exception as e:
    print("Flask not reachable:", e)
