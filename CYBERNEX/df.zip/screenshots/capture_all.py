import urllib.request
import urllib.parse
import subprocess
from pathlib import Path

BASE = "http://127.0.0.1:5000"
SCREENSHOT_DIR = Path("screenshots").resolve()
SCREENSHOT_DIR.mkdir(exist_ok=True)

CHROME_BIN = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

def capture(url_or_path, output_filename, post_data=None):
    out_file = SCREENSHOT_DIR / output_filename
    
    if post_data:
        target_endpoint = f"{BASE}{url_or_path}"
        data_encoded = urllib.parse.urlencode(post_data).encode("utf-8")
        req = urllib.request.Request(target_endpoint, data=data_encoded, method="POST")
        with urllib.request.urlopen(req) as resp:
            content = resp.read()
        temp_html = SCREENSHOT_DIR / f"temp_{output_filename}.html"
        with open(temp_html, "wb") as f:
            f.write(content)
        render_target = str(temp_html)
    elif url_or_path.startswith("http"):
        render_target = url_or_path
    else:
        render_target = f"{BASE}{url_or_path}"

    cmd = [
        CHROME_BIN,
        "--headless=new",
        "--disable-gpu",
        "--window-size=1280,850",
        f"--screenshot={str(out_file)}",
        render_target
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    print(f"Captured {output_filename}: size={out_file.stat().st_size if out_file.exists() else 0} bytes")

# 1. Main Console
capture("/", "fig1_dashboard.png")

# 2. Email Ingestion
capture("/analyze-email", "fig2_email_forensics.png", post_data={"consent": "yes", "email_source": "demo"})

# 3. Browser History Ingestion
capture("/analyze-browser", "fig3_browser_forensics.png", post_data={"consent": "yes", "browser_source": "demo"})

# 4. URL Threat Scan
capture("/scan-url", "fig4_url_inspection.png", post_data={"url": "http://192.168.1.1/secure-bank-login/account-verification.php?client=9812", "model": "RandomForest"})

# 5. ML Comparison
capture("/ml-comparison", "fig5_ml_comparison.png")

# 6. Ablation Experiment
capture("/ml-ablation", "fig6_ml_ablation.png")

# 7. SHAP Explainability
capture("/shap?scenario=phishing_campaign&model_type=random_forest", "fig7_shap_explainability.png")

# 8. Viva Audit Matrix
capture("/viva-audit", "fig8_viva_audit.png")

print("All captures finalized.")
