import requests
import subprocess
from pathlib import Path

BASE = "http://127.0.0.1:5000"
SCREENSHOT_DIR = Path("screenshots").resolve()
CHROME_BIN = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

def snap_post(url_path, output_filename, post_data):
    out_file = SCREENSHOT_DIR / output_filename
    r = requests.post(f"{BASE}{url_path}", data=post_data)
    
    # Save the rendered HTML to file
    temp_html = SCREENSHOT_DIR / f"page_{output_filename}.html"
    # replace /static/ with http://127.0.0.1:5000/static/ so CSS and fonts load completely!
    fixed_html = r.text.replace('href="/static/', 'href="http://127.0.0.1:5000/static/').replace('src="/static/', 'src="http://127.0.0.1:5000/static/')
    temp_html.write_text(fixed_html, encoding="utf-8")
    
    cmd = [
        CHROME_BIN,
        "--headless=new",
        "--disable-gpu",
        "--window-size=1280,850",
        f"--screenshot={str(out_file)}",
        str(temp_html)
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    print(f"Captured {output_filename}: {out_file.stat().st_size} bytes")

print("Rendering clean themed pages...")
# Fig 2: Email Ingestion
snap_post("/analyze-email", "fig2_email_forensics.png", {"consent": "yes", "email_source": "demo"})

# Fig 3: Browser History
snap_post("/analyze-browser", "fig3_browser_forensics.png", {"consent": "yes", "browser_source": "demo"})

# Fig 4: URL Scan
snap_post("/scan-url", "fig4_url_inspection.png", {"scan_url": "http://192.168.1.1/secure-bank-login/account-verification.php?client=9812", "model": "RandomForest"})

print("Done.")
