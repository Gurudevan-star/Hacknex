import requests
import subprocess
from pathlib import Path

BASE = "http://127.0.0.1:5000"
SCREENSHOT_DIR = Path("screenshots").resolve()
CHROME_BIN = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

def make_light(html_text):
    # Set data-theme="light" on <html> tag and pre-set localStorage theme to light
    if '<html lang="en">' in html_text:
        html_text = html_text.replace('<html lang="en">', '<html lang="en" data-theme="light">')
    elif '<html lang="en"' in html_text:
        html_text = html_text.replace('<html lang="en"', '<html lang="en" data-theme="light"')
    else:
        html_text = html_text.replace('<html', '<html data-theme="light"')

    # Inject localStorage theme override script right after <head>
    theme_script = """<head>
    <script>try{localStorage.setItem('dfir_theme','light');}catch(e){}</script>"""
    html_text = html_text.replace('<head>', theme_script, 1)

    # Fix relative asset URLs so CSS and fonts load completely
    html_text = html_text.replace('href="/static/', 'href="http://127.0.0.1:5000/static/')
    html_text = html_text.replace('src="/static/', 'src="http://127.0.0.1:5000/static/')
    return html_text

def snap_page(source_type, endpoint, output_filename, post_data=None):
    out_file = SCREENSHOT_DIR / output_filename
    if source_type == "get":
        r = requests.get(f"{BASE}{endpoint}")
    else:
        r = requests.post(f"{BASE}{endpoint}", data=post_data)

    fixed = make_light(r.text)
    temp_html = SCREENSHOT_DIR / f"temp_{output_filename}.html"
    temp_html.write_text(fixed, encoding="utf-8")

    cmd = [
        CHROME_BIN,
        "--headless=new",
        "--disable-gpu",
        "--window-size=1280,850",
        f"--screenshot={str(out_file)}",
        str(temp_html)
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    print(f"Captured Light Mode {output_filename}: {out_file.stat().st_size} bytes")

print("Rendering Light Mode Forensic Screenshots for Vectors 1, 2, and 3...")

# Fig. 1: Central Workstation Console (Focusing on the 3 Investigation Vectors)
snap_page("get", "/", "fig1_light_workstation.png")

# Fig. 2: Vector 01 - RFC822 Email Forensics (Cryptographic SPF/DKIM/DMARC & Payload Triage)
snap_page("post", "/analyze-email", "fig2_light_email_forensics.png", {"consent": "yes", "email_source": "demo"})

# Fig. 3: Vector 02 - Browser Telemetry & History (SQLite Artifact Audit & Risk Scoring)
snap_page("post", "/analyze-browser", "fig3_light_browser_forensics.png", {"consent": "yes", "browser_source": "demo"})

# Fig. 4: Vector 03 - Live URL Threat Intelligence (SSL/TLS, DOM Heuristics & RandomForest Classification)
snap_page("post", "/scan-url", "fig4_light_url_inspection.png", {
    "scan_url": "http://192.168.1.1/secure-bank-login/account-verification.php?client=9812",
    "model": "RandomForest"
})

print("Light mode screenshots complete.")
