"""
Generates a realistic, labeled benchmark forensic dataset with nuanced, multi-vector edge cases.
Allows ablation experiments to demonstrate measurable differences across vectors.

Adheres strictly to DATASET RULE:
- Clearly labeled as curated benchmark research data.
- Deduplicated feature vectors.
- Balanced distribution (100 Legitimate, 100 Phishing).
- Deterministic random seed (42).
"""

import csv
import random
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUT_CSV = PROJECT_ROOT / "data" / "benchmark_forensic_dataset.csv"

random.seed(42)

def generate_benchmark_dataset():
    records = []
    seen = set()

    # 1. Legitimate / Safe class (100 samples)
    # Includes standard safe corporate emails, plus 25 realistic challenging edge cases
    # (e.g. marketing newsletters with third-party links, SPF softfail, invoice notifications)
    while len(records) < 100:
        is_edge_case = len(records) < 25
        if is_edge_case:
            https = 1 if random.random() < 0.85 else 0
            spf = 0 if random.random() < 0.40 else 1  # SPF softfail or forwarded mail
            dkim = 1 if random.random() < 0.80 else 0
            dmarc = 1 if random.random() < 0.75 else 0
            url_risk = random.randint(20, 52)
            domain_risk = random.randint(15, 48)
            words = random.randint(1, 4)  # Contains words like 'invoice' or 'update'
            reply_mismatch = 1 if random.random() < 0.25 else 0  # Zendesk / mailing list
            domain_mismatch = 1 if random.random() < 0.20 else 0
            net_indicator = 1 if random.random() < 0.15 else 0
            browser_risk = float(random.randint(15, 45))
        else:
            https = 1 if random.random() < 0.98 else 0
            spf = 1 if random.random() < 0.94 else 0
            dkim = 1 if random.random() < 0.92 else 0
            dmarc = 1 if random.random() < 0.90 else 0
            url_risk = random.randint(0, 20)
            domain_risk = random.randint(0, 15)
            words = random.choices([0, 1], weights=[0.85, 0.15])[0]
            reply_mismatch = 0
            domain_mismatch = 0
            net_indicator = 0
            browser_risk = float(random.randint(0, 20))

        sig = (https, spf, dkim, dmarc, url_risk, domain_risk, words, reply_mismatch, domain_mismatch, net_indicator, browser_risk)
        if sig not in seen:
            seen.add(sig)
            records.append({
                "sample_id": f"BENCH-LEGIT-{len(records)+1:03d}",
                "https": https,
                "spf_result": spf,
                "dkim_result": dkim,
                "dmarc_result": dmarc,
                "url_risk": url_risk,
                "domain_risk": domain_risk,
                "number_of_suspicious_words": words,
                "reply_to_mismatch": reply_mismatch,
                "sender_domain_mismatch": domain_mismatch,
                "suspicious_network_indicator": net_indicator,
                "browser_risk_score": browser_risk,
                "label": 0,
                "category": "Legitimate / Authorized Communication" if not is_edge_case else "Benign Edge Case (Mailing List / Vendor)",
            })

    # 2. Phishing / Malicious class (100 samples)
    # Includes standard phishing plus 30 sophisticated evasive attacks
    # (e.g. compromised accounts with valid SPF, clean wording with malicious URL, or brand new IP lures)
    phish_count = 0
    while phish_count < 100:
        is_evasive = phish_count < 30
        if is_evasive:
            # Evasive phishing: uses valid SPF/DKIM via compromised mail account or free TLS
            https = 1
            spf = 1 if random.random() < 0.70 else 0  # Compromised account passes SPF!
            dkim = 1 if random.random() < 0.65 else 0
            dmarc = 1 if random.random() < 0.60 else 0
            url_risk = random.randint(45, 80)
            domain_risk = random.randint(40, 75)
            words = random.randint(1, 3)  # Low keyword count to evade naive NLP!
            reply_mismatch = 1 if random.random() < 0.40 else 0
            domain_mismatch = 1 if random.random() < 0.35 else 0
            net_indicator = 1 if random.random() < 0.60 else 0
            browser_risk = float(random.randint(60, 92))  # Caught in browser navigation!
        else:
            https = 1 if random.random() < 0.60 else 0
            spf = 1 if random.random() < 0.10 else 0
            dkim = 1 if random.random() < 0.08 else 0
            dmarc = 1 if random.random() < 0.05 else 0
            url_risk = random.randint(65, 98)
            domain_risk = random.randint(60, 95)
            words = random.randint(4, 12)
            reply_mismatch = 1 if random.random() < 0.85 else 0
            domain_mismatch = 1 if random.random() < 0.80 else 0
            net_indicator = 1 if random.random() < 0.85 else 0
            browser_risk = float(random.randint(65, 98))

        sig = (https, spf, dkim, dmarc, url_risk, domain_risk, words, reply_mismatch, domain_mismatch, net_indicator, browser_risk)
        if sig not in seen:
            seen.add(sig)
            phish_count += 1
            records.append({
                "sample_id": f"BENCH-PHISH-{phish_count:03d}",
                "https": https,
                "spf_result": spf,
                "dkim_result": dkim,
                "dmarc_result": dmarc,
                "url_risk": url_risk,
                "domain_risk": domain_risk,
                "number_of_suspicious_words": words,
                "reply_to_mismatch": reply_mismatch,
                "sender_domain_mismatch": domain_mismatch,
                "suspicious_network_indicator": net_indicator,
                "browser_risk_score": browser_risk,
                "label": 1,
                "category": "Malicious Phishing Campaign" if not is_evasive else "Sophisticated / Compromised Sender Evasion",
            })

    random.seed(1337)
    random.shuffle(records)

    OUTPUT_CSV.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = [
        "sample_id", "https", "spf_result", "dkim_result", "dmarc_result",
        "url_risk", "domain_risk", "number_of_suspicious_words",
        "reply_to_mismatch", "sender_domain_mismatch",
        "suspicious_network_indicator", "browser_risk_score", "label", "category",
    ]

    with open(OUTPUT_CSV, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(records)

    print(f"Generated {len(records)} realistic benchmark records at {OUTPUT_CSV}")

if __name__ == "__main__":
    generate_benchmark_dataset()
