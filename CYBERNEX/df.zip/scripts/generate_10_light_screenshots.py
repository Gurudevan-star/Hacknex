import os
import requests
import subprocess
from pathlib import Path

BASE = "http://127.0.0.1:5000"
SCREENSHOT_DIR = Path("screenshots").resolve()
SCREENSHOT_DIR.mkdir(exist_ok=True)
CHROME_BIN = r"C:\Program Files\Google\Chrome\Application\chrome.exe"

def make_light_theme(html_text):
    # Ensure data-theme="light" attribute is set
    if '<html lang="en">' in html_text:
        html_text = html_text.replace('<html lang="en">', '<html lang="en" data-theme="light">')
    elif '<html lang="en"' in html_text:
        html_text = html_text.replace('<html lang="en"', '<html lang="en" data-theme="light"')
    elif '<html' in html_text:
        html_text = html_text.replace('<html', '<html data-theme="light"')
    
    # Inject localStorage script and light theme force
    theme_script = """<head>
    <script>try{localStorage.setItem('dfir_theme','light');}catch(e){}</script>"""
    html_text = html_text.replace('<head>', theme_script, 1)

    # Fix static URLs to absolute URLs
    html_text = html_text.replace('href="/static/', 'href="http://127.0.0.1:5000/static/')
    html_text = html_text.replace('src="/static/', 'src="http://127.0.0.1:5000/static/')
    return html_text

def capture_screenshot(html_content, output_filename, window_size="1280,850"):
    temp_html = SCREENSHOT_DIR / f"temp_{output_filename}.html"
    temp_html.write_text(html_content, encoding="utf-8")
    out_file = SCREENSHOT_DIR / output_filename

    cmd = [
        CHROME_BIN,
        "--headless=new",
        "--disable-gpu",
        f"--window-size={window_size}",
        f"--screenshot={str(out_file)}",
        str(temp_html)
    ]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if out_file.exists():
        print(f"[OK] Generated {output_filename} ({out_file.stat().st_size} bytes)")
    else:
        print(f"[ERROR] Failed to generate {output_filename}: {res.stderr}")

def run():
    print("Generating 10 Light Mode Screenshots across Email, Browser, URL, and Downloadable Report...")

    # 1. Fig 1: Primary Workstation Hub (Vector 01, Vector 02, Vector 03 Overview)
    r1 = requests.get(f"{BASE}/")
    html1 = make_light_theme(r1.text)
    capture_screenshot(html1, "fig1_light_workstation.png")

    # 2. Fig 2: Vector 01 Email Forensics - Single Message Ingestion & Cryptographic Header Triage
    r2 = requests.post(f"{BASE}/analyze-email", data={"consent": "yes", "email_source": "upload"})
    html2 = make_light_theme(r2.text)
    capture_screenshot(html2, "fig2_light_email_forensics.png")

    # 3. Fig 3: Vector 01 Email Forensics - Multi-Message Mailbox Telemetry & Batch Campaign Triage
    r3 = requests.post(f"{BASE}/analyze-email", data={"consent": "yes", "email_source": "demo"})
    html3 = make_light_theme(r3.text)
    capture_screenshot(html3, "fig3_light_email_mailbox.png")

    # 4. Fig 4: Vector 02 Browser Telemetry - Direct Local Browser Profile Ingestion Console
    # In index.html, activate Vector 02 (Browser)
    html4 = r1.text
    html4 = html4.replace('id="dock-email" class="vector-dock active"', 'id="dock-email" class="vector-dock"')
    html4 = html4.replace('id="dock-browser" class="vector-dock"', 'id="dock-browser" class="vector-dock active"')
    html4 = html4.replace('id="panel-email" class="investigation-panel active"', 'id="panel-email" class="investigation-panel"')
    html4 = html4.replace('id="panel-browser" class="investigation-panel"', 'id="panel-browser" class="investigation-panel active"')
    html4 = make_light_theme(html4)
    capture_screenshot(html4, "fig4_light_browser_ingestion.png")

    # 5. Fig 5: Vector 02 Browser Telemetry - History Artifact Audit & Deceptive Domain / IP Triage
    r5 = requests.post(f"{BASE}/analyze-browser", data={"consent": "yes", "browser_source": "demo"})
    html5 = make_light_theme(r5.text)
    capture_screenshot(html5, "fig5_light_browser_forensics.png")

    # 6. Fig 6: Vector 03 Live URL Threat Intelligence - Target URI Scanner & Protocol Checks
    html6 = r1.text
    html6 = html6.replace('id="dock-email" class="vector-dock active"', 'id="dock-email" class="vector-dock"')
    html6 = html6.replace('id="dock-url" class="vector-dock"', 'id="dock-url" class="vector-dock active"')
    html6 = html6.replace('id="panel-email" class="investigation-panel active"', 'id="panel-email" class="investigation-panel"')
    html6 = html6.replace('id="panel-url" class="investigation-panel"', 'id="panel-url" class="investigation-panel active"')
    # Pre-fill URL in the input field
    target_url = "http://192.168.1.1/secure-bank-login/account-verification.php?client=9812"
    html6 = html6.replace('placeholder="https://login-verify-secure-bank.net/account/login"', f'value="{target_url}"')
    html6 = make_light_theme(html6)
    capture_screenshot(html6, "fig6_light_url_scanner.png")

    # 7. Fig 7: Vector 03 Live URL Threat Intelligence - AI Detection Verdict & Technical Dossier
    r7 = requests.post(f"{BASE}/scan-url", data={
        "scan_url": "http://192.168.1.1/secure-bank-login/account-verification.php?client=9812",
        "model": "RandomForest"
    })
    html7 = make_light_theme(r7.text)
    capture_screenshot(html7, "fig7_light_url_inspection.png")

    # 8. Fig 8: Explainable AI (SHAP) - Mathematical Additive Verification & Attribution Console
    r8 = requests.get(f"{BASE}/shap?scenario=phishing_campaign&model_type=random_forest")
    html8 = make_light_theme(r8.text)
    capture_screenshot(html8, "fig8_light_shap_explainability.png")

    # 9. Fig 9: Empirical Machine Learning Model Comparison (Random Forest vs XGBoost vs Logistic Regression)
    r9 = requests.get(f"{BASE}/ml-comparison")
    html9 = make_light_theme(r9.text)
    capture_screenshot(html9, "fig9_light_ml_comparison.png")

    # 10. Fig 10: Downloadable Forensic Incident Response Evidence Report (Executive Light Styling)
    tech_rep_path = Path("uploads/reports/CASE-2026-0001_technical_forensic_report.html").resolve()
    if tech_rep_path.exists():
        raw_rep = tech_rep_path.read_text(encoding="utf-8")
        # Transform report style to crisp executive light theme
        light_style = """
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f8fafc; color: #1e293b; margin: 0; padding: 40px; }
        .container { max-width: 1100px; margin: 0 auto; }
        .header { border-bottom: 2px solid #2563eb; padding-bottom: 20px; margin-bottom: 30px; display: flex; justify-content: space-between; align-items: flex-end; }
        .header h1 { margin: 0; color: #0f172a; font-size: 26px; font-weight: 700; }
        .header .meta { color: #64748b; font-size: 13px; font-family: 'JetBrains Mono', Consolas, monospace; }
        .card { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 8px; padding: 24px; margin-bottom: 28px; box-shadow: 0 4px 16px rgba(0,0,0,0.04); }
        .card h2 { color: #1d4ed8; font-size: 18px; margin-top: 0; border-bottom: 1px solid #e2e8f0; padding-bottom: 10px; font-weight: 600; }
        table { width: 100%; border-collapse: collapse; margin-top: 12px; font-size: 13.5px; }
        th, td { padding: 10px 12px; text-align: left; border-bottom: 1px solid #e2e8f0; color: #334155; }
        th { background: #f1f5f9; color: #1e40af; font-weight: 600; text-transform: uppercase; font-size: 11.5px; letter-spacing: 0.5px; }
        .badge-verified { background: #dcfce7; color: #15803d; border: 1px solid #bbf7d0; padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; }
        .badge-alert { background: #fee2e2; color: #b91c1c; border: 1px solid #fecaca; padding: 3px 8px; border-radius: 4px; font-weight: bold; font-size: 11px; }
        .timeline-item { border-left: 2px solid #2563eb; padding-left: 18px; margin-bottom: 16px; position: relative; }
        .timeline-item::before { content: ''; position: absolute; left: -6px; top: 4px; width: 10px; height: 10px; border-radius: 50%; background: #2563eb; }
        .timeline-ts { font-family: 'JetBrains Mono', Consolas, monospace; font-size: 12px; color: #2563eb; font-weight: 600; }
        .disclaimer-box { background: #fffbeb; border-left: 4px solid #f59e0b; padding: 14px; margin-top: 20px; font-size: 12.5px; color: #92400e; border-radius: 4px; }
        """
        # Replace dark style with light style
        import re
        html10 = re.sub(r'<style>.*?</style>', f'<style>{light_style}</style>', raw_rep, flags=re.DOTALL)
        capture_screenshot(html10, "fig10_light_forensic_report.png")
    else:
        print("[WARN] CASE-2026-0001_technical_forensic_report.html not found, falling back to email_forensic_report.html")
        r10 = Path("email_forensic_report.html").read_text(encoding="utf-8")
        capture_screenshot(r10, "fig10_light_forensic_report.png")

    print("\nAll 10 screenshots captured successfully in Light Mode!")

if __name__ == "__main__":
    run()
