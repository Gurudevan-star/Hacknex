"""
Creates the reproducible synthetic demonstration case: CASE-2026-0001.

Adheres strictly to the ABSOLUTE ANTI-FABRICATION RULE:
- All materials are explicitly tagged: SYNTHETIC DEMONSTRATION DATA
- Verifiable bitstream SHA-256 calculation
- Realistic cross-vector correlation
- Live SHAP explainability
- Reproducible on any clean install
"""

import sys
from datetime import datetime, timezone
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
sys.path.append(str(PROJECT_ROOT))

from app.ai.phishing_model import explain_prediction
from app.browser.browser_forensics import analyze_browser_history
from app.correlation_engine import run_cross_artifact_correlation
from app.db import (
    create_case,
    delete_case,
    delete_correlations,
    delete_normalized_events,
    get_case,
    init_db,
)
from app.email.email_forensics import analyze_email_file
from app.event_normalizer import (
    normalize_events_from_browser,
    normalize_events_from_email,
    normalize_events_from_network,
)
from app.evidence_integrity import ingest_evidence_file
from app.network.network_forensics import load_network_csv
from app.reports.report_generator import (
    generate_community_report,
    generate_technical_forensic_report,
)

CASE_ID = "CASE-2026-0001"


def setup_demo_case():
    init_db()
    # Clean prior demo state if exists
    delete_case(CASE_ID)
    delete_normalized_events(CASE_ID)
    delete_correlations(CASE_ID)

    # 1. Create Case Record
    create_case(
        case_id=CASE_ID,
        incident_type="Phishing",
        incident_description=(
            "[SYNTHETIC DEMONSTRATION DATA] Automated end-to-end verification case simulating an urgent "
            "financial lure email, browser link traversal, and network destination telemetry."
        ),
        reported_date="2026-08-01 10:20:00 UTC",
        status="Under Active Forensics",
        notes="All synthetic evidence is strictly isolated and clearly labeled. Demonstrates cross-vector fusion.",
    )

    # 2. Ingest Synthetic Evidence 1: Email (.eml)
    email_content = (
        "Date: Fri, 01 Aug 2026 10:00:00 +0000\n"
        "From: security-alert@bank-update.net\n"
        "To: victim@example-corp.com\n"
        "Subject: Urgent: Verify your bank account immediately to prevent suspension\n"
        "Reply-To: support@secure-account-login.net\n"
        "Return-Path: <bounce@bank-update.net>\n"
        "Received: from mail.bank-update.net (mail.bank-update.net [45.33.11.9])\n"
        "Authentication-Results: spf=fail smtp.mailfrom=bank-update.net; dkim=fail; dmarc=fail\n"
        "\n"
        "Urgent action required! Your bank account has been temporarily suspended.\n"
        "Verify your account immediately to avoid permanent service interruption.\n"
        "Click the secure link below to confirm your password and payment details:\n"
        "https://login-verify-secure-bank.net/account/login\n"
    ).encode("utf-8")

    ev_email = ingest_evidence_file(
        case_id=CASE_ID,
        original_filename="synthetic_phishing_email.eml",
        file_bytes=email_content,
        source="SYNTHETIC DEMONSTRATION DATA (Simulated Email Gateway)",
        description="RFC822 Email lure with failed SPF/DKIM/DMARC, Reply-To mismatch, and credential link.",
        file_type="RFC822 Email",
        custom_evidence_id="EV-2026-001",
    )

    # 3. Ingest Synthetic Evidence 2: Browser History (.csv)
    browser_csv_content = (
        "url,title,timestamp,visit_count\n"
        "https://www.google.com/search?q=bank+login,Google Search,2026-08-01 09:45:00,3\n"
        "https://login-verify-secure-bank.net/account/login,Bank Account Verification Portal,2026-08-01 10:02:15,2\n"
        "https://login-verify-secure-bank.net/success,Confirmation Page,2026-08-01 10:03:10,1\n"
    ).encode("utf-8")

    ev_browser = ingest_evidence_file(
        case_id=CASE_ID,
        original_filename="synthetic_browser_history.csv",
        file_bytes=browser_csv_content,
        source="SYNTHETIC DEMONSTRATION DATA (Simulated Chromium Profile)",
        description="Chromium history showing visit to the lure URL 2 minutes after email arrival.",
        file_type="Browser Telemetry",
        custom_evidence_id="EV-2026-002",
    )

    # 4. Ingest Synthetic Evidence 3: Network Telemetry (.csv)
    network_csv_content = (
        "timestamp,src_ip,dst_ip,protocol,host,dns_query\n"
        "2026-08-01 10:02:14,192.168.1.105,8.8.8.8,DNS,login-verify-secure-bank.net,login-verify-secure-bank.net\n"
        "2026-08-01 10:02:15,192.168.1.105,45.33.11.9,HTTP,login-verify-secure-bank.net,\n"
        "2026-08-01 10:03:10,192.168.1.105,45.33.11.9,HTTPS,login-verify-secure-bank.net,\n"
    ).encode("utf-8")

    ev_network = ingest_evidence_file(
        case_id=CASE_ID,
        original_filename="synthetic_network_traffic.csv",
        file_bytes=network_csv_content,
        source="SYNTHETIC DEMONSTRATION DATA (Simulated NetFlow/DNS)",
        description="Network traffic recording DNS resolution and TCP session to lure destination IP.",
        file_type="Network PCAP/Flow",
        custom_evidence_id="EV-2026-003",
    )

    # 5. Run Forensic Analyzers on working copies
    email_analysis = analyze_email_file(ev_email["working_copy_path"])
    browser_analysis = analyze_browser_history(ev_browser["working_copy_path"])
    network_flows = load_network_csv(ev_network["working_copy_path"])

    # 6. Normalize Events
    normalize_events_from_email(CASE_ID, ev_email["evidence_id"], email_analysis, source_label="Email Forensics")
    normalize_events_from_browser(CASE_ID, ev_browser["evidence_id"], browser_analysis, source_label="Browser Forensics")
    normalize_events_from_network(CASE_ID, ev_network["evidence_id"], network_flows, source_label="Network Telemetry")

    # 7. Run Cross-Artifact Correlation
    correlations = run_cross_artifact_correlation(CASE_ID, time_window_seconds=900)

    # 8. Run AI Inference with Real SHAP Attribution
    model_features = {
        "https": 1,
        "spf_result": 0,
        "dkim_result": 0,
        "dmarc_result": 0,
        "url_risk": 85,
        "domain_risk": 80,
        "number_of_suspicious_words": 6,
        "reply_to_mismatch": 1,
        "sender_domain_mismatch": 1,
        "suspicious_network_indicator": 1,
        "browser_risk_score": 85.0,
    }
    ai_assessment = explain_prediction(model_features)

    # 9. Generate Both Reports
    tech_rep = generate_technical_forensic_report(CASE_ID, ai_assessment)
    comm_rep = generate_community_report(CASE_ID, ai_assessment)

    print(f"=== Synthetic Demo Case {CASE_ID} Initialized ===")
    print(f"Evidence Vault Items: 3 preserved (SHA-256 verified)")
    print(f"Correlations Discovered: {len(correlations)}")
    print(f"AI Prediction: {ai_assessment['prediction']} (Risk: {ai_assessment['risk_score']}/100)")
    print(f"Technical Report: {tech_rep}")
    print(f"Community Report: {comm_rep}")
    return CASE_ID


if __name__ == "__main__":
    setup_demo_case()
