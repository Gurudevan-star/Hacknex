# SafeBrowse Warning extension

A Chromium (Chrome/Edge) Manifest V3 extension for a subject project. It intercepts top-level web navigation, shows an understandable warning for suspicious URL signals, and lets the person either go back or continue for the current browser session.

## Install locally

1. Open `chrome://extensions` in Chrome, or `edge://extensions` in Edge.
2. Turn on **Developer mode**.
3. Select **Load unpacked** and choose this `safebrowse-extension` folder.
4. Pin the SafeBrowse icon from the browser extensions menu, then click it to open its status panel.

## Test it

Open `http://secure-account-check.example` after loading the extension. You should see the warning page. Choose **I understand, continue anyway** to proceed for that browser session.

After editing these files, return to `chrome://extensions` or `edge://extensions` and click the extension's **Reload** button.

## Notes for your presentation

The detection is deliberately explainable and entirely local: HTTP connections, lookalike/internationalized domains, unusually nested subdomains, risky account-link patterns, and a small demo blocklist. It does not claim a website is definitely malicious. For a production version, replace the demo blocklist with an authenticated threat-intelligence service and add privacy safeguards.
