from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from ml.dataset_audit import audit_dataset, compute_file_sha256
from ml.feature_dictionary import FEATURE_NAMES
from ml.metrics import calculate_metrics
from ml.model_registry import ModelRegistry
from ml.preprocessing import prepare_benchmark_splits

# Try importing XGBoost
try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
    XGBOOST_IMPORT_ERROR = None
except Exception as e:
    XGBClassifier = None
    XGBOOST_AVAILABLE = False
    XGBOOST_IMPORT_ERROR = str(e)


def train_all_models(
    dataset_path: Path | str | None = None,
    random_state: int = 42,
    test_size: float = 0.3,
) -> dict[str, Any]:
    """
    Trains and registers the three candidate models:
      1. Logistic Regression (Scales features with StandardScaler fitted on train)
      2. Random Forest (100 trees, bootstrap=True baseline, unscaled features)
      3. XGBoost (Gradient-boosted decision trees, unscaled features, if installed)
    All models are trained and evaluated on the EXACT same train/test split.
    Zero data leakage: preprocessing is fitted only on training partition.
    """
    audit = audit_dataset(dataset_path)
    dataset_hash = audit.get("sha256", "")

    X_train, X_test, y_train, y_test, preprocessor, split_meta = prepare_benchmark_splits(
        dataset_path=dataset_path,
        test_size=test_size,
        random_state=random_state,
    )

    registry = ModelRegistry()
    training_results: dict[str, Any] = {
        "dataset_audit": audit,
        "split_metadata": split_meta,
        "models": {},
    }

    # ─────────────────────────────────────────────────────────────
    # Model 1: Logistic Regression (Interpretable Linear Baseline)
    # ─────────────────────────────────────────────────────────────
    X_train_scaled = preprocessor.transform(X_train, scale=True)
    X_test_scaled = preprocessor.transform(X_test, scale=True)

    lr_params = {"max_iter": 1000, "random_state": random_state, "C": 1.0, "solver": "lbfgs"}
    lr_model = LogisticRegression(**lr_params)
    lr_model.fit(X_train_scaled, y_train)

    lr_preds = lr_model.predict(X_test_scaled)
    lr_probs = lr_model.predict_proba(X_test_scaled)[:, 1]
    lr_metrics = calculate_metrics(y_test, lr_preds, lr_probs)

    registry.register_model(
        model_type="logistic_regression",
        estimator=lr_model,
        preprocessor=preprocessor,
        feature_schema=FEATURE_NAMES,
        hyperparameters=lr_params,
        evaluation_metrics=lr_metrics,
        dataset_hash=dataset_hash,
        uses_scaled_features=True,
        version="1.0.0",
    )
    training_results["models"]["logistic_regression"] = {
        "status": "TRAINED",
        "metrics": lr_metrics,
    }

    # ─────────────────────────────────────────────────────────────
    # Model 2: Random Forest (Primary Tree-Based Baseline)
    # ─────────────────────────────────────────────────────────────
    X_train_unscaled = preprocessor.transform(X_train, scale=False)
    X_test_unscaled = preprocessor.transform(X_test, scale=False)

    rf_params = {"n_estimators": 100, "bootstrap": True, "random_state": random_state}
    rf_model = RandomForestClassifier(**rf_params)
    rf_model.fit(X_train_unscaled, y_train)

    rf_preds = rf_model.predict(X_test_unscaled)
    rf_probs = rf_model.predict_proba(X_test_unscaled)[:, 1]
    rf_metrics = calculate_metrics(y_test, rf_preds, rf_probs)

    registry.register_model(
        model_type="random_forest",
        estimator=rf_model,
        preprocessor=preprocessor,
        feature_schema=FEATURE_NAMES,
        hyperparameters=rf_params,
        evaluation_metrics=rf_metrics,
        dataset_hash=dataset_hash,
        uses_scaled_features=False,
        version="1.0.0",
        make_active=True,  # Primary baseline
    )
    training_results["models"]["random_forest"] = {
        "status": "TRAINED",
        "metrics": rf_metrics,
    }

    # Backward compatibility: save payload for legacy app/ai/phishing_model.py
    legacy_payload = {
        "model": rf_model,
        "features": FEATURE_NAMES,
        "evaluation": {
            "RandomForest": rf_metrics,
            "LogisticRegression": lr_metrics,
        },
        "best_model": "RandomForest",
    }
    legacy_path = Path(__file__).resolve().parents[1] / "models" / "phishing_model.joblib"
    joblib.dump(legacy_payload, legacy_path)

    # ─────────────────────────────────────────────────────────────
    # Model 3: XGBoost (Comparative Gradient Boosted Trees)
    # ─────────────────────────────────────────────────────────────
    if XGBOOST_AVAILABLE and XGBClassifier is not None:
        xgb_params = {
            "n_estimators": 100,
            "max_depth": 4,
            "learning_rate": 0.1,
            "subsample": 0.8,
            "colsample_bytree": 0.8,
            "random_state": random_state,
            "eval_metric": "logloss",
        }
        xgb_model = XGBClassifier(**xgb_params)
        xgb_model.fit(X_train_unscaled, y_train)

        xgb_preds = xgb_model.predict(X_test_unscaled)
        xgb_probs = xgb_model.predict_proba(X_test_unscaled)[:, 1]
        xgb_metrics = calculate_metrics(y_test, xgb_preds, xgb_probs)

        registry.register_model(
            model_type="xgboost",
            estimator=xgb_model,
            preprocessor=preprocessor,
            feature_schema=FEATURE_NAMES,
            hyperparameters=xgb_params,
            evaluation_metrics=xgb_metrics,
            dataset_hash=dataset_hash,
            uses_scaled_features=False,
            version="1.0.0",
        )
        training_results["models"]["xgboost"] = {
            "status": "TRAINED",
            "metrics": xgb_metrics,
        }
    else:
        training_results["models"]["xgboost"] = {
            "status": "UNAVAILABLE",
            "reason": f"XGBoost package not installed or import failed: {XGBOOST_IMPORT_ERROR}",
            "metrics": None,
        }

    return training_results


if __name__ == "__main__":
    print("=" * 65)
    print("STARTING REPRODUCIBLE MULTI-MODEL TRAINING PIPELINE")
    print("=" * 65)
    results = train_all_models()
    print("\nTraining complete! Evaluated on identical test partition (30% holdout):")
    for m_type, m_info in results["models"].items():
        if m_info["status"] == "TRAINED":
            metrics = m_info["metrics"]
            print(f"\n[{m_type.upper()}]")
            print(f"  Accuracy:  {metrics['accuracy']}")
            print(f"  Precision: {metrics['precision']}")
            print(f"  Recall:    {metrics['recall']}")
            print(f"  F1-Score:  {metrics['f1']}")
            print(f"  ROC-AUC:   {metrics['roc_auc']}")
            print(f"  FPR:       {metrics['fpr']}")
            print(f"  FNR:       {metrics['fnr']}")
            print(f"  Confusion: {metrics['confusion_matrix']}")
        else:
            print(f"\n[{m_type.upper()}] Status: {m_info['status']} - {m_info.get('reason')}")
    print("=" * 65)
