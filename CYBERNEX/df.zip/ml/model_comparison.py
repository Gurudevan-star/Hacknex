from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression

from ml.dataset_audit import audit_dataset
from ml.feature_dictionary import FEATURE_NAMES
from ml.metrics import calculate_metrics
from ml.preprocessing import prepare_benchmark_splits

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
    XGBOOST_ERROR = None
except Exception as e:
    XGBClassifier = None
    XGBOOST_AVAILABLE = False
    XGBOOST_ERROR = str(e)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results" / "model_comparison"


def run_model_comparison(
    dataset_path: Path | str | None = None,
    test_size: float = 0.3,
    random_state: int = 42,
) -> dict[str, Any]:
    """
    Executes rigorous comparative evaluation across candidate models:
      1. Simple Baseline (DummyClassifier - Majority Class)
      2. Logistic Regression (Linear Interpretable Baseline with StandardScaler)
      3. Random Forest (100 Trees Ensemble Baseline, unscaled)
      4. XGBoost (Gradient Boosted Trees, unscaled, if available)

    Uses identical data partitions and evaluation protocol.
    Never fabricates scores or hard-codes a winner.
    Determines highest performer strictly from empirical data.
    """
    audit = audit_dataset(dataset_path)
    X_train, X_test, y_train, y_test, preprocessor, split_meta = prepare_benchmark_splits(
        dataset_path=dataset_path,
        test_size=test_size,
        random_state=random_state,
    )

    X_train_unscaled = preprocessor.transform(X_train, scale=False)
    X_test_unscaled = preprocessor.transform(X_test, scale=False)

    X_train_scaled = preprocessor.transform(X_train, scale=True)
    X_test_scaled = preprocessor.transform(X_test, scale=True)

    candidates: list[dict[str, Any]] = []

    # 1. Majority Class Baseline
    dummy = DummyClassifier(strategy="most_frequent")
    t0 = time.perf_counter()
    dummy.fit(X_train_unscaled, y_train)
    dummy_pred = dummy.predict(X_test_unscaled)
    dummy_time = (time.perf_counter() - t0) * 1000.0
    dummy_metrics = calculate_metrics(y_test, dummy_pred, None)
    candidates.append({
        "model_id": "dummy_majority",
        "model_name": "Majority Class Baseline (Dummy)",
        "model_type": "baseline",
        "metrics": dummy_metrics,
        "inference_latency_ms": round(dummy_time, 2),
        "status": "EVALUATED",
    })

    # 2. Logistic Regression
    lr = LogisticRegression(max_iter=1000, random_state=random_state, C=1.0)
    t0 = time.perf_counter()
    lr.fit(X_train_scaled, y_train)
    lr_pred = lr.predict(X_test_scaled)
    lr_prob = lr.predict_proba(X_test_scaled)[:, 1]
    lr_time = (time.perf_counter() - t0) * 1000.0
    lr_metrics = calculate_metrics(y_test, lr_pred, lr_prob)
    candidates.append({
        "model_id": "logistic_regression",
        "model_name": "Logistic Regression (Scaled L2)",
        "model_type": "linear",
        "metrics": lr_metrics,
        "inference_latency_ms": round(lr_time, 2),
        "status": "EVALUATED",
    })

    # 3. Random Forest Baseline
    rf = RandomForestClassifier(n_estimators=100, bootstrap=True, random_state=random_state)
    t0 = time.perf_counter()
    rf.fit(X_train_unscaled, y_train)
    rf_pred = rf.predict(X_test_unscaled)
    rf_prob = rf.predict_proba(X_test_unscaled)[:, 1]
    rf_time = (time.perf_counter() - t0) * 1000.0
    rf_metrics = calculate_metrics(y_test, rf_pred, rf_prob)
    candidates.append({
        "model_id": "random_forest",
        "model_name": "Random Forest (100 Trees Baseline)",
        "model_type": "ensemble_bagging",
        "metrics": rf_metrics,
        "inference_latency_ms": round(rf_time, 2),
        "status": "EVALUATED",
    })

    # 4. XGBoost
    if XGBOOST_AVAILABLE and XGBClassifier is not None:
        xgb = XGBClassifier(
            n_estimators=100,
            max_depth=4,
            learning_rate=0.1,
            subsample=0.8,
            colsample_bytree=0.8,
            random_state=random_state,
            eval_metric="logloss",
        )
        t0 = time.perf_counter()
        xgb.fit(X_train_unscaled, y_train)
        xgb_pred = xgb.predict(X_test_unscaled)
        xgb_prob = xgb.predict_proba(X_test_unscaled)[:, 1]
        xgb_time = (time.perf_counter() - t0) * 1000.0
        xgb_metrics = calculate_metrics(y_test, xgb_pred, xgb_prob)
        candidates.append({
            "model_id": "xgboost",
            "model_name": "XGBoost (Gradient Boosted Trees)",
            "model_type": "ensemble_boosting",
            "metrics": xgb_metrics,
            "inference_latency_ms": round(xgb_time, 2),
            "status": "EVALUATED",
        })
    else:
        candidates.append({
            "model_id": "xgboost",
            "model_name": "XGBoost",
            "model_type": "ensemble_boosting",
            "metrics": None,
            "inference_latency_ms": None,
            "status": "UNAVAILABLE",
            "reason": f"XGBoost dependency not available: {XGBOOST_ERROR}",
        })

    # Data-Driven Selection Logic
    evaluated_models = [c for c in candidates if c["status"] == "EVALUATED" and c["model_id"] != "dummy_majority"]
    evaluated_models.sort(key=lambda c: (c["metrics"]["f1"] if c["metrics"]["f1"] is not None else -1), reverse=True)

    if evaluated_models:
        top_model = evaluated_models[0]
        top_f1 = top_model["metrics"]["f1"] or 0.0

        close_models = [
            m for m in evaluated_models
            if m["model_id"] != top_model["model_id"] and abs((m["metrics"]["f1"] or 0.0) - top_f1) <= 0.02
        ]

        if close_models:
            selection_verdict = (
                f"Top evaluated model by F1-score: {top_model['model_name']} (F1={top_f1}). "
                f"However, performance difference is small across {[m['model_name'] for m in close_models]} "
                f"(difference <= 0.02 on this benchmark test partition)."
            )
        else:
            selection_verdict = (
                f"Top evaluated model by F1-score: {top_model['model_name']} (F1={top_f1}). "
                f"This result applies specifically to the evaluated benchmark dataset and does not claim universal superiority."
            )
    else:
        selection_verdict = "No candidate models could be successfully evaluated."

    comparison_payload = {
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "primary_metric": "F1-score",
        "dataset_audit": audit,
        "split_metadata": split_meta,
        "selection_verdict": selection_verdict,
        "comparison_table": [
            {
                "model_id": c["model_id"],
                "model_name": c["model_name"],
                "model_type": c["model_type"],
                "status": c["status"],
                "accuracy": c["metrics"]["accuracy"] if c["metrics"] else "N/A",
                "precision": c["metrics"]["precision"] if c["metrics"] else "N/A",
                "recall": c["metrics"]["recall"] if c["metrics"] else "N/A",
                "f1": c["metrics"]["f1"] if c["metrics"] else "N/A",
                "roc_auc": c["metrics"]["roc_auc"] if c["metrics"] else "N/A",
                "fpr": c["metrics"]["fpr"] if c["metrics"] else "N/A",
                "fnr": c["metrics"]["fnr"] if c["metrics"] else "N/A",
                "latency_ms": c["inference_latency_ms"] if c["inference_latency_ms"] else "N/A",
            }
            for c in candidates
        ],
        "detailed_candidates": candidates,
    }

    # Save outputs
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    json_path = RESULTS_DIR / "model_comparison.json"
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(comparison_payload, f, indent=2)

    df_comp = pd.DataFrame(comparison_payload["comparison_table"])
    csv_path = RESULTS_DIR / "model_comparison.csv"
    df_comp.to_csv(csv_path, index=False)

    return comparison_payload


if __name__ == "__main__":
    print("=" * 70)
    print("EXECUTING EMPIRICAL MULTI-MODEL COMPARISON PROTOCOL")
    print("=" * 70)
    res = run_model_comparison()
    print("\nEmpirical Evaluation Results Table:")
    print(f"{'Model':<35} | {'Acc':<6} | {'Prec':<6} | {'Rec':<6} | {'F1':<6} | {'ROC':<6} | {'FPR':<6} | {'FNR':<6}")
    print("-" * 88)
    for row in res["comparison_table"]:
        print(f"{row['model_name']:<35} | {str(row['accuracy']):<6} | {str(row['precision']):<6} | {str(row['recall']):<6} | {str(row['f1']):<6} | {str(row['roc_auc']):<6} | {str(row['fpr']):<6} | {str(row['fnr']):<6}")
    print("\nSelection Verdict:")
    print(res["selection_verdict"])
    print("=" * 70)
