from __future__ import annotations

from typing import Any
import numpy as np
from sklearn.metrics import (
    accuracy_score,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
)


def calculate_metrics(
    y_true: list[int] | np.ndarray,
    y_pred: list[int] | np.ndarray,
    y_proba: list[float] | np.ndarray | None = None,
) -> dict[str, Any]:
    """
    Computes rigorous classification and forensic error metrics.
    Adheres strictly to standard mathematical definitions:
      - FPR = FP / (FP + TN)
      - FNR = FN / (FN + TP)
    Never fabricates metrics. If a metric cannot be calculated due to missing classes,
    it returns None / 'N/A' with an explicit explanation.
    """
    y_true_arr = np.asarray(y_true, dtype=int)
    y_pred_arr = np.asarray(y_pred, dtype=int)

    if len(y_true_arr) == 0 or len(y_pred_arr) == 0:
        return {
            "accuracy": None,
            "precision": None,
            "recall": None,
            "f1": None,
            "roc_auc": None,
            "fpr": None,
            "fnr": None,
            "confusion_matrix": {"tn": 0, "fp": 0, "fn": 0, "tp": 0},
            "notes": "Empty input data provided.",
        }

    # Confusion matrix with explicit labels [0, 1]
    cm = confusion_matrix(y_true_arr, y_pred_arr, labels=[0, 1])
    tn, fp, fn, tp = int(cm[0, 0]), int(cm[0, 1]), int(cm[1, 0]), int(cm[1, 1])

    # FPR = FP / (FP + TN)
    if (fp + tn) > 0:
        fpr = float(fp / (fp + tn))
    else:
        fpr = None  # No actual negative samples

    # FNR = FN / (FN + TP)
    if (fn + tp) > 0:
        fnr = float(fn / (fn + tp))
    else:
        fnr = None  # No actual positive samples

    acc = float(accuracy_score(y_true_arr, y_pred_arr))
    prec = float(precision_score(y_true_arr, y_pred_arr, zero_division=0))
    rec = float(recall_score(y_true_arr, y_pred_arr, zero_division=0))
    f1 = float(f1_score(y_true_arr, y_pred_arr, zero_division=0))

    roc_auc = None
    if y_proba is not None:
        try:
            # ROC-AUC requires at least one positive and one negative sample in y_true
            unique_classes = np.unique(y_true_arr)
            if len(unique_classes) >= 2:
                y_proba_arr = np.asarray(y_proba, dtype=float)
                roc_auc = float(roc_auc_score(y_true_arr, y_proba_arr))
            else:
                roc_auc = None
        except Exception:
            roc_auc = None

    return {
        "accuracy": round(acc, 4) if acc is not None else None,
        "precision": round(prec, 4) if prec is not None else None,
        "recall": round(rec, 4) if rec is not None else None,
        "f1": round(f1, 4) if f1 is not None else None,
        "roc_auc": round(roc_auc, 4) if roc_auc is not None else "N/A",
        "fpr": round(fpr, 4) if fpr is not None else "N/A",
        "fnr": round(fnr, 4) if fnr is not None else "N/A",
        "confusion_matrix": {
            "tn": tn,
            "fp": fp,
            "fn": fn,
            "tp": tp,
            "total": int(len(y_true_arr)),
        },
    }
