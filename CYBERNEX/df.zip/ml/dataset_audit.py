from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_BENCHMARK_PATH = PROJECT_ROOT / "data" / "benchmark_forensic_dataset.csv"

REQUIRED_FEATURES = [
    "https",
    "spf_result",
    "dkim_result",
    "dmarc_result",
    "url_risk",
    "domain_risk",
    "number_of_suspicious_words",
    "reply_to_mismatch",
    "sender_domain_mismatch",
    "suspicious_network_indicator",
    "browser_risk_score",
]
TARGET_COLUMN = "label"


def compute_file_sha256(filepath: Path | str) -> str:
    """Computes SHA-256 hash of a file for cryptographic provenance."""
    path = Path(filepath)
    if not path.exists():
        return ""
    hasher = hashlib.sha256()
    with open(path, "rb") as f:
        while chunk := f.read(65536):
            hasher.update(chunk)
    return hasher.hexdigest()


def audit_dataset(filepath: Path | str | None = None) -> dict[str, Any]:
    """
    Inspects and audits the actual benchmark dataset.
    Reports real row counts, columns, class distribution, missing values, duplicates,
    feature types, value ranges, and checks for potential data leakage indicators.
    Never assumes or fabricates statistics.
    """
    path = Path(filepath) if filepath else DEFAULT_BENCHMARK_PATH
    if not path.exists():
        return {
            "status": "FILE_NOT_FOUND",
            "file_path": str(path),
            "error": f"Dataset file does not exist at {path}",
            "sha256": "",
            "rows": 0,
            "columns": 0,
        }

    sha256_hash = compute_file_sha256(path)
    df = pd.read_csv(path)

    # 1. Basic shape
    num_rows, num_cols = df.shape
    columns = list(df.columns)

    # 2. Required features validation
    missing_required_features = [f for f in REQUIRED_FEATURES if f not in columns]
    has_target = TARGET_COLUMN in columns

    # 3. Missing values
    missing_per_col = {col: int(df[col].isna().sum()) for col in columns}
    total_missing = sum(missing_per_col.values())

    # 4. Duplicate rows
    # Check overall duplicates
    total_duplicates = int(df.duplicated().sum())
    # Check feature-only duplicates (identical feature vectors with possibly different labels)
    feature_duplicates = int(df.duplicated(subset=REQUIRED_FEATURES).sum()) if not missing_required_features else 0

    # 5. Label distribution
    label_dist: dict[str, int] = {}
    if has_target:
        counts = df[TARGET_COLUMN].value_counts().to_dict()
        label_dist = {str(k): int(v) for k, v in counts.items()}

    # 6. Categories / Groups (for leakage inspection)
    category_dist: dict[str, int] = {}
    if "category" in df.columns:
        cat_counts = df["category"].value_counts().to_dict()
        category_dist = {str(k): int(v) for k, v in cat_counts.items()}

    # 7. Feature types and value ranges
    feature_audit: dict[str, dict[str, Any]] = {}
    for feat in REQUIRED_FEATURES:
        if feat in df.columns:
            series = df[feat]
            non_numeric = pd.to_numeric(series, errors="coerce").isna().sum()
            feature_audit[feat] = {
                "dtype": str(series.dtype),
                "min": float(series.min()) if non_numeric == 0 else "N/A",
                "max": float(series.max()) if non_numeric == 0 else "N/A",
                "mean": round(float(series.mean()), 4) if non_numeric == 0 else "N/A",
                "unique_values_count": int(series.nunique()),
                "non_numeric_count": int(non_numeric),
            }

    # 8. Check validity of specific ranges
    invalid_range_warnings = []
    if "https" in df.columns and not df["https"].isin([0, 1]).all():
        invalid_range_warnings.append("https contains values outside binary [0, 1]")
    if "spf_result" in df.columns and not df["spf_result"].isin([0, 1]).all():
        invalid_range_warnings.append("spf_result contains values outside binary [0, 1]")
    if "dkim_result" in df.columns and not df["dkim_result"].isin([0, 1]).all():
        invalid_range_warnings.append("dkim_result contains values outside binary [0, 1]")
    if "dmarc_result" in df.columns and not df["dmarc_result"].isin([0, 1]).all():
        invalid_range_warnings.append("dmarc_result contains values outside binary [0, 1]")
    if "url_risk" in df.columns and ((df["url_risk"] < 0) | (df["url_risk"] > 100)).any():
        invalid_range_warnings.append("url_risk contains values outside [0, 100]")
    if "domain_risk" in df.columns and ((df["domain_risk"] < 0) | (df["domain_risk"] > 100)).any():
        invalid_range_warnings.append("domain_risk contains values outside [0, 100]")
    if "browser_risk_score" in df.columns and ((df["browser_risk_score"] < 0) | (df["browser_risk_score"] > 100)).any():
        invalid_range_warnings.append("browser_risk_score contains values outside [0, 100]")

    audit_result = {
        "status": "VALID" if (not missing_required_features and has_target and total_missing == 0) else "WARNING",
        "file_path": str(path.resolve()),
        "file_name": path.name,
        "sha256": sha256_hash,
        "num_rows": num_rows,
        "num_columns": num_cols,
        "columns": columns,
        "required_features_present": len(missing_required_features) == 0,
        "missing_required_features": missing_required_features,
        "target_present": has_target,
        "total_missing_values": total_missing,
        "missing_per_column": missing_per_col,
        "total_duplicate_rows": total_duplicates,
        "feature_duplicate_rows": feature_duplicates,
        "label_distribution": label_dist,
        "category_distribution": category_dist,
        "invalid_range_warnings": invalid_range_warnings,
        "feature_audit": feature_audit,
    }
    return audit_result


if __name__ == "__main__":
    result = audit_dataset()
    print("=" * 60)
    print("DATASET AUDIT REPORT")
    print("=" * 60)
    print(f"File: {result['file_name']}")
    print(f"SHA-256: {result['sha256']}")
    print(f"Rows: {result['num_rows']}, Columns: {result['num_columns']}")
    print(f"Status: {result['status']}")
    print(f"Target Present: {result['target_present']}")
    print(f"Label Distribution: {result['label_distribution']}")
    print(f"Missing Values: {result['total_missing_values']}")
    print(f"Duplicate Rows: {result['total_duplicate_rows']}")
    if result["category_distribution"]:
        print(f"Categories: {result['category_distribution']}")
    if result["invalid_range_warnings"]:
        print(f"Warnings: {result['invalid_range_warnings']}")
    print("Feature Ranges:")
    for feat, stats in result["feature_audit"].items():
        print(f"  - {feat:30s} min={stats['min']}, mean={stats['mean']}, max={stats['max']}")
    print("=" * 60)
