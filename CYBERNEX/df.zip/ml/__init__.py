from __future__ import annotations

from ml.ablation import run_ablation_experiment
from ml.dataset_audit import audit_dataset
from ml.evaluate import evaluate_all_registered_models
from ml.explain import explain_case_prediction, verify_shap_reconstruction
from ml.feature_dictionary import (
    FEATURE_DICTIONARY,
    FEATURE_NAMES,
    get_feature_dictionary,
    get_vector_feature_mapping,
)
from ml.metrics import calculate_metrics
from ml.model_comparison import run_model_comparison
from ml.model_registry import ModelPackage, ModelRegistry
from ml.preprocessing import ForensicPreprocessor, prepare_benchmark_splits
from ml.train import train_all_models

__all__ = [
    "FEATURE_NAMES",
    "FEATURE_DICTIONARY",
    "get_feature_dictionary",
    "get_vector_feature_mapping",
    "audit_dataset",
    "calculate_metrics",
    "ForensicPreprocessor",
    "prepare_benchmark_splits",
    "ModelPackage",
    "ModelRegistry",
    "train_all_models",
    "evaluate_all_registered_models",
    "run_model_comparison",
    "run_ablation_experiment",
    "explain_case_prediction",
    "verify_shap_reconstruction",
]
