from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler

from ml.feature_dictionary import FEATURE_NAMES

AUTHENTICATION_MAPPING: dict[str, int] = {
    "pass": 1,
    "1": 1,
    1: 1,
    True: 1,
    "fail": 0,
    "softfail": 0,
    "neutral": 0,
    "none": 0,
    "permerror": 0,
    "temperror": 0,
    "unknown": 0,
    "unavailable": 0,
    "0": 0,
    0: 0,
    False: 0,
}


def normalize_auth_status(value: Any) -> int:
    """
    Explicitly normalizes SPF/DKIM/DMARC authentication statuses into numerical representation.
    Documented mapping:
      - 'pass' / 1 / True -> 1 (cryptographically verified or authorized)
      - 'fail' / 0 / False -> 0 (explicitly rejected/failed policy)
      - 'none' / 'unknown' / 'unavailable' -> 0 (unauthenticated / missing header)
    Does NOT silently guess; maps cleanly according to RFC specs.
    """
    if value is None:
        return 0
    if isinstance(value, str):
        v = value.strip().lower()
        return AUTHENTICATION_MAPPING.get(v, 0)
    if isinstance(value, (int, float, bool)):
        return 1 if value else 0
    return 0


class ForensicPreprocessor:
    """
    Strict, reproducible preprocessing pipeline ensuring ZERO data leakage.
    Fits imputers, scalers, and normalizers strictly on training partitions only.
    Guarantees consistent feature ordering across models and inference requests.
    """

    def __init__(self, feature_names: list[str] | None = None):
        self.feature_names = list(feature_names) if feature_names else list(FEATURE_NAMES)
        self.scaler = StandardScaler()
        self.medians_: dict[str, float] = {}
        self.is_fitted = False

    def fit(self, X: pd.DataFrame | np.ndarray) -> ForensicPreprocessor:
        """Fits imputation medians and standard scaler strictly on training data."""
        if isinstance(X, np.ndarray):
            df = pd.DataFrame(X, columns=self.feature_names)
        else:
            df = X.copy()

        # Validate features
        for f in self.feature_names:
            if f not in df.columns:
                raise ValueError(f"Missing required feature in training data: {f}")

        # Compute medians for imputation on training data
        self.medians_ = {}
        clean_df = pd.DataFrame()
        for f in self.feature_names:
            series = pd.to_numeric(df[f], errors="coerce")
            med = float(series.median()) if not np.isnan(series.median()) else 0.0
            self.medians_[f] = med
            clean_df[f] = series.fillna(med)

        # Fit scaler on clean training features
        self.scaler.fit(clean_df[self.feature_names])
        self.is_fitted = True
        return self

    def transform(
        self,
        X: pd.DataFrame | dict[str, Any] | list[dict[str, Any]] | np.ndarray,
        scale: bool = False,
    ) -> pd.DataFrame:
        """
        Transforms input into guaranteed feature schema.
        If scale=True (for Logistic Regression), applies the fitted StandardScaler.
        If scale=False (for Random Forest / XGBoost), returns raw unscaled features.
        """
        if not self.is_fitted:
            raise RuntimeError("ForensicPreprocessor must be fitted on training data before transform().")

        if isinstance(X, dict):
            df = pd.DataFrame([X])
        elif isinstance(X, list):
            df = pd.DataFrame(X)
        elif isinstance(X, np.ndarray):
            df = pd.DataFrame(X, columns=self.feature_names)
        else:
            df = X.copy()

        # Handle auth status normalization if columns exist as strings
        for auth_col in ["spf_result", "dkim_result", "dmarc_result"]:
            if auth_col in df.columns:
                df[auth_col] = df[auth_col].apply(normalize_auth_status)

        out_df = pd.DataFrame(index=df.index)
        for f in self.feature_names:
            if f in df.columns:
                series = pd.to_numeric(df[f], errors="coerce")
                out_df[f] = series.fillna(self.medians_.get(f, 0.0))
            else:
                out_df[f] = self.medians_.get(f, 0.0)

        # Enforce exact column ordering
        out_df = out_df[self.feature_names].astype(float)

        if scale:
            scaled_matrix = self.scaler.transform(out_df)
            out_df = pd.DataFrame(scaled_matrix, columns=self.feature_names, index=df.index)

        return out_df

    def fit_transform(self, X: pd.DataFrame | np.ndarray, scale: bool = False) -> pd.DataFrame:
        return self.fit(X).transform(X, scale=scale)

    def save(self, filepath: Path | str) -> None:
        """Saves fitted preprocessor state."""
        path = Path(filepath)
        path.parent.mkdir(parents=True, exist_ok=True)
        joblib.dump(self, path)

    @classmethod
    def load(cls, filepath: Path | str) -> ForensicPreprocessor:
        """Loads saved fitted preprocessor state."""
        return joblib.load(filepath)


def prepare_benchmark_splits(
    dataset_path: Path | str | None = None,
    test_size: float = 0.3,
    random_state: int = 42,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.Series, pd.Series, ForensicPreprocessor, dict[str, Any]]:
    """
    Loads benchmark dataset, performs stratified train/test split,
    and fits preprocessor strictly on X_train.
    Returns: X_train_raw, X_test_raw, y_train, y_test, preprocessor, split_metadata
    """
    path = Path(dataset_path) if dataset_path else Path(__file__).resolve().parents[1] / "data" / "benchmark_forensic_dataset.csv"
    if not path.exists():
        raise FileNotFoundError(f"Benchmark dataset not found at {path}")

    df = pd.read_csv(path)

    # Validate target and features
    if "label" not in df.columns:
        raise ValueError("Dataset missing 'label' target column.")

    X = df[FEATURE_NAMES].copy()
    y = df["label"].astype(int).copy()

    # Stratified split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    # Check for identical feature leakage between train and test
    train_tuples = set(tuple(x) for x in X_train.values)
    test_tuples = set(tuple(x) for x in X_test.values)
    overlap_count = len(train_tuples.intersection(test_tuples))

    # Fit preprocessor strictly on X_train
    preprocessor = ForensicPreprocessor(FEATURE_NAMES)
    preprocessor.fit(X_train)

    split_metadata = {
        "dataset_path": str(path.resolve()),
        "total_samples": len(df),
        "train_samples": len(X_train),
        "test_samples": len(X_test),
        "test_size": test_size,
        "random_state": random_state,
        "stratified": True,
        "feature_overlap_count": overlap_count,
        "leakage_check_passed": overlap_count == 0,
        "train_class_distribution": {str(k): int(v) for k, v in y_train.value_counts().items()},
        "test_class_distribution": {str(k): int(v) for k, v in y_test.value_counts().items()},
    }

    return X_train, X_test, y_train, y_test, preprocessor, split_metadata
