from __future__ import annotations

from typing import Any

import numpy as np
import pandas as pd
import shap

from ml.feature_dictionary import FEATURE_DICTIONARY, FEATURE_NAMES
from ml.model_registry import ModelPackage, ModelRegistry

SHAP_RECONSTRUCTION_TOLERANCE = 1e-3


def verify_shap_reconstruction(
    base_value: float,
    shap_values: list[float] | np.ndarray,
    model_output: float,
    tolerance: float = SHAP_RECONSTRUCTION_TOLERANCE,
) -> tuple[bool, float, float]:
    """
    Validates the additive property of SHAP explanations:
      f(x) = phi_0 + sum(phi_i)
    Returns:
      (is_verified, reconstructed_value, absolute_discrepancy)
    """
    sum_phi = float(np.sum(shap_values))
    reconstructed = float(base_value + sum_phi)
    discrepancy = float(abs(reconstructed - model_output))
    is_valid = bool(discrepancy <= tolerance)
    return is_valid, round(reconstructed, 6), round(discrepancy, 6)


def explain_case_prediction(
    features_dict: dict[str, Any],
    model_type: str = "random_forest",
    case_id: str | None = None,
) -> dict[str, Any]:
    """
    Generates genuine, mathematically validated Explainable AI attribution using shap.TreeExplainer.
    Supports both Random Forest (probability space) and XGBoost (margin/probability space).

    Strict Anti-Fabrication & Defense Rules:
      - Never converts SHAP values into fake percentages.
      - Uses scientifically rigorous phrasing: 'Feature X contributed positively/negatively to this model prediction.'
      - Never asserts criminal causality ('Feature X caused 40% of the attack').
      - Reconstructs and validates f(x) = phi_0 + sum(phi_i).
    """
    registry = ModelRegistry()
    package = registry.get_model(model_type)
    model = package.estimator
    feature_schema = package.feature_schema

    # Construct guaranteed single-row DataFrame
    row: dict[str, float] = {}
    for f in feature_schema:
        v = features_dict.get(f, 0)
        if isinstance(v, bool):
            v = int(v)
        try:
            row[f] = float(v)
        except (ValueError, TypeError):
            row[f] = 0.0

    raw_frame = pd.DataFrame([row], columns=feature_schema)
    scaled = package.metadata.get("uses_scaled_features", False)
    transformed_frame = package.preprocessor.transform(raw_frame, scale=scaled)

    # 1. Model inference
    pred_class = int(model.predict(transformed_frame)[0])
    has_proba = hasattr(model, "predict_proba")
    proba_dist = model.predict_proba(transformed_frame)[0] if has_proba else [0.5, 0.5]
    phish_proba = float(proba_dist[1]) if len(proba_dist) > 1 else float(proba_dist[0])

    if pred_class == 1:
        prediction_label = "Suspicious" if phish_proba < 0.55 else "Phishing"
    else:
        prediction_label = "Safe"

    risk_score = int(round(phish_proba * 100))
    if prediction_label == "Suspicious":
        risk_score = max(45, min(70, risk_score))

    # 2. SHAP computation via TreeExplainer
    shap_contributions: list[dict[str, Any]] = []
    positive_contributors: list[dict[str, Any]] = []
    negative_contributors: list[dict[str, Any]] = []
    neutral_contributors: list[dict[str, Any]] = []

    shap_available = True
    shap_error = None
    baseline_val = 0.5
    raw_target_output = phish_proba
    explanation_space = "probability"

    try:
        explainer = shap.TreeExplainer(model)
        explanation = explainer(transformed_frame)

        # Handle multiclass/binary probability vs margin output shape
        if len(explanation.values.shape) == 3 and explanation.values.shape[2] == 2:
            # Random Forest binary class (class 1 is phishing)
            raw_shap = explanation.values[0, :, 1]
            base_val = (
                explanation.base_values[0, 1]
                if len(explanation.base_values.shape) > 1
                else explanation.base_values[0]
            )
            raw_target_output = phish_proba
            explanation_space = "probability"
        elif len(explanation.values.shape) == 2:
            # XGBoost margin space (log-odds)
            raw_shap = explanation.values[0]
            base_val = explanation.base_values[0]
            # Output margin from XGBoost
            if hasattr(model, "predict"):
                try:
                    raw_target_output = float(model.predict(transformed_frame, output_margin=True)[0])
                    explanation_space = "log-odds (margin)"
                except Exception:
                    raw_target_output = float(base_val + sum(raw_shap))
            else:
                raw_target_output = float(base_val + sum(raw_shap))
        else:
            raw_shap = explanation.values[0]
            base_val = explanation.base_values[0]

        baseline_val = float(base_val)

        # Validate additive reconstruction: f(x) = phi_0 + sum(phi_i)
        is_verified, recon_val, discrepancy = verify_shap_reconstruction(
            base_value=baseline_val,
            shap_values=raw_shap,
            model_output=raw_target_output,
            tolerance=SHAP_RECONSTRUCTION_TOLERANCE,
        )

        for feat_name, feat_val, sv in zip(feature_schema, raw_frame.iloc[0], raw_shap):
            contribution = float(sv)
            meta = FEATURE_DICTIONARY.get(feat_name, {})
            vector_name = meta.get("vector", "General")

            if contribution > 1e-4:
                impact = "Increases Risk"
                direction = "+"
                statement = (
                    f"Feature '{feat_name}' (value: {feat_val}) contributed positively (+{abs(round(contribution, 4))}) "
                    f"toward the phishing risk prediction relative to baseline expectation."
                )
            elif contribution < -1e-4:
                impact = "Decreases Risk"
                direction = "-"
                statement = (
                    f"Feature '{feat_name}' (value: {feat_val}) contributed negatively (-{abs(round(contribution, 4))}) "
                    f"reducing the phishing risk prediction toward benign classification."
                )
            else:
                impact = "Neutral"
                direction = "="
                statement = f"Feature '{feat_name}' had minimal influence on this specific prediction."

            entry = {
                "feature": feat_name,
                "value": feat_val,
                "shap_value": round(contribution, 4),
                "impact": impact,
                "direction": direction,
                "vector": vector_name,
                "explanation_statement": statement,
                "caveat": meta.get("dfir_caveat", ""),
            }
            shap_contributions.append(entry)
            if direction == "+":
                positive_contributors.append(entry)
            elif direction == "-":
                negative_contributors.append(entry)
            else:
                neutral_contributors.append(entry)

        # Sort contributions by absolute magnitude descending
        shap_contributions.sort(key=lambda x: abs(x["shap_value"]), reverse=True)
        positive_contributors.sort(key=lambda x: x["shap_value"], reverse=True)
        negative_contributors.sort(key=lambda x: abs(x["shap_value"]), reverse=True)

    except Exception as exc:
        shap_available = False
        shap_error = str(exc)
        is_verified = False
        recon_val = None
        discrepancy = None

    # Deterministic rule-based forensic observations (explicitly separate from ML)
    deterministic_observations = []
    if row.get("spf_result") == 0:
        deterministic_observations.append("SPF validation failed (unauthorized sending IP / missing SPF record)")
    if row.get("dkim_result") == 0:
        deterministic_observations.append("DKIM digital signature failed verification")
    if row.get("dmarc_result") == 0:
        deterministic_observations.append("DMARC domain policy alignment failed")
    if row.get("reply_to_mismatch") == 1:
        deterministic_observations.append("Reply-To header domain conflicts with From header domain")
    if row.get("sender_domain_mismatch") == 1:
        deterministic_observations.append("Sender envelope domain conflicts with Return-Path domain")
    if row.get("https") == 0:
        deterministic_observations.append("Target website communicates over unencrypted HTTP protocol")
    if row.get("url_risk", 0) >= 50:
        deterministic_observations.append(f"High lexical URL risk score: {int(row['url_risk'])}/100")
    if row.get("domain_risk", 0) >= 50:
        deterministic_observations.append(f"High domain lexical/reputation risk score: {int(row['domain_risk'])}/100")
    if row.get("number_of_suspicious_words", 0) >= 2:
        deterministic_observations.append(f"NLP detected {int(row['number_of_suspicious_words'])} urgency/coercion keywords")
    if row.get("suspicious_network_indicator") == 1:
        deterministic_observations.append("Suspicious network telemetry: non-standard port or direct-IP host request detected")
    if row.get("browser_risk_score", 0) >= 50:
        deterministic_observations.append(f"High browser history forensic risk score: {int(row['browser_risk_score'])}/100")

    result = {
        "case_id": case_id,
        "model_name": package.model_name,
        "model_type": model_type,
        "model_version": package.version,
        "prediction": prediction_label,
        "predicted_class": pred_class,
        "model_probability": round(phish_proba, 4),
        "risk_score": risk_score,
        "explanation_space": explanation_space,
        "shap_available": shap_available,
        "shap_error": shap_error,
        "shap_baseline": round(baseline_val, 4) if baseline_val is not None else None,
        "raw_model_output": round(raw_target_output, 4) if raw_target_output is not None else None,
        "reconstructed_output": recon_val,
        "reconstruction_discrepancy": discrepancy,
        "reconstruction_verified": is_verified,
        "math_formulation": "f(x) = phi_0 + sum(phi_i)",
        "shap_contributions": shap_contributions,
        "positive_contributors": positive_contributors,
        "negative_contributors": negative_contributors,
        "neutral_contributors": neutral_contributors,
        "deterministic_forensic_observations": deterministic_observations or ["No severe anomalies identified in individual vectors."],
    }
    return result


if __name__ == "__main__":
    test_feat = {
        "https": 0,
        "spf_result": 0,
        "dkim_result": 0,
        "dmarc_result": 0,
        "url_risk": 88,
        "domain_risk": 79,
        "number_of_suspicious_words": 5,
        "reply_to_mismatch": 1,
        "sender_domain_mismatch": 1,
        "suspicious_network_indicator": 1,
        "browser_risk_score": 85.0,
    }

    print("=" * 70)
    print("DEMONSTRATING SHAP EXPLAINER ON RANDOM FOREST:")
    print("=" * 70)
    exp_rf = explain_case_prediction(test_feat, model_type="random_forest")
    print(f"Model: {exp_rf['model_name']} (v{exp_rf['model_version']})")
    print(f"Prediction: {exp_rf['prediction']} (Risk Score: {exp_rf['risk_score']}/100, Proba: {exp_rf['model_probability']})")
    print(f"Baseline phi_0: {exp_rf['shap_baseline']}, Model Output: {exp_rf['raw_model_output']}")
    print(f"Reconstructed: {exp_rf['reconstructed_output']}, Verified: {exp_rf['reconstruction_verified']}")
    print("Top Feature Contributions:")
    for item in exp_rf["shap_contributions"][:5]:
        print(f"  {item['direction']} {item['feature']:<30} {item['shap_value']:+.4f} ({item['impact']})")

    print("\n" + "=" * 70)
    print("DEMONSTRATING SHAP EXPLAINER ON XGBOOST:")
    print("=" * 70)
    try:
        exp_xgb = explain_case_prediction(test_feat, model_type="xgboost")
        print(f"Model: {exp_xgb['model_name']} (v{exp_xgb['model_version']})")
        print(f"Prediction: {exp_xgb['prediction']} (Proba: {exp_xgb['model_probability']})")
        print(f"Space: {exp_xgb['explanation_space']}")
        print(f"Baseline phi_0: {exp_xgb['shap_baseline']}, Raw Output: {exp_xgb['raw_model_output']}")
        print(f"Reconstructed: {exp_xgb['reconstructed_output']}, Verified: {exp_xgb['reconstruction_verified']}")
        print("Top Feature Contributions:")
        for item in exp_xgb["shap_contributions"][:5]:
            print(f"  {item['direction']} {item['feature']:<30} {item['shap_value']:+.4f} ({item['impact']})")
    except Exception as e:
        print(f"XGBoost test error: {e}")
    print("=" * 70)
