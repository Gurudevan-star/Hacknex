from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import joblib
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
REGISTRY_DIR = PROJECT_ROOT / "models"
REGISTRY_INDEX_FILE = REGISTRY_DIR / "model_registry.json"


class ModelPackage:
    """Encapsulates a trained estimator, preprocessor, and full provenance metadata."""

    def __init__(
        self,
        estimator: Any,
        preprocessor: Any,
        metadata: dict[str, Any],
    ):
        self.estimator = estimator
        self.preprocessor = preprocessor
        self.metadata = metadata

    @property
    def model_name(self) -> str:
        return self.metadata.get("model_name", "UnknownModel")

    @property
    def model_type(self) -> str:
        return self.metadata.get("model_type", "unknown")

    @property
    def version(self) -> str:
        return self.metadata.get("version", "1.0.0")

    @property
    def feature_schema(self) -> list[str]:
        return self.metadata.get("feature_schema", [])

    def predict(self, X: pd.DataFrame | dict[str, Any]) -> int:
        scale = self.metadata.get("uses_scaled_features", False)
        X_trans = self.preprocessor.transform(X, scale=scale)
        pred = self.estimator.predict(X_trans)
        return int(pred[0])

    def predict_proba(self, X: pd.DataFrame | dict[str, Any]) -> list[float]:
        scale = self.metadata.get("uses_scaled_features", False)
        X_trans = self.preprocessor.transform(X, scale=scale)
        if hasattr(self.estimator, "predict_proba"):
            probs = self.estimator.predict_proba(X_trans)[0]
            return [float(p) for p in probs]
        pred = self.predict(X)
        return [0.0, 1.0] if pred == 1 else [1.0, 0.0]


class ModelRegistry:
    """Manages model artifacts, metadata persistence, versioning, and retrieval."""

    def __init__(self, root_dir: Path | str | None = None):
        self.root_dir = Path(root_dir) if root_dir else REGISTRY_DIR
        self.root_dir.mkdir(parents=True, exist_ok=True)
        self.index_path = self.root_dir / "model_registry.json"

    def _read_index(self) -> dict[str, Any]:
        if not self.index_path.exists():
            return {"active_model": None, "models": {}}
        try:
            with open(self.index_path, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            return {"active_model": None, "models": {}}

    def _write_index(self, index: dict[str, Any]) -> None:
        with open(self.index_path, "w", encoding="utf-8") as f:
            json.dump(index, f, indent=2)

    def register_model(
        self,
        model_type: str,
        estimator: Any,
        preprocessor: Any,
        feature_schema: list[str],
        hyperparameters: dict[str, Any],
        evaluation_metrics: dict[str, Any],
        dataset_hash: str,
        uses_scaled_features: bool = False,
        version: str = "1.0.0",
        make_active: bool = False,
    ) -> Path:
        """Saves estimator, preprocessor, and metadata to the model registry."""
        model_dir = self.root_dir / model_type
        model_dir.mkdir(parents=True, exist_ok=True)

        model_file = model_dir / f"{model_type}_model.joblib"
        metadata_file = model_dir / f"{model_type}_metadata.json"

        timestamp = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC")
        model_name = {
            "logistic_regression": "Logistic Regression (Scaled L2)",
            "random_forest": "Random Forest Classifier (100 Trees Baseline)",
            "xgboost": "XGBoost Classifier (Gradient Boosted Trees)",
        }.get(model_type, model_type.title())

        metadata = {
            "model_name": model_name,
            "model_type": model_type,
            "version": version,
            "training_timestamp": timestamp,
            "dataset_hash": dataset_hash,
            "feature_schema": list(feature_schema),
            "feature_count": len(feature_schema),
            "uses_scaled_features": uses_scaled_features,
            "hyperparameters": hyperparameters,
            "evaluation_metrics": evaluation_metrics,
            "model_file": str(model_file.resolve()),
        }

        package = ModelPackage(
            estimator=estimator,
            preprocessor=preprocessor,
            metadata=metadata,
        )

        joblib.dump(package, model_file)
        with open(metadata_file, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=2)

        # Update index
        index = self._read_index()
        index["models"][model_type] = {
            "model_name": model_name,
            "version": version,
            "training_timestamp": timestamp,
            "file": str(model_file.resolve()),
            "metrics": evaluation_metrics,
        }
        if make_active or index.get("active_model") is None:
            index["active_model"] = model_type

        self._write_index(index)
        return model_file

    def get_model(self, model_type: str | None = None) -> ModelPackage:
        """Retrieves a ModelPackage from disk."""
        index = self._read_index()
        target_type = model_type or index.get("active_model") or "random_forest"

        model_file = self.root_dir / target_type / f"{target_type}_model.joblib"
        if not model_file.exists():
            raise FileNotFoundError(f"Model {target_type} not found at {model_file}. Train models first.")

        package = joblib.load(model_file)
        return package

    def list_models(self) -> dict[str, Any]:
        """Returns the registered models index."""
        return self._read_index()

    def set_active_model(self, model_type: str) -> bool:
        """Sets the active model in the registry."""
        index = self._read_index()
        if model_type in index["models"]:
            index["active_model"] = model_type
            self._write_index(index)
            return True
        return False
