from __future__ import annotations

from typing import Any

FEATURE_NAMES = [
    "https",
    "spf_result",
    "dkim_result",
    "dmarc_result",
    "url_risk",
    "domain_risk",
    "number_of_suspicious_words",
    "reply_to_mismatch",
    "sender_domain_mismatch",
    "suspicious_network_indicator",
    "browser_risk_score",
]

FEATURE_DICTIONARY: dict[str, dict[str, Any]] = {
    "https": {
        "index": 1,
        "name": "https",
        "vector": "URL / Website",
        "semantic_meaning": "Indicates whether the connection or URL utilizes HTTPS encryption protocol.",
        "data_type": "binary (0 or 1)",
        "allowed_range": "[0, 1]",
        "source_module": "app.website.website_analysis",
        "calculation_methodology": (
            "Extracted via URL parsing scheme inspection (url.lower().startswith('https://')). "
            "Returns 1 if HTTPS, 0 if plain HTTP or missing."
        ),
        "dfir_caveat": (
            "CRITICAL FORENSIC CAVEAT: HTTPS denotes transport-layer TLS encryption; it does NOT constitute "
            "proof that a website is benign, authentic, or legitimate. Modern phishing sites overwhelmingly "
            "obtain free automated TLS certificates (e.g., Let's Encrypt) to deceptively display the browser padlock."
        ),
    },
    "spf_result": {
        "index": 2,
        "name": "spf_result",
        "vector": "Email",
        "semantic_meaning": "Sender Policy Framework (SPF) RFC 7208 authentication status for the sending mail server.",
        "data_type": "binary (0 or 1)",
        "allowed_range": "[0, 1]",
        "source_module": "app.email.email_forensics",
        "calculation_methodology": (
            "Parsed from the email 'Authentication-Results' or 'Received-SPF' headers. "
            "Encoded as 1 if 'spf=pass' (sending IP is authorized by the sender domain's SPF DNS record); "
            "encoded as 0 if fail, softfail, neutral, none, permerror, temperror, or header unavailable."
        ),
        "dfir_caveat": (
            "A failed SPF check indicates unauthorized sender infrastructure. However, a 'pass' may still occur "
            "if an attacker registers their own domain with valid SPF records or compromises authorized infrastructure."
        ),
    },
    "dkim_result": {
        "index": 3,
        "name": "dkim_result",
        "vector": "Email",
        "semantic_meaning": "DomainKeys Identified Mail (DKIM) RFC 6376 cryptographic digital signature verification status.",
        "data_type": "binary (0 or 1)",
        "allowed_range": "[0, 1]",
        "source_module": "app.email.email_forensics",
        "calculation_methodology": (
            "Extracted from 'Authentication-Results' or 'DKIM-Signature' validation telemetry. "
            "Encoded as 1 if 'dkim=pass' (cryptographic signature over email body and headers successfully verified); "
            "encoded as 0 if fail, neutral, none, or invalid signature."
        ),
        "dfir_caveat": (
            "DKIM verifies message integrity and signing domain identity. An attacker-controlled domain can sign emails "
            "with valid DKIM; alignment with the visible From domain must also be checked."
        ),
    },
    "dmarc_result": {
        "index": 4,
        "name": "dmarc_result",
        "vector": "Email",
        "semantic_meaning": "Domain-based Message Authentication, Reporting, and Conformance (DMARC) RFC 7489 alignment status.",
        "data_type": "binary (0 or 1)",
        "allowed_range": "[0, 1]",
        "source_module": "app.email.email_forensics",
        "calculation_methodology": (
            "Extracted from 'Authentication-Results' dmarc evaluation. "
            "Encoded as 1 if 'dmarc=pass' (requires SPF and/or DKIM to pass AND align with the visible RFC 5322 From domain); "
            "encoded as 0 if fail, none, or absent policy."
        ),
        "dfir_caveat": (
            "DMARC failure strongly suggests domain impersonation/spoofing of legitimate corporate identities."
        ),
    },
    "url_risk": {
        "index": 5,
        "name": "url_risk",
        "vector": "URL / Website",
        "semantic_meaning": "Lexical structural risk score of the target URL.",
        "data_type": "integer/float (0 to 100)",
        "allowed_range": "[0, 100]",
        "source_module": "app.website.website_analysis.analyze_url_for_suspicion",
        "calculation_methodology": (
            "Deterministic heuristic score combining: IP address in host (+30), excessive subdomains (>3, +15), "
            "high entropy path segments (+15), target brand keywords in path/subdomain (+20), suspicious TLDs (+20), "
            "presence of credential keywords ('login', 'verify', 'update', 'signin', +15), and login form detection."
        ),
        "dfir_caveat": (
            "Computed solely from static lexical and DOM characteristics; does not execute active browser payloads."
        ),
    },
    "domain_risk": {
        "index": 6,
        "name": "domain_risk",
        "vector": "Browser / DNS",
        "semantic_meaning": "Domain lexical reputation risk score.",
        "data_type": "integer/float (0 to 100)",
        "allowed_range": "[0, 100]",
        "source_module": "app.utils.suspicious_domain_score",
        "calculation_methodology": (
            "Evaluated by analyzing the fully qualified domain name (FQDN): excessive hyphens (>2, +20), "
            "Shannon character entropy (>3.8 bits, +25), dynamic DNS or suspicious TLD (.tk, .xyz, .top, .icu, +25), "
            "punycode/IDN homograph prefix 'xn--', and brand typosquatting distance against protected target brands."
        ),
        "dfir_caveat": (
            "Evaluates domain string characteristics; air-gapped safe evaluation without external WHOIS or DNS lookups."
        ),
    },
    "number_of_suspicious_words": {
        "index": 7,
        "name": "number_of_suspicious_words",
        "vector": "NLP / Social Engineering",
        "semantic_meaning": "Count of social engineering urgency, threat, or credential harvesting trigger terms detected.",
        "data_type": "integer (>= 0)",
        "allowed_range": "[0, 100]",
        "source_module": "app.nlp.phishing_nlp.detect_phishing_language",
        "calculation_methodology": (
            "Regex tokenization and matching against curated cybersecurity forensic lure dictionaries: "
            "Urgency cues ('immediately', 'urgent', 'action required', 'within 24 hours'), "
            "Threat/fear cues ('suspended', 'terminated', 'unauthorized', 'compromised', 'locked'), "
            "Call-to-action/harvesting cues ('verify your password', 'click here to confirm', 'update billing', 'reactivate')."
        ),
        "dfir_caveat": (
            "Keywords indicate manipulative psychological framing. Benign transactional alerts (e.g. password reset emails "
            "requested by user) may contain these terms; must be interpreted in cross-vector context."
        ),
    },
    "reply_to_mismatch": {
        "index": 8,
        "name": "reply_to_mismatch",
        "vector": "Email",
        "semantic_meaning": "Binary indicator specifying whether the email Reply-To header domain conflicts with the From header.",
        "data_type": "binary (0 or 1)",
        "allowed_range": "[0, 1]",
        "source_module": "app.email.email_forensics",
        "calculation_methodology": (
            "Extracted via domain extraction from RFC 822 'From' and 'Reply-To' headers: "
            "1 if Reply-To exists AND extract_domain(reply_to) != extract_domain(from_address); 0 otherwise."
        ),
        "dfir_caveat": (
            "Mismatches frequently indicate credential harvesters redirecting responses to free webmail drop-boxes. "
            "However, legitimate mailing lists and automated CRM systems (e.g., Salesforce, Zendesk) also legitimately use distinct Reply-To addresses."
        ),
    },
    "sender_domain_mismatch": {
        "index": 9,
        "name": "sender_domain_mismatch",
        "vector": "Email",
        "semantic_meaning": "Binary indicator specifying whether the visible From domain conflicts with the Return-Path (envelope sender).",
        "data_type": "binary (0 or 1)",
        "allowed_range": "[0, 1]",
        "source_module": "app.email.email_forensics",
        "calculation_methodology": (
            "1 if Return-Path exists AND extract_domain(from_address) != extract_domain(return_path); 0 otherwise."
        ),
        "dfir_caveat": (
            "Envelope sender bounce mismatches occur in email spoofing campaigns, but also in legitimate third-party bulk dispatchers (e.g., Mailchimp, SendGrid)."
        ),
    },
    "suspicious_network_indicator": {
        "index": 10,
        "name": "suspicious_network_indicator",
        "vector": "Network / NetFlow / DNS",
        "semantic_meaning": "Binary indicator specifying anomalous destination IP, non-standard egress port, or suspicious host pattern.",
        "data_type": "binary (0 or 1)",
        "allowed_range": "[0, 1]",
        "source_module": "app.network.network_forensics.analyze_network_traffic",
        "calculation_methodology": (
            "Evaluated from NetFlow, PCAP CSV, or connection logs: 1 if connection targets non-standard ports (e.g., 4444, 8080, 1337), "
            "direct IP HTTP host requests without valid domain, private RFC1918 IP outbound proxying, or DNS resolution matching flagged host; 0 otherwise."
        ),
        "dfir_caveat": (
            "Based on available network telemetry. Encrypted traffic payloads are not decrypted; flow metadata is inspected."
        ),
    },
    "browser_risk_score": {
        "index": 11,
        "name": "browser_risk_score",
        "vector": "Browser History",
        "semantic_meaning": "Composite forensic risk score computed across browser history records.",
        "data_type": "integer/float (0 to 100)",
        "allowed_range": "[0, 100]",
        "source_module": "app.browser.browser_forensics.analyze_browser_history",
        "calculation_methodology": (
            "Aggregates visit records from SQLite places.sqlite or Chromium History: "
            "Evaluates percentage of visited URLs with high lexical risk, single-visit rapid-dwell landing pages, "
            "known phishing TLDs, and cross-referencing against email lure URLs. Produces normalized 0-100 score."
        ),
        "dfir_caveat": (
            "Reflects observed browsing behavior in the local profile. Incognito/private browsing sessions may leave no persistent SQLite records."
        ),
    },
}


def get_feature_dictionary() -> dict[str, dict[str, Any]]:
    """Returns the complete machine-readable feature dictionary."""
    return FEATURE_DICTIONARY


def get_vector_feature_mapping() -> dict[str, list[str]]:
    """Returns the mapping of forensic vectors to their component features."""
    return {
        "Email": ["spf_result", "dkim_result", "dmarc_result", "reply_to_mismatch", "sender_domain_mismatch"],
        "Browser": ["browser_risk_score", "domain_risk"],
        "Network": ["suspicious_network_indicator"],
        "Website/NLP": ["https", "url_risk", "number_of_suspicious_words"],
    }
