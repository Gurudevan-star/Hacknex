from __future__ import annotations

import argparse
from pathlib import Path
from typing import Any

import pandas as pd

from ml.dataset_audit import audit_dataset
from ml.feature_dictionary import FEATURE_NAMES
from ml.metrics import calculate_metrics
from ml.model_registry import ModelRegistry
from ml.preprocessing import prepare_benchmark_splits


def evaluate_all_registered_models(
    dataset_path: Path | str | None = None,
    test_size: float = 0.3,
    random_state: int = 42,
) -> dict[str, Any]:
    """
    Evaluates all registered models on the benchmark holdout test set.
    Ensures identical evaluation protocol for every model.
    """
    X_train, X_test, y_train, y_test, preprocessor, split_meta = prepare_benchmark_splits(
        dataset_path=dataset_path,
        test_size=test_size,
        random_state=random_state,
    )

    registry = ModelRegistry()
    index = registry.list_models()

    eval_results: dict[str, Any] = {
        "split_metadata": split_meta,
        "models": {},
    }

    for model_type in ["logistic_regression", "random_forest", "xgboost"]:
        if model_type not in index.get("models", {}):
            eval_results["models"][model_type] = {
                "status": "NOT_REGISTERED",
                "metrics": None,
            }
            continue

        try:
            package = registry.get_model(model_type)
            uses_scaled = package.metadata.get("uses_scaled_features", False)
            X_test_proc = package.preprocessor.transform(X_test, scale=uses_scaled)

            preds = package.estimator.predict(X_test_proc)
            probs = (
                package.estimator.predict_proba(X_test_proc)[:, 1]
                if hasattr(package.estimator, "predict_proba")
                else None
            )

            metrics = calculate_metrics(y_test, preds, probs)
            eval_results["models"][model_type] = {
                "status": "EVALUATED",
                "model_name": package.model_name,
                "version": package.version,
                "metrics": metrics,
            }
        except Exception as exc:
            eval_results["models"][model_type] = {
                "status": "EVALUATION_ERROR",
                "error": str(exc),
                "metrics": None,
            }

    return eval_results


if __name__ == "__main__":
    print("=" * 65)
    print("EVALUATING ALL REGISTERED DFIR ML MODELS ON BENCHMARK TEST SET")
    print("=" * 65)
    res = evaluate_all_registered_models()
    for m_type, m_info in res["models"].items():
        print(f"\nModel: {m_type.upper()} ({m_info.get('model_name', 'N/A')})")
        print(f"Status: {m_info['status']}")
        if m_info.get("metrics"):
            m = m_info["metrics"]
            print(f"  F1-Score:  {m['f1']}")
            print(f"  Accuracy:  {m['accuracy']}")
            print(f"  Precision: {m['precision']}")
            print(f"  Recall:    {m['recall']}")
            print(f"  ROC-AUC:   {m['roc_auc']}")
            print(f"  FPR:       {m['fpr']}")
            print(f"  FNR:       {m['fnr']}")
            print(f"  Confusion: {m['confusion_matrix']}")
    print("=" * 65)
