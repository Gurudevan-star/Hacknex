from __future__ import annotations

import json
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from sklearn.ensemble import RandomForestClassifier

from ml.dataset_audit import audit_dataset
from ml.feature_dictionary import FEATURE_NAMES, get_vector_feature_mapping
from ml.metrics import calculate_metrics
from ml.preprocessing import prepare_benchmark_splits

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results" / "ablation"
DATA_DIR = PROJECT_ROOT / "data"

VECTOR_MAPPING = get_vector_feature_mapping()

# Specific configurations defined in Section 16
ABLATION_CONFIGS = [
    {
        "config_id": "full_model",
        "name": "Full Model (Fused Cross-Vector)",
        "features": list(FEATURE_NAMES),
        "removed_vector": "None",
        "description": "Baseline model with all 11 features across all 5 forensic vectors.",
    },
    {
        "config_id": "no_email",
        "name": "No Email",
        "features": [f for f in FEATURE_NAMES if f not in VECTOR_MAPPING["Email"]],
        "removed_vector": "Email (SPF, DKIM, DMARC, Reply-To, Sender Mismatch)",
        "description": "Excludes email authentication headers and sender alignment features.",
    },
    {
        "config_id": "no_browser",
        "name": "No Browser",
        "features": [f for f in FEATURE_NAMES if f not in VECTOR_MAPPING["Browser"]],
        "removed_vector": "Browser (Browser Risk Score, Domain Risk)",
        "description": "Excludes local browser history telemetry and domain reputation metrics.",
    },
    {
        "config_id": "no_network",
        "name": "No Network (Without Network)",
        "features": [f for f in FEATURE_NAMES if f not in VECTOR_MAPPING["Network"]],
        "removed_vector": "Network (Suspicious Network Indicator)",
        "description": "Excludes NetFlow/PCAP egress connection and IP subnet indicators.",
    },
    {
        "config_id": "no_website_nlp",
        "name": "No Website/NLP (Combined)",
        "features": [f for f in FEATURE_NAMES if f not in VECTOR_MAPPING["Website/NLP"]],
        "removed_vector": "Website/NLP (HTTPS, URL Risk, Number of Suspicious Words)",
        "description": "Excludes lexical URL analysis, login form markers, and NLP urgency cues.",
    },
    {
        "config_id": "no_url",
        "name": "Without URL Vector",
        "features": [f for f in FEATURE_NAMES if f not in ["https", "url_risk"]],
        "removed_vector": "URL (HTTPS, URL Risk)",
        "description": "Excludes lexical URL characteristics and encryption status.",
    },
    {
        "config_id": "no_nlp",
        "name": "Without NLP Vector",
        "features": [f for f in FEATURE_NAMES if f not in ["number_of_suspicious_words"]],
        "removed_vector": "NLP (Number of Suspicious Words)",
        "description": "Excludes NLP urgency and phishing social engineering keywords.",
    },
]


def run_ablation_experiment(
    dataset_path: Path | str | None = None,
    test_size: float = 0.3,
    random_state: int = 42,
) -> dict[str, Any]:
    """
    Executes the empirical vector ablation study.
    For each configuration:
      - Constructs the exact reduced feature matrix (does NOT set features to zero)
      - Trains a fresh Random Forest classifier from scratch on X_train[subset]
      - Evaluates on X_test[subset] using identical holdout split
      - Computes real metrics: Precision, Recall, F1, ROC-AUC, FPR, FNR, Latency
      - Calculates delta F1 vs Full Model
    Never reuses predictions or fabricates values.
    """
    audit = audit_dataset(dataset_path)
    X_train_raw, X_test_raw, y_train, y_test, preprocessor, split_meta = prepare_benchmark_splits(
        dataset_path=dataset_path,
        test_size=test_size,
        random_state=random_state,
    )

    table_rows: list[dict[str, Any]] = []

    for cfg in ABLATION_CONFIGS:
        features_subset = cfg["features"]
        X_tr = X_train_raw[features_subset].copy()
        X_te = X_test_raw[features_subset].copy()

        # Train a fresh Random Forest classifier specifically on this reduced feature set
        t0 = time.perf_counter()
        clf = RandomForestClassifier(n_estimators=100, bootstrap=True, random_state=random_state)
        clf.fit(X_tr, y_train)
        pred = clf.predict(X_te)
        prob = clf.predict_proba(X_te)[:, 1]
        elapsed_ms = (time.perf_counter() - t0) * 1000.0

        metrics = calculate_metrics(y_test, pred, prob)

        table_rows.append({
            "config_id": cfg["config_id"],
            "configuration": cfg["name"],
            "removed_vector": cfg["removed_vector"],
            "description": cfg["description"],
            "features_used": len(features_subset),
            "feature_names": features_subset,
            "accuracy": metrics["accuracy"],
            "precision": metrics["precision"],
            "recall": metrics["recall"],
            "f1": metrics["f1"],
            "roc_auc": metrics["roc_auc"],
            "fpr": metrics["fpr"],
            "fnr": metrics["fnr"],
            "confusion_matrix": metrics["confusion_matrix"],
            "latency_ms": round(elapsed_ms, 2),
        })

    # Compute delta F1 vs Full Model
    full_f1 = table_rows[0]["f1"]
    for row in table_rows:
        delta = round(row["f1"] - full_f1, 4) if (row["f1"] is not None and full_f1 is not None) else 0.0
        row["delta_f1_vs_full"] = delta

    ablation_payload = {
        "status": "EXPERIMENT_EXECUTED",
        "executed": True,
        "experiment_timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S UTC"),
        "random_state": random_state,
        "test_size": test_size,
        "dataset_audit": audit,
        "split_metadata": split_meta,
        "table": table_rows,
        "summary": (
            "Empirical vector ablation study evaluates the performance impact when removing individual "
            "forensic vectors from the cross-vector pipeline on the benchmark dataset."
        ),
    }

    # Save to results/ablation/
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    res_file = RESULTS_DIR / "ablation_results.json"
    with open(res_file, "w", encoding="utf-8") as f:
        json.dump(ablation_payload, f, indent=2)

    df_table = pd.DataFrame(table_rows)
    csv_file = RESULTS_DIR / "ablation_results.csv"
    df_table.to_csv(csv_file, index=False)

    # Also save to data/ablation_results.json for backward compatibility with existing research_evaluation.py
    data_ablation_file = DATA_DIR / "ablation_results.json"
    with open(data_ablation_file, "w", encoding="utf-8") as f:
        json.dump(ablation_payload, f, indent=2)

    return ablation_payload


if __name__ == "__main__":
    print("=" * 80)
    print("EXECUTING EMPIRICAL VECTOR ABLATION STUDY (RETRAINING PER CONFIGURATION)")
    print("=" * 80)
    res = run_ablation_experiment()
    print(f"{'Configuration':<32} | {'Feats':<5} | {'Prec':<6} | {'Rec':<6} | {'F1':<6} | {'ROC-AUC':<7} | {'delta_F1':<6}")
    print("-" * 80)
    for row in res["table"]:
        print(f"{row['configuration']:<32} | {row['features_used']:<5} | {str(row['precision']):<6} | {str(row['recall']):<6} | {str(row['f1']):<6} | {str(row['roc_auc']):<7} | {str(row['delta_f1_vs_full']):<6}")
    print("=" * 80)
